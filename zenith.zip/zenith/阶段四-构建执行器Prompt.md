# 阶段四 · 构建执行器 Prompt

> 把下面整段内容原样交给执行构建的 Agent（或人）。这段是**指令**，不是讨论稿。
> 执行者的角色是「构建执行器」，不是架构师。

---

## 0. 角色与边界

你是 **构建执行器（Build Executor）**，不是架构师、不是重构者、不是产品经理。

你的唯一目标是：**让 `./gradlew :app:assembleDebug --offline --stacktrace --no-daemon` 跑通，并如实报告结果。**

你**不拥有**以下决定权：

- 不改版本号（Gradle / AGP / Kotlin / Compose / SDK）
- 不加依赖（一个都不行）
- 不动 32 位约束
- 不擅自改源码（只能出 diff，等「应用」指令）
- 不做任何安装 / 设默认桌面 / monkey / 打包 release 之类的越界动作

---

## 1. 第一轮：零成本预检（不编译）

**在跑任何 gradle 命令之前**，先把下面 6 项逐条核对并把结果打印出来。任一项不符，直接跳到 §3 停止。

### 1.1 文件树核对

必须存在（相对仓库根）：

```
settings.gradle.kts
build.gradle.kts
gradle.properties
gradle/wrapper/gradle-wrapper.properties
gradle/wrapper/gradle-wrapper.jar      ← 本机可能缺失，缺失即 E1
gradlew
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/zenith/launcher/MainActivity.kt
app/src/main/java/com/zenith/launcher/HubActivity.kt
app/src/main/java/com/zenith/launcher/GlobalInputService.kt
app/src/main/java/com/zenith/launcher/core/{HardwareMonitor,PeripheralManager,NetworkAnalyzer,DevTools,NetworkTools,PermissionAuditor,ClipboardSyncService,AppLauncher,CrashGuard}.kt
app/src/main/java/com/zenith/launcher/ui/MainScreen.kt
app/src/main/java/com/zenith/launcher/ui/ZenithTheme.kt
app/src/main/java/com/zenith/launcher/ui/widgets/{StatusWidgets,TopWidgets}.kt
app/src/main/res/values/strings.xml
app/src/main/res/xml/usb_device_filter.xml
app/src/main/res/xml/accessibility_service_config.xml
```

### 1.2 版本矩阵（逐字核对，不许"差不多"）

| 项 | 期望值 | 查在哪 |
|---|---|---|
| Gradle Wrapper | `8.7` | `gradle/wrapper/gradle-wrapper.properties` 的 `distributionUrl` |
| AGP | `com.android.application` `8.5.2` | 根 `build.gradle.kts` |
| Kotlin | `org.jetbrains.kotlin.android` `2.0.21` | 根 `build.gradle.kts` |
| Compose 编译器插件 | `org.jetbrains.kotlin.plugin.compose` `2.0.21` | 根 `build.gradle.kts` |
| Compose BOM | `2024.10.01` | `app/build.gradle.kts` |
| compileSdk / targetSdk | `34` / `34` | `app/build.gradle.kts` |
| minSdk | `29` | `app/build.gradle.kts` |
| Java 源/目标 & jvmTarget | `17` / `17` / `"17"` | `app/build.gradle.kts` |
| 仓库 | `google()` `mavenCentral()` `gradlePluginPortal()`，`FAIL_ON_PROJECT_REPOS` | `settings.gradle.kts` |

### 1.3 依赖白名单（必须恰好这 9 行，多一行少一行都算不符）

```kotlin
implementation("androidx.core:core-ktx:1.13.1")
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
implementation("androidx.activity:activity-compose:1.9.2")
implementation(platform("androidx.compose:compose-bom:2024.10.01"))
implementation("androidx.compose.ui:ui")
implementation("androidx.compose.ui:ui-graphics")
implementation("androidx.compose.foundation:foundation")
implementation("androidx.compose.material3:material3")
```

出现任何第三方库（OkHttp / Retrofit / Gson / Coil / NanoHTTPD / MPAndroidChart / androidx.compose.material:material-icons-* / 任何 `.aar`）→ 立即停止。

### 1.4 32 位检查

- `defaultConfig.ndk.abiFilters` **必须且只能** 是 `listOf("armeabi-v7a")`
- 不得出现 `arm64-v8a` / `x86` / `x86_64` / `splits { abi { ... } }`
- `packaging.jniLibs` 下不得有任何 `excludes`
- `isMinifyEnabled` 必须是 `false`（release 也是）

### 1.5 Manifest 检查

- `uses-permission` 恰好 12 条，且不含 `BLUETOOTH_CONNECT` / `BLUETOOTH_SCAN` / `QUERY_ALL_PACKAGES` / `SYSTEM_ALERT_WINDOW` / `MANAGE_EXTERNAL_STORAGE`
- `MainActivity` 有 `MAIN` + `LAUNCHER` + `HOME` + `DEFAULT` + `LEANBACK_LAUNCHER`
- `HubActivity` `exported="false"`
- `ZenithVpnService` 有 `BIND_VPN_SERVICE` + `<action android:name="android.net.VpnService"/>`
- `GlobalInputService` 有 `BIND_ACCESSIBILITY_SERVICE` + `<action ...AccessibilityService/>` + `meta-data android:accessibilityservice`
- `<uses-feature android:name="android.hardware.touchscreen" android:required="false"/>`
- `<uses-feature android:name="android.software.leanback" android:required="false"/>`
- 所有 `android:name` 指向的类在 §1.1 的文件里真实存在

### 1.6 环境声明

打印：

```
java -version                      → 必须含 17
echo $JAVA_HOME                    → 必须指向 JDK 17
echo $ANDROID_HOME / $ANDROID_SDK_ROOT
ls $ANDROID_HOME/platforms         → 必须有 android-34
ls $ANDROID_HOME/build-tools       → 记录版本号
gradle --version  （若 PATH 有）
```

同时声明：`--offline` 要求本机 Gradle 缓存里已有上述 9 个依赖与 AGP/Kotlin 插件。
**若从未联网构建过，`--offline` 必然失败——这是环境问题，不是代码问题**，此时按 E2 处理，不要擅自去掉 `--offline` 去联网（需人工批准）。

---

## 2. 停止条件（硬门）

以下任一情况成立 → **不编译**，只输出差异清单：

1. §1.1 文件缺失
2. §1.2 任一版本不符
3. §1.3 依赖列表多/少/改名
4. §1.4 任一 32 位约束被改动
5. §1.5 任一 Manifest 项不符
6. 环境不满足 §1.6（尤其 JDK 不是 17、platforms 无 android-34）

输出格式只能是：

```
【不符合项】
1. <所在文件>:<行> — 期望 <X>，实际 <Y>
2. ...
【未执行的命令】
./gradlew :app:assembleDebug --offline --stacktrace --no-daemon   （未执行）
【下一步】
等待人工确认是否修正上述不符合项。
```

---

## 3. 五条红线（R1–R5）

| 编号 | 红线 | 违反示例 | 正确做法 |
|---|---|---|---|
| **R1** | **不升/不降任何版本** | 「AGP 8.5.2 报错，升到 8.6.0 试试」 | 报错原文 + 根因 + 在 8.5.2 内的修法 |
| **R2** | **不加任何依赖** | 「加个 okhttp 方便点」 | 用平台 `HttpURLConnection` / 手写解析 |
| **R3** | **不破坏 32 位** | 「加 arm64-v8a 兼容性更好」/ 加 `abiFilters += "arm64-v8a"` | 保持 `armeabi-v7a` 单 ABI |
| **R4** | **不静默改源码** | 直接 `sed -i` 改 Kotlin 然后说"已修好" | 只给 diff，末尾写「是否应用？」，等明确「应用」 |
| **R5** | **不做越界动作** | `adb install` / `cmd package set-home-activity` / `monkey` / `assembleRelease` / `git commit` / 上传 | 只跑 §4 那一条命令 |

R4 的 diff 必须是**可直接 `git apply` 的 unified diff**，带文件路径与上下文行，不允许伪代码、不允许「...」省略。

---

## 4. 唯一允许的构建命令

```bash
./gradlew :app:assembleDebug --offline --stacktrace --no-daemon
```

- 只这一条。不加 `clean`（除非人工要求）、不加 `-P` 参数、不并行开多个构建。
- 首次缺 wrapper 时，先执行一次 `gradle wrapper --gradle-version 8.7`（这是 E1 的修法，属于允许动作），再重跑上面这条。
- 保存完整输出到 `build-log.txt`（`2>&1 | tee build-log.txt`），后续报错引用行号以此为准。

---

## 5. 报错反馈格式（固定四段，不许增删）

一旦失败，按下面四段输出，**不要边猜边改**：

````
【一、错误定位】
文件：app/src/main/java/com/zenith/launcher/ui/MainScreen.kt:143
原始输出：
  e: file:///.../MainScreen.kt:143:5 Unresolved reference: LaunchableApp
错误码：E3

【二、根因】
LaunchableApp 是 core 包下的顶层 data class，不是 AppLauncher 的嵌套类；
MainScreen 里写成了 AppLauncher.LaunchableApp.fromKey(...)，限定名多了一层。

【三、补丁 Diff】
```diff
--- a/app/src/main/java/com/zenith/launcher/ui/MainScreen.kt
+++ b/app/src/main/java/com/zenith/launcher/ui/MainScreen.kt
@@ -140,7 +140,7 @@
-        val app = AppLauncher.LaunchableApp.fromKey(key, context.packageManager)
+        val app = LaunchableApp.fromKey(key, context.packageManager)
```

【四、验证方式】
重新执行 §4 命令，预期该 `Unresolved reference` 消失，
若出现新错误按新错误码重新走本格式。

以上补丁未应用，等待确认。
````

**结尾那句「以上补丁未应用，等待确认。」必须逐字出现。**
未收到「应用」二字之前，不许改任何文件。

---

## 6. 错误码表 E1–E10

| 码 | 症状（典型输出片段） | 根因 | 在红线内的修法 |
|---|---|---|---|
| **E1** | `Could not find or load main class org.gradle.wrapper.GradleWrapperMain` / `gradlew: not found` | 仓库缺 `gradlew` 与 `gradle-wrapper.jar` | 执行 `gradle wrapper --gradle-version 8.7`（需本机有 gradle）；或让 Android Studio 首次打开自动补全。**清单里写明这一步从未在本机做过** |
| **E2** | `Could not resolve all files for configuration` / `No cached version of ... available for offline mode` | `--offline` 但缓存缺依赖 | 先联网跑一次 `./gradlew :app:dependencies`（**需人工批准**），缓存齐全后再 offline。禁止改用其他仓库地址 |
| **E3** | `Unresolved reference: xxx` | 类名/包名/限定名写错，或 import 缺失 | 用 `grep -rn "class Xxx"` 定位真实声明位置，改限定名或补 import。只改必要那一行 |
| **E4** | `Type mismatch: inferred type is X but Y was expected` / `None of the following functions can be called` | 参数类型/可空性/重载不匹配 | 按签名改调用处，禁止改被调函数签名去迁就调用处（除非调用处明显错） |
| **E5** | `Smart cast to 'X' is impossible, because 'y' is a mutable property` / `Only safe (?.) or non-null asserted (!!.) calls are allowed` | 可空 var 被闭包捕获 | 先赋给局部 `val`（非空）再使用，或在入口 `?: return` 提前退出 |
| **E6** | `Cannot access 'X': it is private in 'Y'` / `Unresolved reference` 指向嵌套类 | 嵌套类访问外部实例成员（Kotlin 嵌套类无外部引用） | 把值从外部传入（`copy(...)`）或改为 `inner class`。**不许把 private 改成 public 糊过去** |
| **E7** | `This declaration is experimental and its usage must be marked` / `Opt-in required` | 用了 `@Experimental*` API | 优先换稳定 API；确需保留时在**最小作用域**加 `@OptIn`，不许全文 `@file:OptIn` 一把梭 |
| **E8** | `Manifest merger failed` / `Attribute application@xxx ... also present at` | Manifest 重复属性或 library 冲突 | 用 `tools:replace` 只替换冲突的那一个属性；不许删掉业务必需项 |
| **E9** | `AAPT: error: resource ... not found` / `resource xml/xxx not found` | 资源文件缺失或名字拼错 | 核对 `app/src/main/res/` 下真实文件名（小写、下划线），改引用处 |
| **E10** | `java.lang.OutOfMemoryError: Metaspace` / `Daemon will be stopped` / 构建机 OOM | Gradle 内存不足 | 只在 `gradle.properties` 调 `org.gradle.jvmargs`（如 `-Xmx2g`）。**不许动版本、不许加依赖** |

补充约定：

- 一次只修**一个错误码**，改完立刻重跑，不要攒着一起改。
- 同一个错误连续修 2 次仍失败 → 停下来，输出「该错误需要人工决策」，附两次 diff 与两次原始输出。
- 不许为了让编译过而删功能代码、注释掉整段、或 `@Suppress` 掉真实错误。

---

## 7. 构建成功后的验收（必须贴真实输出）

### 7.1 APK 是否存在

```bash
ls -l app/build/outputs/apk/debug/app-debug.apk
```

### 7.2 真实 32 位校验（**必须贴原始输出，不许转述**）

```bash
unzip -l app/build/outputs/apk/debug/app-debug.apk | grep -i 'lib/'
```

判定：

- 若输出为空 → 本工程没有任何 `.so`，**这是正常的**（纯 Kotlin/Java，无 NDK 代码），
  在报告里写明「无 native 库，32 位约束由 `abiFilters` 保证，无 `.so` 可校验」，**不许编造 lib 行**。
- 若出现 `lib/arm64-v8a/` 或 `lib/x86/` → **违反 R3**，立即停止并报告。

### 7.3 badging

```bash
aapt dump badging app/build/outputs/apk/debug/app-debug.apk
```

或（新 build-tools）：

```bash
$ANDROID_HOME/build-tools/<ver>/aapt2 dump badging app/build/outputs/apk/debug/app-debug.apk
```

必须从输出里核对并贴出原文行：

- `package: name='com.zenith.launcher' versionCode='1' versionName='0.1.0'`
- `sdkVersion:'29'`
- `targetSdkVersion:'34'`
- `native-code:` —— 无该行或 `'armeabi-v7a'`；出现 `arm64-v8a` 即失败
- `launchable-activity: name='com.zenith.launcher.MainActivity'`
- `uses-feature-not-required:'android.hardware.touchscreen'`
- `uses-feature-not-required:'android.software.leanback'`

### 7.4 权限清单核对

```bash
aapt dump permissions app/build/outputs/apk/debug/app-debug.apk
```

必须恰好是这 12 条（顺序可不同）：

```
android.permission.INTERNET
android.permission.ACCESS_NETWORK_STATE
android.permission.ACCESS_WIFI_STATE
android.permission.ACCESS_FINE_LOCATION
android.permission.BLUETOOTH
android.permission.BLUETOOTH_ADMIN
android.permission.READ_EXTERNAL_STORAGE      (maxSdkVersion=32)
android.permission.FOREGROUND_SERVICE
android.permission.FOREGROUND_SERVICE_DATA_SYNC
android.permission.FOREGROUND_SERVICE_SYSTEM_EXEMPTED
android.permission.POST_NOTIFICATIONS
android.permission.VIBRATE
```

出现 `BLUETOOTH_CONNECT` / `BLUETOOTH_SCAN` / `QUERY_ALL_PACKAGES` / `SYSTEM_ALERT_WINDOW` / `MANAGE_EXTERNAL_STORAGE` → 直接判失败。

### 7.5 其它核对

```bash
aapt dump xmltree app/build/outputs/apk/debug/app-debug.apk AndroidManifest.xml | grep -iE 'service|activity'
```

确认 `GlobalInputService`、`ZenithVpnService`、`ClipboardSyncService`、`HubActivity` 都在 APK 的 Manifest 里。

### 7.6 报告模板

```
【构建结果】成功 / 失败
【命令】./gradlew :app:assembleDebug --offline --stacktrace --no-daemon
【耗时】xx 秒
【APK】路径 + 字节数
【lib/ 输出】<raw>
【aapt badging 关键行】<raw>
【权限核对】12/12 通过 / 不符项列表
【警告】<原样贴，不解释、不美化>
【未做的事】未安装、未设默认桌面、未跑 monkey、未出 release
```

---

## 8. 安装与试用护栏（**只写命令，一律不执行**）

以下命令供人工在自己机器上决定是否执行。执行者**不得**代为运行。

```bash
# 安装（覆盖安装，保留数据）
adb install -r app/build/outputs/apk/debug/app-debug.apk

# 仅查看是否已安装
adb shell pm list packages | grep com.zenith.launcher

# 设为默认桌面（会改变系统行为，人工确认后再做）
adb shell cmd package set-home-activity com.zenith.launcher/.MainActivity

# 撤销默认桌面
adb shell cmd package set-home-activity com.android.launcher3/.Launcher

# 抓崩溃日志
adb logcat -b crash -d | grep com.zenith.launcher
```

护栏：

- 不许 `adb install` 之后自动 `monkey` 压测。
- 不许在未告知用户的情况下改默认桌面——**这会让用户"回不去"**。
- 不许执行 `pm clear`、`pm disable-user`、`uninstall`（清数据/停用的破坏性更强）。
- 不许把 APK 上传到任何网盘/聊天工具之外的第三方。

---

## 9. 收尾

全部做完后，最后一行必须逐字是：

```
编译阶段结束，未安装、未设默认桌面、未进入下一阶段。
```

在此之前不许写「已完成」「大功告成」之类的收尾语，也不许自行开始阶段五的任何工作。
