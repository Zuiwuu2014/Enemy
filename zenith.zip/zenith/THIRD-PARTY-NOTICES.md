# 第三方代码声明（THIRD-PARTY NOTICES）

Zenith 本体为原创代码。以下文件融合了开源项目的代码片段，按各自许可证保留声明。

## 1. aerial-tv

- 仓库：https://github.com/pengchujin/aerial-tv
- 许可证：MIT License, Copyright (c) 2026 pengchujin
- 被引用的文件：
  - `app/src/main/java/app/orchard/tv/ui/components/Pressable.kt`（按键判定）
  - `app/src/main/java/app/orchard/tv/guard/GamepadDevices.kt`（输入设备机型怪癖表）
  - `app/src/main/java/app/orchard/tv/apps/IconLibrary.kt`（仅借鉴缓存结构，未搬其网络部分）
- 在 Zenith 中的落点：
  - `app/src/main/java/com/zenith/launcher/core/KeyMap.kt`
  - `app/src/main/java/com/zenith/launcher/core/PeripheralQuirks.kt`
  - `app/src/main/java/com/zenith/launcher/core/AppIconLoader.kt`（结构参考）

```
MIT License

Copyright (c) 2026 pengchujin

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
