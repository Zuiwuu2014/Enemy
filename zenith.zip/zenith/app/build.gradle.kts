plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

/*
 * 依赖白名单（只允许这三类，禁止任何第三方 SDK / 图表库 / 图标库 / .so / .aar）：
 *   1. AndroidX（core-ktx / lifecycle / activity-compose）
 *   2. Jetpack Compose（BOM 统一版本）
 *   3. Kotlin 标准库（随 kotlin-android 插件自动引入）
 * 平台内置能力（org.json / HttpURLConnection / ServerSocket / java.security）
 * 不需要任何依赖声明。
 */
android {
    namespace = "com.zenith.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zenith.launcher"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"

        // 32 位硬约束：只出 armeabi-v7a。
        // 禁止追加 arm64-v8a / x86，禁止在 splits 里做 ABI 拆分。
        ndk {
            abiFilters += listOf("armeabi-v7a")
        }
    }

    buildTypes {
        debug {
            // 先出 debug，不混淆，方便阶段四对着堆栈改
            isMinifyEnabled = false
            isShrinkResources = false
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    // 不许误排除 32 位 .so；也不加 64 位兜底
    packaging {
        jniLibs {
            useLegacyPackaging = false
            // 不写任何 excludes：32 位 .so 一个都不许排除
        }
    }

    lint {
        // 阶段四只要求"原样列出警告"，这里不让 lint 阻断构建
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
}
