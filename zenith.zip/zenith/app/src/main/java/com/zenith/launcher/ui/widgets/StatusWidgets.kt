package com.zenith.launcher.ui.widgets

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.zenith.launcher.core.HardwareSnapshot
import com.zenith.launcher.core.LanScanResult
import com.zenith.launcher.ui.ZenithPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Unavailable {
    const val TEXT = "--"
}

/**
 * hover 提亮容器：只改背景色与线框色，不加 blur / shadow / glow。
 * 用 interactionSource 感知 hover，让有鼠标的场景可用；遥控器走 focusProvider 路径。
 */
@Composable
fun HoverBox(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()

    val bg = if (hovered) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal
    val line = if (hovered) ZenithPalette.LineHi else ZenithPalette.Line

    Box(
        modifier = modifier
            .hoverable(interaction)
            .border(1.dp, line)
            .padding(12.dp)
    ) {
        // 背景由外层 border 控制；这里只负责内容，避免双层 padding
        androidx.compose.foundation.layout.BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            content()
        }
    }
}

/**
 * 环形指标：一个圆环表示一个百分比，中心写数值。
 * 纯 Canvas，零图表库；不做任何渐变与模糊。
 */
@Composable
fun RingGauge(
    label: String,
    percent: Float?,
    modifier: Modifier = Modifier,
    ringColor: Color = ZenithPalette.TextMain,
    diameter: Dp = 84.dp
) {
    val animated by animateFloatAsState(
        targetValue = percent?.coerceIn(0f, 100f)?.let { it / 100f } ?: 0f,
        animationSpec = tween(durationMillis = 400, easing = LinearEasing),
        label = "ring"
    )

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(modifier = Modifier.size(diameter)) {
            val stroke = 6.dp.toPx()
            drawArc(
                color = ZenithPalette.Track,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Butt)
            )
            if (percent != null) {
                drawArc(
                    color = ringColor,
                    startAngle = -90f,
                    sweepAngle = 360f * animated,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = percent?.let { "${it.toInt()}%" } ?: Unavailable.TEXT,
            style = MaterialTheme.typography.titleMedium,
            color = if (percent == null) ZenithPalette.TextFaint else ZenithPalette.TextMain
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = ZenithPalette.TextDim
        )
    }
}

@Composable
fun CpuMemoryRings(
    snapshot: HardwareSnapshot?,
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        RingGauge(
            label = "CPU",
            percent = snapshot?.cpu?.totalPercent?.takeIf { it > 0f },
            diameter = 84.dp,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        RingGauge(
            label = "MEM",
            percent = snapshot?.memory?.usedPercent?.takeIf { it > 0f },
            diameter = 84.dp,
            modifier = Modifier.weight(1f)
        )
    }
}

/** 电池区：无电池时整块显示 "--" */
@Composable
fun BatteryBlock(
    snapshot: HardwareSnapshot?,
    modifier: Modifier = Modifier
) {
    val battery = snapshot?.battery
    Column(modifier = modifier) {
        Text(
            text = "BATTERY",
            style = MaterialTheme.typography.labelMedium,
            color = ZenithPalette.TextDim
        )
        Spacer(Modifier.height(6.dp))
        if (battery == null) {
            Text(
                text = Unavailable.TEXT,
                style = MaterialTheme.typography.displayMedium,
                color = ZenithPalette.TextFaint
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "无电池设备",
                style = MaterialTheme.typography.bodySmall,
                color = ZenithPalette.TextDim
            )
        } else {
            Text(
                text = "${battery.percent}%",
                style = MaterialTheme.typography.displayMedium,
                color = ZenithPalette.TextMain
            )
            Spacer(Modifier.height(2.dp))
            val state = when {
                battery.status == android.os.BatteryManager.BATTERY_STATUS_CHARGING -> "充电中"
                battery.status == android.os.BatteryManager.BATTERY_STATUS_FULL -> "已充满"
                battery.isCharging -> "充电中"
                else -> "使用电池"
            }
            val tempText = if (battery.temperatureCelsius.isNaN()) Unavailable.TEXT
            else String.format(Locale.US, "%.1f℃", battery.temperatureCelsius)
            Text(
                text = "$state  $tempText",
                style = MaterialTheme.typography.bodySmall,
                color = if (battery.temperatureCelsius.isNaN()) ZenithPalette.TextFaint
                else ZenithPalette.TextDim
            )
        }
    }
}

/**
 * 局域网探针状态：红/绿圆点 + 上次扫描时间。
 * 明确写"上次扫描时间"而不是"实时"，避免误读。
 */
@Composable
fun LanProbeStatus(
    scanResult: LanScanResult?,
    scanning: Boolean,
    modifier: Modifier = Modifier
) {
    val dotColor = when {
        scanning -> ZenithPalette.Warn
        scanResult == null -> ZenithPalette.TextFaint
        scanResult.refused -> ZenithPalette.Offline
        scanResult.hosts.isEmpty() -> ZenithPalette.Warn
        else -> ZenithPalette.Online
    }
    val dotLabel = when {
        scanning -> "扫描中"
        scanResult == null -> "未扫描"
        scanResult.refused -> "已拒绝"
        scanResult.hosts.isEmpty() -> "无设备"
        else -> "在线 ${scanResult.hosts.size}"
    }

    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(10.dp)) {
            drawCircle(color = dotColor)
        }
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                text = "局域网",
                style = MaterialTheme.typography.labelMedium,
                color = ZenithPalette.TextDim
            )
            Text(
                text = dotLabel,
                style = MaterialTheme.typography.bodySmall,
                color = if (scanResult == null || scanResult.refused) ZenithPalette.TextFaint
                else ZenithPalette.TextMain
            )
            val at = scanResult?.finishedAt
            Text(
                text = if (at == null || at == 0L) "上次扫描 --" else "上次扫描 ${fmt.format(Date(at))}",
                style = MaterialTheme.typography.labelSmall,
                color = ZenithPalette.TextFaint
            )
        }
    }
}
