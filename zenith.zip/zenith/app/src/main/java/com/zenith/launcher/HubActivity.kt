package com.zenith.launcher

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.hoverable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.zenith.launcher.core.OfflinePage
import com.zenith.launcher.ui.ZenithPalette
import com.zenith.launcher.ui.ZenithTheme

/**
 * 内置浏览器：两个 WebView，Tab 切换，不叠加全屏。
 *
 * 白名单只放 github.com 与 chat.deepseek.com 及其静态资源域。
 * 禁 file://、禁任意跳转；JS 按需开（github 需要开，deepseek 需要 DOM storage）。
 * 不持久化 Cookie / 不自动填表 / 不保存账号密码 —— 见白名单外的所有请求一律拦截。
 */
class HubActivity : ComponentActivity() {

    private val webViews = arrayOfNulls<WebView>(2)
    private var activeIndex = 0

    // ADB 状态：读系统全局开关，读不到就视为关闭（显示 OFF，不撒谎说 ON）
    private fun adbEnabled(): Boolean = runCatching {
        Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
    }.getOrDefault(false)

    /**
     * 跳开发者选项。
     * 开发者选项没开时**不强跳**（跳过去也是一片空白），改为文字引导。
     */
    private fun openDeveloperSettings() {
        val devEnabled = runCatching {
            Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        }.getOrDefault(false)

        if (!devEnabled) {
            Toast.makeText(
                this,
                "开发者选项未开启：设置 → 关于手机 → 连续点击「版本号」7 次，再回来重试",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val ok = runCatching {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }.isSuccess
        if (!ok) {
            Toast.makeText(this, "本机没有开放开发者选项页面，请在系统设置里手动找", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ZenithTheme {
                HubScreen(
                    onBack = { handleBack() },
                    onClearCookies = { clearWebData() }
                )
            }
        }
    }

    private fun handleBack() {
        val wv = webViews.getOrNull(activeIndex) ?: run { finish(); return }
        // 先退 WebView 历史，退无可退再退 Activity
        val canGoBack = runCatching { wv.canGoBack() }.getOrDefault(false)
        if (canGoBack) {
            runCatching { wv.goBack() }
        } else {
            finish()
        }
    }

    /** 清缓存 / 清 Cookie：只清本 WebView 的，不动系统 */
    private fun clearWebData() {
        runCatching {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        for (wv in webViews) {
            wv?.let {
                runCatching { it.clearCache(true) }
                runCatching { it.clearFormData() }
                runCatching { it.clearHistory() }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // 方向键映射成滚动：PC UA 页面在遥控器上必须能滚
        val wv: WebView = webViews.getOrNull(activeIndex) ?: return super.onKeyDown(keyCode, event)
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            val delta = if (keyCode == KeyEvent.KEYCODE_DPAD_UP) -1 else 1
            val canScroll = if (delta < 0) wv.canScrollVertically(-1) else wv.canScrollVertically(1)
            if (canScroll) {
                runCatching { wv.scrollBy(0, delta * 160) }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        for (wv in webViews) {
            wv?.let {
                // 不留痕：销毁时清掉 Cookie / Cache / 表单 / 历史
                runCatching { it.clearCache(true) }
                runCatching { it.clearFormData() }
                runCatching { it.clearHistory() }
                runCatching { it.stopLoading() }
                (it.parent as? ViewGroup)?.removeView(it)
                runCatching { it.destroy() }
            }
            webViews[0] = null
            webViews[1] = null
        }
        super.onDestroy()
    }

    // ---------------- Compose 界面 ----------------

    @Composable
    private fun HubScreen(
        onBack: () -> Unit,
        onClearCookies: () -> Unit
    ) {
        var tabIndex by remember { mutableIntStateOf(0) }
        var pcUa by remember { mutableStateOf(true) }
        var adbOn by remember { mutableStateOf(adbEnabled()) }

        val tabs = listOf("GitHub", "DeepSeek")

        Column(
            Modifier
                .fillMaxSize()
                .background(ZenithPalette.Void)
                .padding(12.dp)
        ) {
            // Tab 栏
            Row(verticalAlignment = Alignment.CenterVertically) {
                for ((i, name) in tabs.withIndex()) {
                    TabButton(
                        label = name,
                        selected = tabIndex == i,
                        onClick = {
                            // 再点当前标签 = 重新加载：离线兜底页的手动重试通道
                            if (tabIndex == i) runCatching { webViews[i]?.reload() }
                            tabIndex = i
                            activeIndex = i
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Spacer(Modifier.weight(1f))
                UaToggle(pcUa = pcUa) { pcUa = !pcUa }
                Spacer(Modifier.width(8.dp))
                ClearButton(onClick = onClearCookies)
                Spacer(Modifier.width(8.dp))
                AdbBadge(enabled = adbOn, onClick = { openDeveloperSettings() })
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Back=后退  Esc=退出",
                    style = MaterialTheme.typography.labelSmall,
                    color = ZenithPalette.TextFaint
                )
            }

            Spacer(Modifier.height(8.dp))

            // WebView 区域：两个独立 WebView，切换显示
            Box(Modifier.fillMaxSize().weight(1f)) {
                for (i in 0 until 2) {
                    val visible = tabIndex == i
                    if (visible || webViews[i] != null) {
                        WebPane(
                            index = i,
                            pcUa = pcUa,
                            // 不可见的 WebView 缩到 0×0，绝不叠在全屏上
                            modifier = if (visible) {
                                Modifier.fillMaxSize()
                            } else {
                                Modifier.width(0.dp).height(0.dp)
                            }
                        )
                    }
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun WebPane(
        index: Int,
        pcUa: Boolean,
        modifier: Modifier = Modifier
    ) {
        val context = LocalContext.current
        val url = if (index == 0) "https://github.com" else "https://chat.deepseek.com"

        AndroidView(
            modifier = modifier,
            factory = { ctx ->
                WebView(ctx).apply {
                    webViews[index] = this
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    settings.apply {
                        // JS / DOM storage 按需开
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        // 禁文件协议 / 禁 JS 访问文件
                        allowFileAccess = false
                        allowFileAccessFromFileURLs = false
                        allowUniversalAccessFromFileURLs = false
                        allowContentAccess = false
                        // 禁自动填表（不保存任何账号/密码）
                        saveFormData = false
                        @Suppress("DEPRECATION")
                        savePassword = false
                        // UA
                        userAgentString = if (pcUa) PC_UA else MOBILE_UA
                        // 关掉混合内容降级
                        mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        // 缓存不落盘（进程内存缓存）
                        cacheMode = WebSettings.LOAD_DEFAULT
                    }

                    // 不持久化 Cookie：每页加载完就清
                    runCatching { CookieManager.getInstance().setAcceptCookie(true) }

                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest
                        ): Boolean {
                            val target = request.url ?: return false
                            return !isAllowed(target)
                        }

                        @Deprecated("Deprecated in Java")
                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                            return !isAllowed(Uri.parse(url))
                        }

                        /** 白名单外一律拦截，包括 file:// */
                        private fun isAllowed(uri: Uri): Boolean {
                            val scheme = uri.scheme?.lowercase() ?: return false
                            if (scheme != "https") return false
                            val host = uri.host?.lowercase() ?: return false
                            return ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") }
                        }

                        /**
                         * 离线兜底页。
                         * 只有主文档失败才接管 —— request.isForMainFrame 必须为 true，
                         * 否则一张头像 404 也会把整页换掉（这是同类实现的通病）。
                         */
                        override fun onReceivedError(
                            view: WebView,
                            request: WebResourceRequest,
                            error: WebResourceError
                        ) {
                            if (!request.isForMainFrame) return
                            val code = runCatching { error.errorCode }.getOrDefault(-1)
                            val desc = runCatching { error.description?.toString() }
                                .getOrNull().orEmpty()
                            runCatching {
                                view.loadDataWithBaseURL(
                                    null,
                                    OfflinePage.html(code, desc),
                                    "text/html",
                                    "UTF-8",
                                    null
                                )
                            }
                        }

                        override fun onPageFinished(view: WebView, url: String) {
                            // 不持久化 Cookie：页面加载完立刻清掉，Session 也不留
                            runCatching {
                                CookieManager.getInstance().removeAllCookies(null)
                                CookieManager.getInstance().flush()
                            }
                        }

                        override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                            // WebView 渲染进程崩溃：不重建，只显示降级页
                            runCatching { (view.parent as? ViewGroup)?.removeView(view) }
                            webViews[index] = null
                            return true
                        }
                    }

                    webChromeClient = WebChromeClient()

                    runCatching { loadUrl(url) }
                }
            },
            update = { wv ->
                // UA 切换
                wv.settings.userAgentString = if (pcUa) PC_UA else MOBILE_UA
            }
        )
    }

    // ---------------- 小组件 ----------------

    @Composable
    private fun TabButton(label: String, selected: Boolean, onClick: () -> Unit) {
        val focused = remember { mutableStateOf(false) }
        val interaction = remember { MutableInteractionSource() }
        val hovered by interaction.collectIsHoveredAsState()
        val active = selected || hovered || focused.value

        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            color = if (active) ZenithPalette.TextMain else ZenithPalette.TextDim,
            modifier = Modifier
                .background(if (active) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal)
                .border(1.dp, if (active) ZenithPalette.LineHi else ZenithPalette.Line)
                .focusable()
                .onFocusChanged { focused.value = it.isFocused }
                .hoverable(interaction)
                .onKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyUp &&
                        (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                    ) {
                        onClick()
                        true
                    } else false
                }
                .padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }

    @Composable
    private fun UaToggle(pcUa: Boolean, onToggle: () -> Unit) {
        val focused = remember { mutableStateOf(false) }
        val interaction = remember { MutableInteractionSource() }
        val hovered by interaction.collectIsHoveredAsState()
        val active = hovered || focused.value

        Text(
            text = if (pcUa) "PC UA" else "移动 UA",
            style = MaterialTheme.typography.labelMedium,
            color = if (active) ZenithPalette.TextMain else ZenithPalette.TextDim,
            modifier = Modifier
                .background(if (active) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal)
                .border(1.dp, if (active) ZenithPalette.LineHi else ZenithPalette.Line)
                .focusable()
                .onFocusChanged { focused.value = it.isFocused }
                .hoverable(interaction)
                .onKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyUp &&
                        (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                    ) {
                        onToggle()
                        true
                    } else false
                }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }

    @Composable
    private fun ClearButton(onClick: () -> Unit) {
        val focused = remember { mutableStateOf(false) }
        val interaction = remember { MutableInteractionSource() }
        val hovered by interaction.collectIsHoveredAsState()
        val active = hovered || focused.value

        Text(
            text = "清缓存/Cookie",
            style = MaterialTheme.typography.labelMedium,
            color = if (active) ZenithPalette.TextMain else ZenithPalette.TextDim,
            modifier = Modifier
                .background(if (active) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal)
                .border(1.dp, if (active) ZenithPalette.LineHi else ZenithPalette.Line)
                .focusable()
                .onFocusChanged { focused.value = it.isFocused }
                .hoverable(interaction)
                .onKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyUp &&
                        (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                    ) {
                        onClick()
                        true
                    } else false
                }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }

    @Composable
    private fun AdbBadge(enabled: Boolean, onClick: () -> Unit) {
        val color = if (enabled) ZenithPalette.Online else ZenithPalette.TextFaint
        val focused = remember { mutableStateOf(false) }
        val interaction = remember { MutableInteractionSource() }
        val hovered by interaction.collectIsHoveredAsState()
        val active = hovered || focused.value

        Text(
            text = if (enabled) "ADB ON" else "ADB OFF",
            style = MaterialTheme.typography.labelMedium,
            color = color,
            modifier = Modifier
                .background(if (active) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal)
                .border(1.dp, if (active) ZenithPalette.LineHi else ZenithPalette.Line)
                .focusable()
                .onFocusChanged { focused.value = it.isFocused }
                .hoverable(interaction)
                .onKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyUp &&
                        (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                    ) {
                        onClick()
                        true
                    } else false
                }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }

    // ---------------- 常量 ----------------

    companion object {
        private const val PC_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        private const val MOBILE_UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

        /**
         * 白名单：只放 github.com 与 chat.deepseek.com 及其静态资源域。
         * 静态资源域允许以子域名形式出现（如 assets.github.com / cdn.deepseek.com）。
         */
        private val ALLOWED_HOSTS = listOf(
            "github.com",
            "githubusercontent.com",
            "githubassets.com",
            "github.io",
            "deepseek.com",
            "deepseekstatic.com"
        )
    }
}
