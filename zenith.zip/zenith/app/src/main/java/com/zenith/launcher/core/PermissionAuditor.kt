package com.zenith.launcher.core

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 权限的中文元数据 */
data class PermissionMeta(
    val name: String,
    /** 中文短名，例如「读取位置信息」 */
    val label: String,
    /** 中文分组，例如「位置」「相机」 */
    val group: String,
    /** 系统给的一句话解释，可能为空 */
    val description: String?,
    val isDangerous: Boolean
)

data class AppPermission(
    val name: String,
    val label: String,
    val group: String,
    val granted: Boolean,
    val isDangerous: Boolean
)

data class AuditedApp(
    val packageName: String,
    val appLabel: String,
    val isSystemApp: Boolean,
    val versionName: String?,
    val permissions: List<AppPermission>
) {
    val dangerousGranted: List<AppPermission>
        get() = permissions.filter { it.isDangerous && it.granted }

    val dangerousCount: Int get() = permissions.count { it.isDangerous }
    val grantedCount: Int get() = permissions.count { it.granted }
}

data class AuditReport(
    val apps: List<AuditedApp>,
    val generatedAt: Long,
    /** 因上限被截断 */
    val truncated: Boolean,
    val totalScanned: Int,
    val elapsedMs: Long
) {
    val dangerousTotal: Int get() = apps.sumOf { it.dangerousCount }
    val grantedTotal: Int get() = apps.sumOf { it.grantedCount }
}

/**
 * 权限审计器。
 *
 * 一条硬条款写死在代码注释里，防止后来者"顺手优化"：
 * **Android 没有面向第三方应用的「直接撤销某权限」公开 API。**
 * 能撤销运行时权限的 `grantRuntimePermission` / `revokeRuntimePermission` 在
 * `PackageManager` 上是 @hide + 需要 android.permission.GRANT_RUNTIME_PERMISSIONS
 * 签名权限，普通应用调用会被 SecurityException 拒绝，且属于非公开 API，
 * 在不同 ROM 上行为不可预期。因此本模块**只做读与跳转**，不做任何撤销动作。
 * 跳转入口固定为 Settings.ACTION_APPLICATION_DETAILS_SETTINGS，
 * UI 文案必须写明「需在系统页手动关闭」。
 */
object PermissionAuditor {

    const val MAX_APPS = 400
    const val MAX_PERMISSIONS_PER_APP = 128

    /**
     * 危险权限中文表。只覆盖与隐私/费用相关的高频项；
     * 表里没有的权限统一归入「其它」，按系统名展示，不编造中文名。
     */
    private val CATALOG: Map<String, Triple<String, String, String>> = mapOf(
        // 权限名 -> (中文短名, 中文分组, 说明)
        "android.permission.ACCESS_FINE_LOCATION" to
            Triple("精确位置", "位置", "通过 GPS/基站获取精确地理坐标"),
        "android.permission.ACCESS_COARSE_LOCATION" to
            Triple("大致位置", "位置", "通过网络获取大致地理范围"),
        "android.permission.ACCESS_BACKGROUND_LOCATION" to
            Triple("后台位置", "位置", "应用在后台时仍可获取位置"),
        "android.permission.CAMERA" to
            Triple("相机", "相机", "拍照与录像"),
        "android.permission.RECORD_AUDIO" to
            Triple("录音", "麦克风", "采集麦克风音频"),
        "android.permission.READ_CONTACTS" to
            Triple("读取联系人", "联系人", "读取通讯录条目"),
        "android.permission.WRITE_CONTACTS" to
            Triple("修改联系人", "联系人", "新增或改写通讯录条目"),
        "android.permission.READ_CALL_LOG" to
            Triple("读取通话记录", "通话", "读取通话历史"),
        "android.permission.WRITE_CALL_LOG" to
            Triple("修改通话记录", "通话", "改写通话历史"),
        "android.permission.CALL_PHONE" to
            Triple("拨打电话", "通话", "直接发起电话呼叫"),
        "android.permission.READ_PHONE_STATE" to
            Triple("读取通话状态", "通话", "读取设备号、运营商、通话状态"),
        "android.permission.READ_PHONE_NUMBERS" to
            Triple("读取本机号码", "通话", "读取本机手机号"),
        "android.permission.ANSWER_PHONE_CALLS" to
            Triple("接听电话", "通话", "自动接听来电"),
        "android.permission.SEND_SMS" to
            Triple("发送短信", "短信", "发送短信（可能产生费用）"),
        "android.permission.RECEIVE_SMS" to
            Triple("接收短信", "短信", "接收短信内容，可用于读取验证码"),
        "android.permission.READ_SMS" to
            Triple("读取短信", "短信", "读取短信历史"),
        "android.permission.READ_EXTERNAL_STORAGE" to
            Triple("读取存储", "存储", "读取共享存储中的文件"),
        "android.permission.WRITE_EXTERNAL_STORAGE" to
            Triple("写入存储", "存储", "写入或修改共享存储中的文件"),
        "android.permission.MANAGE_EXTERNAL_STORAGE" to
            Triple("全部文件访问", "存储", "访问所有文件，含其它应用目录"),
        "android.permission.BODY_SENSORS" to
            Triple("身体传感器", "传感器", "读取心率等身体数据"),
        "android.permission.ACTIVITY_RECOGNITION" to
            Triple("活动识别", "传感器", "识别走路、跑步等活动状态"),
        "android.permission.READ_CALENDAR" to
            Triple("读取日历", "日历", "读取日程安排"),
        "android.permission.WRITE_CALENDAR" to
            Triple("修改日历", "日历", "新增或改写日程"),
        "android.permission.GET_ACCOUNTS" to
            Triple("读取账户", "账户", "读取设备上的账户列表"),
        "android.permission.READ_MEDIA_IMAGES" to
            Triple("读取图片", "媒体", "读取相册图片"),
        "android.permission.READ_MEDIA_VIDEO" to
            Triple("读取视频", "媒体", "读取相册视频"),
        "android.permission.READ_MEDIA_AUDIO" to
            Triple("读取音频", "媒体", "读取音乐与录音文件"),
        "android.permission.POST_NOTIFICATIONS" to
            Triple("发送通知", "通知", "向通知栏推送消息"),
        "android.permission.SYSTEM_ALERT_WINDOW" to
            Triple("悬浮窗", "显示", "在其他应用上方绘制窗口"),
        "android.permission.REQUEST_INSTALL_PACKAGES" to
            Triple("安装应用", "安装", "请求安装未知来源的应用"),
        "android.permission.QUERY_ALL_PACKAGES" to
            Triple("查询全部应用", "应用列表", "枚举设备上安装的所有应用"),
        "android.permission.BLUETOOTH_SCAN" to
            Triple("蓝牙扫描", "蓝牙", "扫描周围蓝牙设备（Android 12+）"),
        "android.permission.BLUETOOTH_CONNECT" to
            Triple("蓝牙连接", "蓝牙", "连接已配对蓝牙设备（Android 12+）"),
        "android.permission.NEARBY_WIFI_DEVICES" to
            Triple("附近 Wi-Fi", "网络", "扫描附近 Wi-Fi（Android 13+）"),
        "android.permission.ACCESS_MEDIA_LOCATION" to
            Triple("媒体位置", "位置", "读取照片中的地理位置")
    )

    /** 供 UI 展示「哪些权限属于高危」的静态清单 */
    fun dangerousCatalog(): List<PermissionMeta> =
        CATALOG.entries
            .map { (name, v) ->
                PermissionMeta(
                    name = name,
                    label = v.first,
                    group = v.second,
                    description = v.third,
                    isDangerous = true
                )
            }
            .sortedWith(compareBy({ it.group }, { it.label }))

    /**
     * 扫描已安装应用。
     *
     * @param includeSystemApps 是否包含系统应用，默认排除（只审第三方）
     * @param onlyWithDangerous 只返回声明了危险权限的应用，减少 UI 噪音
     */
    suspend fun audit(
        context: Context,
        includeSystemApps: Boolean = false,
        onlyWithDangerous: Boolean = true
    ): AuditReport = withContext(Dispatchers.IO) {
        val begin = System.nanoTime()
        val pm = context.packageManager

        @Suppress("DEPRECATION")
        val installed: List<PackageInfo> = runCatching {
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }.getOrDefault(emptyList())

        val apps = ArrayList<AuditedApp>(installed.size)
        var scanned = 0
        var truncated = false

        for (info in installed) {
            if (apps.size >= MAX_APPS) {
                truncated = true
                break
            }
            val appInfo: ApplicationInfo = info.applicationInfo ?: continue
            scanned++

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (isSystem && !includeSystemApps) continue

            val requested = info.requestedPermissions ?: continue
            if (requested.isEmpty()) continue

            val packageName = info.packageName ?: continue
            val perms = ArrayList<AppPermission>(requested.size.coerceAtMost(MAX_PERMISSIONS_PER_APP))

            for (permName in requested) {
                if (perms.size >= MAX_PERMISSIONS_PER_APP) break
                if (permName == null) continue
                val granted = runCatching {
                    pm.checkPermission(permName, packageName) == PackageManager.PERMISSION_GRANTED
                }.getOrDefault(false)

                perms.add(toAppPermission(pm, permName, granted))
            }

            if (onlyWithDangerous && perms.none { it.isDangerous }) continue

            val label = runCatching { pm.getApplicationLabel(appInfo).toString() }
                .getOrDefault(packageName)

            apps.add(
                AuditedApp(
                    packageName = packageName,
                    appLabel = label,
                    isSystemApp = isSystem,
                    versionName = info.versionName,
                    permissions = perms.sortedWith(
                        compareByDescending<AppPermission> { it.isDangerous }
                            .thenByDescending { it.granted }
                            .thenBy { it.group }
                    )
                )
            )
        }

        AuditReport(
            apps = apps.sortedByDescending { it.dangerousGranted.size },
            generatedAt = System.currentTimeMillis(),
            truncated = truncated,
            totalScanned = scanned,
            elapsedMs = (System.nanoTime() - begin) / 1_000_000L
        )
    }

    private fun toAppPermission(pm: PackageManager, name: String, granted: Boolean): AppPermission {
        val known = CATALOG[name]
        if (known != null) {
            return AppPermission(name, known.first, known.second, granted, true)
        }
        // 表里没有：尽量用系统自带的中文权限名，拿不到就显示原始权限名，不编造
        val systemLabel = runCatching {
            @Suppress("DEPRECATION")
            pm.getPermissionInfo(name, 0).loadLabel(pm).toString()
        }.getOrNull()

        val protection = runCatching {
            @Suppress("DEPRECATION")
            pm.getPermissionInfo(name, 0).protectionLevel
        }.getOrDefault(0)

        val dangerous = (protection and android.content.pm.PermissionInfo.PROTECTION_DANGEROUS) != 0

        return AppPermission(
            name = name,
            label = systemLabel?.takeIf { it.isNotBlank() } ?: name.substringAfterLast('.'),
            group = if (dangerous) "其它高危" else "普通",
            granted = granted,
            isDangerous = dangerous
        )
    }

    /** 按权限反查应用：给定权限名，返回声明了它的应用 */
    fun reverseLookup(report: AuditReport, permissionName: String): List<AuditedApp> =
        report.apps.filter { app ->
            app.permissions.any { it.name == permissionName || it.label == permissionName }
        }

    /** 列出报告里出现过的所有权限（用于反查下拉列表） */
    fun allPermissions(report: AuditReport): List<PermissionMeta> {
        val map = LinkedHashMap<String, PermissionMeta>()
        for (app in report.apps) {
            for (p in app.permissions) {
                if (map.containsKey(p.name)) continue
                map[p.name] = PermissionMeta(
                    name = p.name,
                    label = p.label,
                    group = p.group,
                    description = null,
                    isDangerous = p.isDangerous
                )
            }
        }
        return map.values.sortedWith(compareBy({ it.group }, { it.label }))
    }

    /**
     * 导出为纯文本。仅返回字符串，不写文件、不联网。
     * 调用方可以复制到剪贴板或自己决定存哪里。
     */
    fun exportText(report: AuditReport): String {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val sb = StringBuilder(16 * 1024)
        sb.append("Zenith 权限审计报告\n")
        sb.append("生成时间：").append(format.format(Date(report.generatedAt))).append('\n')
        sb.append("扫描应用数：").append(report.totalScanned)
        sb.append("，收录 ").append(report.apps.size).append(" 个")
        if (report.truncated) sb.append("（已达上限 ${MAX_APPS}，结果被截断）")
        sb.append('\n')
        sb.append("危险权限总数：").append(report.dangerousTotal)
        sb.append("，已授予：").append(report.grantedTotal).append('\n')
        sb.append("说明：本报告仅为只读统计，未对任何应用做权限变更。\n")
        sb.append("如需关闭权限，请进入系统「应用信息 → 权限」手动操作。\n")
        sb.append('\n')

        for (app in report.apps) {
            sb.append("── ").append(app.appLabel).append(" (").append(app.packageName).append(")\n")
            sb.append("   系统应用：").append(if (app.isSystemApp) "是" else "否")
            sb.append("   版本：").append(app.versionName ?: "--").append('\n')
            if (app.permissions.isEmpty()) {
                sb.append("   （无权限记录）\n")
            } else {
                for (p in app.permissions) {
                    sb.append("   [").append(if (p.granted) "已授予" else "未授予").append("] ")
                    sb.append(p.group).append(" · ").append(p.label)
                    if (p.isDangerous) sb.append(" ★")
                    sb.append('\n')
                    sb.append("       ").append(p.name).append('\n')
                }
            }
            sb.append('\n')
        }
        return sb.toString()
    }

    /**
     * 唯一允许的"撤销"入口：跳到系统应用详情页。
     * 这是 Intent 跳转，不是 API 调用；是否真的能关，取决于系统页与 ROM 实现。
     */
    fun buildAppDetailsIntent(packageName: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    /** 跳转前先确认系统能处理，避免 ActivityNotFoundException */
    fun canOpenAppDetails(context: Context, packageName: String): Boolean = runCatching {
        context.packageManager
            .resolveActivity(buildAppDetailsIntent(packageName), PackageManager.MATCH_DEFAULT_ONLY) != null
    }.getOrDefault(false)

    /** UI 必须显示这句话，不允许改写成"已撤销"或"可一键关闭" */
    const val REVOKE_NOTE: String =
        "Android 未向第三方应用开放「直接撤销权限」的接口。此处仅提供跳转入口，需在系统页手动关闭。"
}
