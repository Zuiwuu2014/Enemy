package com.zenith.launcher.core

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.input.InputManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import android.bluetooth.BluetoothManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/** USB 设备类型，仅做粗分类，够 UI 画图标即可 */
enum class UsbDeviceKind {
    HID_MOUSE,
    HID_KEYBOARD,
    HID_OTHER,
    MASS_STORAGE,
    OTHER
}

data class UsbDeviceInfo(
    val deviceId: Int,
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val kind: UsbDeviceKind,
    /** false 表示需要走 ACTION_USB_DEVICE_ATTACHED 显式授权 */
    val hasPermission: Boolean,
    /** 无权限时系统返回 null */
    val manufacturerName: String?,
    val productName: String?,
    val serialNumber: String?
)

data class InputDeviceInfo(
    val deviceId: Int,
    val name: String,
    val sources: Int,
    val isMouse: Boolean,
    val isKeyboard: Boolean,
    val isTouchscreen: Boolean,
    val isGamepad: Boolean
)

data class StorageVolumeInfo(
    val path: String,
    val label: String?,
    val totalBytes: Long,
    val freeBytes: Long,
    val isRemovable: Boolean,
    val isMounted: Boolean
) {
    val usedBytes: Long get() = (totalBytes - freeBytes).coerceAtLeast(0L)
}

data class BluetoothInfo(
    /** 需要 BLUETOOTH 普通权限（安装即授予），不需要运行时申请 */
    val supported: Boolean,
    val enabled: Boolean,
    val adapterName: String?,
    val bondedCount: Int
)

/**
 * 外设状态快照。对外只暴露这一个不可变对象，
 * lastUpdate 供 UI 判断"多久没刷新"，避免把陈旧数据当实时。
 */
data class PeripheralSnapshot(
    val usbDevices: List<UsbDeviceInfo>,
    val inputDevices: List<InputDeviceInfo>,
    val mouseOnline: Boolean,
    val keyboardOnline: Boolean,
    val volumes: List<StorageVolumeInfo>,
    val bluetooth: BluetoothInfo?,
    val lastUpdate: Long
)

/**
 * USB / 输入设备 / 存储卷 / 蓝牙的只读枚举器。
 *
 * 版本纪律：minSdk 29（Android 10）。
 * - 蓝牙只用 BLUETOOTH + BLUETOOTH_ADMIN（normal 权限，安装即给）；
 * - 严禁引用 BLUETOOTH_CONNECT / BLUETOOTH_SCAN（API 31 才有），
 *   因此在 Android 12+ 上 adapter.name / bondedDevices 可能抛 SecurityException，
 *   已用 runCatching 降级为 null，绝不伪造数据。
 */
class PeripheralManager(context: Context) {

    private val appContext: Context = context.applicationContext
    private val usbManager: UsbManager? =
        appContext.getSystemService(Context.USB_SERVICE) as? UsbManager
    private val inputManager: InputManager? =
        appContext.getSystemService(Context.INPUT_SERVICE) as? InputManager
    private val storageManager: StorageManager? =
        appContext.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
    private val bluetoothManager: BluetoothManager? =
        appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager

    private val _snapshot = MutableStateFlow<PeripheralSnapshot?>(null)
    val snapshot: StateFlow<PeripheralSnapshot?> = _snapshot.asStateFlow()

    private val mainHandler = Handler(Looper.getMainLooper())
    private var registered = false

    /** 输入设备热插拔监听 */
    private val inputDeviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            refresh()
        }

        override fun onInputDeviceRemoved(deviceId: Int) {
            refresh()
        }

        override fun onInputDeviceChanged(deviceId: Int) {
            refresh()
        }
    }

    /** USB 授权结果 / 插拔广播 */
    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_USB_PERMISSION,
                UsbManager.ACTION_USB_DEVICE_ATTACHED,
                UsbManager.ACTION_USB_DEVICE_DETACHED -> refresh()
            }
        }
    }

    fun start() {
        if (registered) return
        registered = true
        runCatching {
            inputManager?.registerInputDeviceListener(inputDeviceListener, mainHandler)
        }
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        runCatching {
            appContext.registerReceiver(usbReceiver, filter)
        }
        refresh()
    }

    fun stop() {
        if (!registered) return
        registered = false
        runCatching { inputManager?.unregisterInputDeviceListener(inputDeviceListener) }
        runCatching { appContext.unregisterReceiver(usbReceiver) }
    }

    /** 重新枚举一次并发布快照；任意时刻只能由一个线程调用，冲突时直接返回 */
    fun refresh() {
        val usb = collectUsbDevices()
        val inputs = collectInputDevices()
        val snap = PeripheralSnapshot(
            usbDevices = usb,
            inputDevices = inputs,
            mouseOnline = inputs.any { it.isMouse } || usb.any {
                it.kind == UsbDeviceKind.HID_MOUSE && it.hasPermission
            },
            keyboardOnline = inputs.any { it.isKeyboard } || usb.any {
                it.kind == UsbDeviceKind.HID_KEYBOARD && it.hasPermission
            },
            volumes = collectVolumes(),
            bluetooth = collectBluetooth(),
            lastUpdate = System.currentTimeMillis()
        )
        _snapshot.value = snap
    }

    // ---------------- USB ----------------

    private fun collectUsbDevices(): List<UsbDeviceInfo> {
        val manager = usbManager ?: return emptyList()
        val list = runCatching { manager.deviceList.values.toList() }.getOrDefault(emptyList())
        return list.map { device ->
            val granted = runCatching { manager.hasPermission(device) }.getOrDefault(false)
            UsbDeviceInfo(
                deviceId = device.deviceId,
                deviceName = runCatching { device.deviceName }.getOrDefault(""),
                vendorId = device.vendorId,
                productId = device.productId,
                kind = classify(device),
                hasPermission = granted,
                // 未授权时这两项系统返回 null，属于预期，不是 bug
                manufacturerName = runCatching { device.manufacturerName }.getOrNull(),
                productName = runCatching { device.productName }.getOrNull(),
                serialNumber = if (granted) {
                    runCatching { device.serialNumber }.getOrNull()
                } else {
                    null
                }
            )
        }.sortedBy { it.deviceName }
    }

    private fun classify(device: UsbDevice): UsbDeviceKind {
        var isMassStorage = device.deviceClass == UsbConstants.USB_CLASS_MASS_STORAGE
        var hidMouse = false
        var hidKeyboard = false
        var hidOther = false

        for (i in 0 until device.interfaceCount) {
            val intf = runCatching { device.getInterface(i) }.getOrNull() ?: continue
            when (intf.interfaceClass) {
                UsbConstants.USB_CLASS_MASS_STORAGE -> isMassStorage = true
                UsbConstants.USB_CLASS_HID -> {
                    val boot = intf.interfaceSubclass == UsbConstants.USB_INTERFACE_SUBCLASS_BOOT
                    when {
                        boot && intf.interfaceProtocol == UsbConstants.USB_PROTOCOL_MOUSE -> hidMouse = true
                        boot && intf.interfaceProtocol == UsbConstants.USB_PROTOCOL_KEYBOARD -> hidKeyboard = true
                        else -> hidOther = true
                    }
                }
            }
        }

        return when {
            hidMouse -> UsbDeviceKind.HID_MOUSE
            hidKeyboard -> UsbDeviceKind.HID_KEYBOARD
            hidOther -> UsbDeviceKind.HID_OTHER
            isMassStorage -> UsbDeviceKind.MASS_STORAGE
            else -> UsbDeviceKind.OTHER
        }
    }

    /** 设备未授权时，用这个 PendingIntent 触发系统授权弹窗 */
    fun buildUsbPermissionIntent(device: UsbDevice): PendingIntent? {
        val manager = usbManager ?: return null
        val intent = Intent(ACTION_USB_PERMISSION).apply {
            setPackage(appContext.packageName)
            putExtra(UsbManager.EXTRA_DEVICE, device)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return runCatching {
            PendingIntent.getBroadcast(appContext, device.deviceId, intent, flags)
        }.getOrNull()
    }

    /** 主动发起授权；返回 false 表示无 USB 服务或系统拒绝 */
    fun requestPermission(device: UsbDevice): Boolean {
        val manager = usbManager ?: return false
        val pending = buildUsbPermissionIntent(device) ?: return false
        return runCatching { manager.requestPermission(device, pending); true }.getOrDefault(false)
    }

    // ---------------- 输入设备 ----------------

    private fun collectInputDevices(): List<InputDeviceInfo> {
        val manager = inputManager ?: return emptyList()
        val ids = runCatching { manager.inputDeviceIds }.getOrDefault(IntArray(0))
        val result = ArrayList<InputDeviceInfo>(ids.size)
        for (id in ids) {
            val device = runCatching { manager.getInputDevice(id) }.getOrNull() ?: continue
            val sources = device.sources
            val name = runCatching { device.name }.getOrDefault("未知设备")
            val isKeyboard = sources and SOURCE_KEYBOARD == SOURCE_KEYBOARD
            val isMouse = sources and SOURCE_MOUSE == SOURCE_MOUSE
            // 光看 sources 位不够：不少固件把内置遥控接收器也声明成 GAMEPAD，
            // 这里再过一遍 PeripheralQuirks，免得外设栏凭空多出手柄。
            val claimsGamepad = sources and SOURCE_GAMEPAD == SOURCE_GAMEPAD ||
                sources and SOURCE_JOYSTICK == SOURCE_JOYSTICK
            val isGamepad = PeripheralQuirks.isPhysicalGamepad(
                name = name,
                isVirtual = runCatching { device.isVirtual }.getOrDefault(false),
                supportsGamepad = claimsGamepad,
                vendorId = runCatching { device.vendorId }.getOrDefault(0),
                productId = runCatching { device.productId }.getOrDefault(0),
                alphabetic = isKeyboard
            )
            result.add(
                InputDeviceInfo(
                    deviceId = id,
                    name = name,
                    sources = sources,
                    isMouse = isMouse,
                    isKeyboard = isKeyboard,
                    isTouchscreen = sources and SOURCE_TOUCHSCREEN == SOURCE_TOUCHSCREEN,
                    isGamepad = isGamepad
                )
            )
        }
        return result.sortedBy { it.deviceId }
    }

    // ---------------- 存储卷 ----------------

    /**
     * 两条来源合并：
     * 1. StorageManager.storageVolumes —— 拿 label / isRemovable / 挂载状态；
     *    目录路径在 API 30+ 用 getDirectory()，API 29 无此方法，改用来源 2 反推。
     * 2. getExternalFilesDirs(null) —— 必定可用的真实路径，反推出卷根目录。
     */
    private fun collectVolumes(): List<StorageVolumeInfo> {
        val byPath = LinkedHashMap<String, StorageVolumeInfo>()

        for (root in externalRoots()) {
            val stat = statFs(root) ?: continue
            byPath[root] = StorageVolumeInfo(
                path = root,
                label = null,
                totalBytes = stat.first,
                freeBytes = stat.second,
                isRemovable = root != internalRoot(),
                isMounted = true
            )
        }

        val volumes: List<StorageVolume> = runCatching {
            storageManager?.storageVolumes ?: emptyList()
        }.getOrDefault(emptyList())

        for (volume in volumes) {
            val dirPath = volumeDirectory(volume)
            val label = runCatching { volume.getDescription(appContext) }.getOrNull()
            val state = runCatching { volume.state }.getOrNull()
            val mounted = state == Environment.MEDIA_MOUNTED
            val removable = runCatching { volume.isRemovable }.getOrDefault(false)

            if (dirPath == null) {
                if (label != null && byPath.values.none { it.label == label }) {
                    byPath["volume://${label}"] = StorageVolumeInfo(
                        path = "volume://${label}",
                        label = label,
                        totalBytes = 0L,
                        freeBytes = 0L,
                        isRemovable = removable,
                        isMounted = mounted
                    )
                }
                continue
            }

            val stat = statFs(dirPath)
            byPath[dirPath] = StorageVolumeInfo(
                path = dirPath,
                label = label,
                totalBytes = stat?.first ?: 0L,
                freeBytes = stat?.second ?: 0L,
                isRemovable = removable,
                isMounted = mounted
            )
        }

        return byPath.values.sortedBy { it.path }
    }

    /** API 30+ 才有 getDirectory()；API 29 返回 null，靠 externalRoots 兜底 */
    private fun volumeDirectory(volume: StorageVolume): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return runCatching { volume.directory?.absolutePath }.getOrNull()
    }

    private fun externalRoots(): List<String> {
        val dirs = runCatching { appContext.getExternalFilesDirs(null) }.getOrNull()
            ?: return listOfNotNull(internalRoot())
        val roots = LinkedHashSet<String>()
        for (dir in dirs) {
            if (dir == null) continue
            val path = dir.absolutePath
            val cut = path.indexOf("/Android/")
            val root = if (cut > 0) path.substring(0, cut) else path
            roots.add(root)
        }
        val primary = internalRoot()
        if (primary != null) roots.add(primary)
        return roots.toList()
    }

    private fun internalRoot(): String? =
        runCatching { Environment.getExternalStorageDirectory()?.absolutePath }.getOrNull()

    /** 返回 (总量, 可用)，读不到返回 null */
    private fun statFs(path: String): Pair<Long, Long>? {
        val file = File(path)
        if (!file.exists()) return null
        return runCatching {
            val stat = android.os.StatFs(file)
            val total = stat.blockCountLong * stat.blockSizeLong
            val free = stat.availableBlocksLong * stat.blockSizeLong
            total to free
        }.getOrNull()
    }

    // ---------------- 蓝牙 ----------------

    private fun collectBluetooth(): BluetoothInfo? {
        val manager = bluetoothManager ?: return null
        val adapter = runCatching { manager.adapter }.getOrNull() ?: return null
        // Android 12+ 上 isEnabled 仍只需 BLUETOOTH；name/bondedDevices 需要 BLUETOOTH_CONNECT，
        // 本阶段按规范不声明该权限，故捕获异常后降级为 null。
        val enabled = runCatching { adapter.isEnabled }.getOrDefault(false)
        val name = if (enabled) runCatching { adapter.name }.getOrNull() else null
        val bonded = if (enabled) {
            runCatching { adapter.bondedDevices?.size ?: 0 }.getOrDefault(0)
        } else {
            0
        }
        return BluetoothInfo(
            supported = true,
            enabled = enabled,
            adapterName = name,
            bondedCount = bonded
        )
    }

    companion object {
        const val ACTION_USB_PERMISSION = "com.zenith.launcher.USB_PERMISSION"

        private const val SOURCE_MOUSE = 0x00002002
        private const val SOURCE_KEYBOARD = 0x00000101
        private const val SOURCE_TOUCHSCREEN = 0x00001002
        private const val SOURCE_GAMEPAD = 0x00000401
        private const val SOURCE_JOYSTICK = 0x01000010
    }
}
