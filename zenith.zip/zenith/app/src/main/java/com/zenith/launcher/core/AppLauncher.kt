package com.zenith.launcher.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import java.util.Locale

/** 可启动应用。key 形如 "com.foo/.MainActivity"，用于持久化槽位 */
data class LaunchableApp(
    val packageName: String,
    val activityName: String,
    val label: String
) {
    val key: String get() = "$packageName/$activityName"

    companion object {
        fun fromKey(key: String, pm: PackageManager): LaunchableApp? {
            val idx = key.indexOf('/')
            if (idx <= 0 || idx == key.length - 1) return null
            val pkg = key.substring(0, idx)
            val cls = key.substring(idx + 1)
            val full = if (cls.startsWith(".")) pkg + cls else cls
            val label = runCatching {
                val info = pm.getActivityInfo(ComponentName(pkg, full), 0)
                pm.getApplicationLabel(pm.getApplicationInfo(info.packageName, 0)).toString()
            }.getOrDefault(pkg)
            return LaunchableApp(pkg, full, label)
        }
    }
}

/**
 * 只枚举"真的能被点开"的应用。
 *
 * 两道关：
 * 1. queryIntentActivities(MAIN/LAUNCHER) —— 受 <queries> 限制，只拿得到启动器类应用；
 * 2. 每个候选再 resolveActivity 一次 —— 防止清单里注册了但没有实际实现、或已被禁用的组件。
 * 启动前还要再判一次，因为列表可能已经过期几秒（用户刚卸载了某个应用）。
 */
object AppLauncher {

    private const val MAX_APPS = 400

    fun listLaunchable(pm: PackageManager): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = runCatching {
            pm.queryIntentActivities(intent, 0)
        }.getOrDefault(emptyList())

        val seen = HashSet<String>(resolved.size)
        val out = ArrayList<LaunchableApp>(resolved.size)

        for (info in resolved) {
            if (out.size >= MAX_APPS) break
            val activity = info.activityInfo ?: continue
            val pkg = activity.packageName ?: continue
            val name = activity.name ?: continue
            val key = "$pkg/$name"
            if (!seen.add(key)) continue

            val probe = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(pkg, name))
            val resolve = runCatching {
                pm.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY)
            }.getOrNull() ?: continue

            val label = runCatching { info.loadLabel(pm).toString() }
                .getOrDefault(pkg)

            out.add(LaunchableApp(pkg, name, label))
        }

        return out.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    /** 启动前最后一道 resolveActivity；不通过返回 false，绝不直接 startActivity 撞崩溃 */
    fun canLaunch(context: Context, app: LaunchableApp): Boolean {
        val intent = buildIntent(app) ?: return false
        val resolve = runCatching {
            context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }.getOrNull() ?: return false
        return resolve.activityInfo?.packageName == app.packageName
    }

    fun buildIntent(app: LaunchableApp): Intent? {
        if (app.packageName.isEmpty() || app.activityName.isEmpty()) return null
        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
    }

    /** 启动成功返回 null，失败返回中文原因（供 UI 显示，不弹 Toast） */
    fun launch(context: Context, app: LaunchableApp): String? {
        if (!canLaunch(context, app)) {
            return "「${app.label}」已不可用（可能被卸载或禁用）"
        }
        val intent = buildIntent(app) ?: return "「${app.label}」的启动参数无效"
        return runCatching { context.startActivity(intent); null }
            .getOrElse { "启动「${app.label}」失败：${it.javaClass.simpleName}" }
    }
}

/**
 * 底部应用位的持久化。只存 "包名/Activity" 字符串，不存图标、不存序列化对象。
 * 槽位数量限制在 5~8，超出的部分保留在数组里但不绘制，便于用户改回大数量时不丢配置。
 */
class AppSlotStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    val count: Int
        get() = prefs.getInt(KEY_COUNT, DEFAULT_COUNT).coerceIn(MIN_SLOTS, MAX_SLOTS)

    fun setCount(value: Int) {
        prefs.edit().putInt(KEY_COUNT, value.coerceIn(MIN_SLOTS, MAX_SLOTS)).apply()
    }

    fun load(): List<String?> {
        val total = MAX_SLOTS
        val out = ArrayList<String?>(total)
        for (i in 0 until total) {
            out.add(prefs.getString(slotKey(i), null))
        }
        return out
    }

    fun setSlot(index: Int, key: String?) {
        if (index !in 0 until MAX_SLOTS) return
        prefs.edit().apply {
            if (key == null) remove(slotKey(index)) else putString(slotKey(index), key)
        }.apply()
    }

    /** 首次使用时给空位填上系统能查到的前几个应用，避免一进来全是 "+" */
    fun seedIfEmpty(apps: List<LaunchableApp>) {
        if (prefs.getBoolean(KEY_SEEDED, false)) return
        if (apps.isEmpty()) return
        val editor = prefs.edit()
        for (i in 0 until MAX_SLOTS) {
            val app = apps.getOrNull(i) ?: break
            editor.putString(slotKey(i), app.key)
        }
        editor.putBoolean(KEY_SEEDED, true).apply()
    }

    private fun slotKey(index: Int) = "slot_$index"

    companion object {
        const val MIN_SLOTS = 5
        const val MAX_SLOTS = 8
        const val DEFAULT_COUNT = 6

        private const val PREFS_NAME = "zenith_slots"
        private const val KEY_COUNT = "slot_count"
        private const val KEY_SEEDED = "seeded"
    }
}
