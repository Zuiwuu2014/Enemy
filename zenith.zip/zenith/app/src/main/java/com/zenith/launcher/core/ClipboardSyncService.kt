package com.zenith.launcher.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.util.Collections
import java.util.Locale

data class ClipboardServiceState(
    val running: Boolean,
    val port: Int,
    /** 空字符串表示未设 PIN */
    val pin: String,
    val startedAt: Long,
    val lastPeer: String?,
    val lastWriteAt: Long,
    val requestCount: Int,
    val lastError: String?,
    val idleTimeoutMillis: Long
) {
    val idleSecondsLeft: Long
        get() {
            if (!running || startedAt == 0L) return 0L
            val last = if (lastWriteAt > 0L) lastWriteAt else startedAt
            val left = idleTimeoutMillis - (System.currentTimeMillis() - last)
            return if (left < 0L) 0L else left / 1000L
        }

    companion object {
        val IDLE = ClipboardServiceState(
            running = false, port = 0, pin = "", startedAt = 0L, lastPeer = null,
            lastWriteAt = 0L, requestCount = 0, lastError = null, idleTimeoutMillis = 0L
        )
    }
}

/**
 * 剪贴板同步服务 —— 手写最小 HTTP/1.1，**不使用 NanoHTTPD 或任何外部库**。
 *
 * 安全护栏（全部为"默认安全"）：
 * 1. 默认关闭，必须由用户手动启动；
 * 2. 只接受来源 IP 属于 RFC1918 私网的连接，回环(127.0.0.1)与链路本地一律拒绝；
 *    这同时意味着"同一台手机自己访问自己"也会被拒 —— 这是刻意的，避免该端口
 *    被本机恶意应用当作提权跳板；
 * 3. 可选 4~6 位数字 PIN，校验失败直接 403；
 * 4. 单条文本上限 16 KiB，请求体上限 32 KiB，请求头上限 8 KiB；
 * 5. 不写任何文件、不留历史、不缓存；进程退出即全部丢失；
 * 6. 空闲 10 分钟自动关闭；单连接读超时 5 秒；
 * 7. 明确不做 UPnP、不做端口映射、不监听公网，只在当前局域网可达。
 *
 * 已知限制（必须让用户知道，不能藏）：
 * Android 10 起，只有持有焦点的应用或默认输入法才能访问剪贴板。
 * 本服务在后台运行时调用 setPrimaryClip，系统可能静默丢弃写入。
 * 因此本功能在"App 处于前台或刚切到后台"时最可靠；后台写入失败会在回执里
 * 明确返回 "write-maybe-blocked"，绝不谎报成功。
 */
class ClipboardSyncService : Service() {

    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private var watchdogThread: Thread? = null

    @Volatile
    private var running = false

    @Volatile
    private var lastActivityAt = 0L

    private var startedAt = 0L
    private var requestCount = 0
    private var lastPeer: String? = null
    private var lastWriteAt = 0L
    private var lastError: String? = null

    private var configuredPort = DEFAULT_PORT
    private var configuredPin = ""

    private val clipboard: ClipboardManager?
        get() = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown("用户停止")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                configuredPort = intent.getIntExtra(EXTRA_PORT, DEFAULT_PORT)
                configuredPin = sanitizePin(intent.getStringExtra(EXTRA_PIN))
                if (!running) startServer()
                return START_NOT_STICKY
            }
            else -> {
                // 被系统重建时不自动恢复：剪贴板服务必须由用户显式开启
                return START_NOT_STICKY
            }
        }
    }

    // ---------------- 生命周期 ----------------

    private fun startServer() {
        if (configuredPort !in 1024..65535) {
            lastError = "端口必须在 1024~65535 之间"
            publish()
            stopSelf()
            return
        }

        val socket = try {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(configuredPort), BACKLOG)
                soTimeout = ACCEPT_TIMEOUT_MS
            }
        } catch (e: Exception) {
            lastError = "端口 ${configuredPort} 绑定失败：${e.message ?: e.javaClass.simpleName}"
            publish()
            stopSelf()
            return
        }

        serverSocket = socket
        running = true
        startedAt = System.currentTimeMillis()
        lastActivityAt = startedAt
        lastError = null
        requestCount = 0
        lastPeer = null
        lastWriteAt = 0L

        startForegroundCompat()
        publish()

        acceptThread = Thread({ acceptLoop(socket) }, "zenith-clipboard-accept").apply {
            isDaemon = true
            start()
        }
        watchdogThread = Thread({ watchdogLoop() }, "zenith-clipboard-idle").apply {
            isDaemon = true
            start()
        }
    }

    private fun acceptLoop(socket: ServerSocket) {
        while (running) {
            val client = try {
                socket.accept()
            } catch (e: SocketTimeoutException) {
                continue
            } catch (e: Exception) {
                if (running) lastError = "accept 异常：${e.message ?: e.javaClass.simpleName}"
                break
            }

            try {
                handleClient(client)
            } catch (e: Exception) {
                lastError = "处理连接失败：${e.message ?: e.javaClass.simpleName}"
            } finally {
                runCatching { client.close() }
                publish()
            }
        }
    }

    /** 空闲超时：到点直接关服务，不弹任何挽留对话框 */
    private fun watchdogLoop() {
        while (running) {
            try {
                Thread.sleep(WATCHDOG_INTERVAL_MS)
            } catch (e: InterruptedException) {
                return
            }
            if (!running) return
            val now = System.currentTimeMillis()
            val last = if (lastWriteAt > 0L) lastWriteAt else lastActivityAt
            if (now - last >= IDLE_TIMEOUT_MS) {
                shutdown("空闲 ${IDLE_TIMEOUT_MS / 60000} 分钟自动关闭")
                return
            }
        }
    }

    private fun shutdown(reason: String) {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        acceptThread?.interrupt()
        acceptThread = null
        watchdogThread?.interrupt()
        watchdogThread = null
        if (reason.isNotEmpty()) {
            android.util.Log.i(TAG, "剪贴板服务停止：$reason")
        }
        runCatching { stopForeground(true) }
        _state.value = ClipboardServiceState.IDLE.copy(lastError = lastError)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        acceptThread?.interrupt()
        watchdogThread?.interrupt()
        _state.value = ClipboardServiceState.IDLE
        super.onDestroy()
    }

    // ---------------- 单连接处理 ----------------

    private fun handleClient(client: Socket) {
        client.soTimeout = SOCKET_READ_TIMEOUT_MS
        val peerIp = client.inetAddress?.hostAddress ?: return

        // 护栏 2：只接受 RFC1918
        if (!isAllowedPeer(client.inetAddress)) {
            writeResponse(
                client.getOutputStream(), 403, "text/plain; charset=utf-8",
                "forbidden: 只接受局域网私网来源（当前 $peerIp）".toByteArray(Charsets.UTF_8)
            )
            return
        }

        lastPeer = peerIp
        lastActivityAt = System.currentTimeMillis()

        val input = BufferedInputStream(client.getInputStream())
        val request = readRequest(input) ?: run {
            writeResponse(
                client.getOutputStream(), 400, "text/plain; charset=utf-8",
                "bad request".toByteArray(Charsets.UTF_8)
            )
            return
        }

        requestCount++
        val output = BufferedOutputStream(client.getOutputStream())

        when {
            request.method == "GET" && (request.path == "/" || request.path == "/index.html") -> {
                val html = buildFormPage(peerIp).toByteArray(Charsets.UTF_8)
                writeResponse(output, 200, "text/html; charset=utf-8", html)
            }

            request.method == "GET" && request.path == "/status" -> {
                val body = buildStatusJson().toByteArray(Charsets.UTF_8)
                writeResponse(output, 200, "application/json; charset=utf-8", body)
            }

            request.method == "POST" && request.path == "/set" -> {
                handleSet(request, output, peerIp)
            }

            request.path == "/favicon.ico" -> {
                writeResponse(output, 204, "text/plain", ByteArray(0))
            }

            else -> {
                writeResponse(
                    output, 404, "text/plain; charset=utf-8",
                    "not found: ${request.path}".toByteArray(Charsets.UTF_8)
                )
            }
        }
    }

    private fun handleSet(request: HttpRequestLite, output: OutputStream, peerIp: String) {
        // 护栏 3：PIN
        if (configuredPin.isNotEmpty()) {
            val supplied = request.formValue("pin") ?: request.queryValue("pin") ?: ""
            if (supplied != configuredPin) {
                writeResponse(
                    output, 403, "text/plain; charset=utf-8",
                    "pin 校验失败".toByteArray(Charsets.UTF_8)
                )
                return
            }
        }

        val raw = request.formValue("text") ?: request.rawBody
        if (raw.isEmpty()) {
            writeResponse(
                output, 400, "text/plain; charset=utf-8",
                "空内容，未写入".toByteArray(Charsets.UTF_8)
            )
            return
        }
        if (raw.length > MAX_TEXT_LENGTH) {
            writeResponse(
                output, 413, "text/plain; charset=utf-8",
                "内容超过 ${MAX_TEXT_LENGTH} 字符上限（当前 ${raw.length}）".toByteArray(Charsets.UTF_8)
            )
            return
        }

        val manager = clipboard
        if (manager == null) {
            writeResponse(
                output, 500, "text/plain; charset=utf-8",
                "本机无剪贴板服务".toByteArray(Charsets.UTF_8)
            )
            return
        }

        val ok = runCatching {
            manager.setPrimaryClip(ClipData.newPlainText("Zenith", raw))
            true
        }.getOrDefault(false)

        lastWriteAt = System.currentTimeMillis()
        lastActivityAt = lastWriteAt

        if (!ok) {
            lastError = "setPrimaryClip 被系统拒绝"
            writeResponse(
                output, 500, "text/plain; charset=utf-8",
                "write-failed：系统拒绝写入剪贴板".toByteArray(Charsets.UTF_8)
            )
            return
        }

        // 回执：明确区分"确定写入"与"可能被系统静默拦截"
        val ack = if (appInForeground()) {
            "ok：已写入剪贴板（${raw.length} 字符，来自 $peerIp）"
        } else {
            "write-maybe-blocked：已提交写入（${raw.length} 字符，来自 $peerIp）。" +
                "Android 10+ 在应用无焦点时可能静默丢弃，请把 Zenith 切到前台后重试。"
        }
        writeResponse(output, 200, "text/plain; charset=utf-8", ack.toByteArray(Charsets.UTF_8))
    }

    /**
     * 判定"本应用是否可能持有焦点"。
     * 这里不看真正的前台状态（那要 PACKAGE_USAGE_STATS 权限，本阶段不申请），
     * 只用 ActivityManager 的 runningAppProcesses 里本进程的 importance，
     * 拿不到就按"可能被拦截"处理，宁可多提示一次也不谎报成功。
     */
    private fun appInForeground(): Boolean = runCatching {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
            ?: return false
        val procs = am.runningAppProcesses ?: return false
        val mine = procs.firstOrNull { it.pid == android.os.Process.myPid() }
            ?: return false
        mine.importance == android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
    }.getOrDefault(false)

    // ---------------- 极简 HTTP 解析 ----------------

    /**
     * 只支持方法 / 路径 / 查询串 / 少量 Header / Content-Length 定长的 Body。
     * 不支持 chunked、不支持 gzip —— 浏览器表单提交用不到，少一个解析面就少一个洞。
     */
    private fun readRequest(input: InputStream): HttpRequestLite? {
        val headerBuffer = ByteArrayOutputStream(1024)
        var matched = 0
        val terminator = byteArrayOf(13, 10, 13, 10) // \r\n\r\n

        while (true) {
            val b = input.read()
            if (b < 0) return null
            headerBuffer.write(b)
            if (b.toByte() == terminator[matched]) {
                matched++
                if (matched == terminator.size) break
            } else {
                matched = if (b.toByte() == terminator[0]) 1 else 0
            }
            if (headerBuffer.size() > MAX_HEADER_BYTES) return null
        }

        val headerText = String(headerBuffer.toByteArray(), Charsets.ISO_8859_1)
        val lines = headerText.split("\r\n").filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null

        val requestLine = lines[0].split(' ')
        if (requestLine.size < 2) return null
        val method = requestLine[0].uppercase(Locale.US)
        if (method !in ALLOWED_METHODS) return null

        val rawTarget = requestLine[1]
        if (!rawTarget.startsWith("/")) return null
        val path = rawTarget.substringBefore('?')
        val query = rawTarget.substringAfter('?', "")

        val headers = HashMap<String, String>(8)
        for (i in 1 until lines.size) {
            val idx = lines[i].indexOf(':')
            if (idx <= 0) continue
            headers[lines[i].substring(0, idx).trim().lowercase(Locale.US)] =
                lines[i].substring(idx + 1).trim()
        }

        val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
        if (contentLength < 0 || contentLength > MAX_BODY_BYTES) return null

        val bodyBytes = if (contentLength > 0) {
            val buf = ByteArray(contentLength)
            var read = 0
            while (read < contentLength) {
                val n = input.read(buf, read, contentLength - read)
                if (n <= 0) break
                read += n
            }
            buf
        } else {
            ByteArray(0)
        }

        val bodyText = String(bodyBytes, Charsets.UTF_8)
        return HttpRequestLite(method, path, query, headers, bodyText)
    }

    private fun writeResponse(
        output: OutputStream,
        status: Int,
        contentType: String,
        body: ByteArray
    ) {
        val reason = when (status) {
            200 -> "OK"
            204 -> "No Content"
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            413 -> "Payload Too Large"
            else -> "Internal Server Error"
        }
        val head = buildString(256) {
            append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n")
            append("Content-Type: ").append(contentType).append("\r\n")
            append("Content-Length: ").append(body.size).append("\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n")
            append("X-Content-Type-Options: nosniff\r\n")
            append("\r\n")
        }
        val out = BufferedOutputStream(output)
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        if (body.isNotEmpty()) out.write(body)
        out.flush()
    }

    // ---------------- 页面与状态 ----------------

    private fun buildFormPage(peerIp: String): String {
        val pinField = if (configuredPin.isEmpty()) {
            ""
        } else {
            """<label>PIN</label><input type="password" name="pin" inputmode="numeric" maxlength="6" required>"""
        }
        return """<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zenith 剪贴板</title>
<style>
html,body{background:#000;color:#ddd;font-family:ui-monospace,monospace;margin:0;padding:16px}
h1{font-size:16px;font-weight:400;letter-spacing:1px;color:#fff;margin:0 0 4px}
p.meta{font-size:12px;color:#777;margin:0 0 16px}
textarea{width:100%;box-sizing:border-box;background:#111;border:1px solid #2a2a2a;color:#eee;
padding:10px;font-family:inherit;font-size:14px;min-height:160px;outline:none}
textarea:focus{border-color:#555}
input[type=password]{background:#111;border:1px solid #2a2a2a;color:#eee;padding:8px;
font-family:inherit;width:120px;outline:none}
label{font-size:12px;color:#777;display:block;margin:12px 0 4px}
button{margin-top:12px;background:#111;border:1px solid #444;color:#eee;padding:10px 18px;
font-family:inherit;font-size:14px;cursor:pointer}
button:hover{background:#1a1a1a;border-color:#666}
pre{white-space:pre-wrap;word-break:break-all;font-size:12px;color:#888}
</style></head><body>
<h1>ZENITH · CLIPBOARD</h1>
<p class="meta">来源 $peerIp · 仅本机局域网可用 · 不保存历史</p>
<form method="POST" action="/set">
<textarea name="text" maxlength="$MAX_TEXT_LENGTH" placeholder="粘贴文本后提交" required></textarea>
$pinField
<button type="submit">写入手机剪贴板</button>
</form>
<p class="meta">单条上限 $MAX_TEXT_LENGTH 字符。写入后不保留任何副本。</p>
</body></html>"""
    }

    private fun buildStatusJson(): String {
        val s = _state.value
        return """{"running":${s.running},"port":${s.port},"pin":${s.pin.isNotEmpty()},""" +
            """"requests":${s.requestCount},"lastPeer":${jsonString(s.lastPeer)},""" +
            """"idleSecondsLeft":${s.idleSecondsLeft},"maxTextLength":$MAX_TEXT_LENGTH}"""
    }

    private fun jsonString(value: String?): String {
        if (value == null) return "null"
        val sb = StringBuilder(value.length + 2)
        sb.append('"')
        for (c in value) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append("\\u").append(
                    String.format(Locale.US, "%04x", c.code)
                ) else sb.append(c)
            }
        }
        sb.append('"')
        return sb.toString()
    }

    // ---------------- 网络判定 ----------------

    /**
     * 只放行 RFC1918。回环、链路本地、IPv6、公网全部拒绝。
     * 刻意的取舍：宁可少一个使用场景，也不要在这个端口上开一个"本机可访问"的口子。
     */
    private fun isAllowedPeer(address: InetAddress?): Boolean {
        if (address == null) return false
        if (address is Inet4Address) {
            val ip = address.hostAddress ?: return false
            if (ip.startsWith("127.")) return false
            return LanScanner.isRfc1918(ip)
        }
        return false
    }

    // ---------------- 通知 ----------------

    private fun createChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channel = NotificationChannel(
            CHANNEL_ID, "Zenith 剪贴板同步", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "剪贴板同步服务运行时显示"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun startForegroundCompat() {
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pending = openIntent?.let {
            PendingIntent.getActivity(
                this, 0, it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ClipboardSyncService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val ip = lanIpv4() ?: "--"
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Zenith · 剪贴板同步")
            .setContentText("http://$ip:$configuredPort  ·  仅局域网")
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "停止",
                    stopIntent
                ).build()
            )
        if (pending != null) builder.setContentIntent(pending)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, builder.build(), FOREGROUND_TYPE)
        } else {
            startForeground(NOTIFICATION_ID, builder.build())
        }
    }

    /** 取本机在局域网内的 IPv4，供 UI 显示"http://ip:port"给用户照着敲 */
    fun lanIpv4(): String? = runCatching {
        Collections.list(NetworkInterface.getNetworkInterfaces())
            .asSequence()
            .filter { runCatching { it.isUp }.getOrDefault(false) }
            .flatMap { nif -> Collections.list(nif.inetAddresses).asSequence() }
            .filterIsInstance<Inet4Address>()
            .mapNotNull { it.hostAddress }
            .firstOrNull { LanScanner.isRfc1918(it) }
    }.getOrNull()

    private fun sanitizePin(raw: String?): String {
        if (raw.isNullOrEmpty()) return ""
        val digits = raw.filter { it.isDigit() }
        return if (digits.length in 4..6) digits else ""
    }

    private fun publish() {
        _state.value = ClipboardServiceState(
            running = running,
            port = configuredPort,
            pin = configuredPin,
            startedAt = startedAt,
            lastPeer = lastPeer,
            lastWriteAt = lastWriteAt,
            requestCount = requestCount,
            lastError = lastError,
            idleTimeoutMillis = IDLE_TIMEOUT_MS
        )
    }

    /** 极简请求模型，只活在这一个文件里 */
    private class HttpRequestLite(
        val method: String,
        val path: String,
        val query: String,
        val headers: Map<String, String>,
        val rawBody: String
    ) {
        fun queryValue(key: String): String? {
            if (query.isEmpty()) return null
            return parseForm(query)[key]
        }

        fun formValue(key: String): String? {
            if (rawBody.isEmpty()) return null
            return parseForm(rawBody)[key]
        }

        private fun parseForm(text: String): Map<String, String> {
            val out = HashMap<String, String>(4)
            for (pair in text.split('&')) {
                if (pair.isEmpty()) continue
                val idx = pair.indexOf('=')
                if (idx < 0) continue
                val k = decodeSafe(pair.substring(0, idx))
                val v = decodeSafe(pair.substring(idx + 1))
                out[k] = v
            }
            return out
        }

        private fun decodeSafe(text: String): String =
            runCatching { URLDecoder.decode(text, "UTF-8") }.getOrDefault(text)
    }

    companion object {
        const val ACTION_START = "com.zenith.launcher.action.CLIPBOARD_START"
        const val ACTION_STOP = "com.zenith.launcher.action.CLIPBOARD_STOP"
        const val EXTRA_PORT = "port"
        const val EXTRA_PIN = "pin"

        const val DEFAULT_PORT = 8250
        const val MAX_TEXT_LENGTH = 16 * 1024
        const val MAX_BODY_BYTES = 32 * 1024
        const val MAX_HEADER_BYTES = 8 * 1024
        const val IDLE_TIMEOUT_MS = 10 * 60 * 1000L

        private const val TAG = "ZenithClip"
        private const val CHANNEL_ID = "zenith_clipboard"
        private const val NOTIFICATION_ID = 1002
        private const val BACKLOG = 8
        private const val ACCEPT_TIMEOUT_MS = 1000
        private const val SOCKET_READ_TIMEOUT_MS = 5000
        private const val WATCHDOG_INTERVAL_MS = 15_000L
        private const val FOREGROUND_TYPE = 0x00000001 // FOREGROUND_SERVICE_TYPE_DATA_SYNC

        private val ALLOWED_METHODS = setOf("GET", "POST", "HEAD")

        private val _state = MutableStateFlow(ClipboardServiceState.IDLE)
        val state: StateFlow<ClipboardServiceState> = _state.asStateFlow()

        /** UI 用：拼出给用户照着敲的地址 */
        fun buildUrl(ip: String?, port: Int): String =
            if (ip == null) "http://--:$port" else "http://$ip:$port"
    }
}
