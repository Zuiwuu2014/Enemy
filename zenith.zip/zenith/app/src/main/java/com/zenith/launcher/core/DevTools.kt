package com.zenith.launcher.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Base64
import java.util.Locale
import java.util.UUID
import java.util.zip.CRC32

// ============================ 结果模型 ============================

/** 正则捕获组。未参与匹配的组 range 为 null，value 为 null，UI 折叠显示 "(未参与)" */
data class RegexGroup(
    val index: Int,
    val name: String?,
    val start: Int?,
    val end: Int?,
    val value: String?
)

data class RegexMatch(
    /** 整体匹配区间 [start, end)，供 UI 高亮 */
    val start: Int,
    val end: Int,
    val value: String,
    val groups: List<RegexGroup>
)

data class RegexOutcome(
    val ok: Boolean,
    /** 编译期错误（语法错）或运行期错误 */
    val error: String?,
    val matches: List<RegexMatch>,
    /** 命中上限被截断 */
    val truncated: Boolean,
    val elapsedMs: Long
) {
    val matchCount: Int get() = matches.size
}

/** JSON 校验/格式化的三态结果 */
sealed class JsonOutcome {
    data class Success(
        val text: String,
        /** 顶层是对象 / 数组 / 标量 */
        val rootType: String,
        val nodeCount: Int,
        val bytes: Int
    ) : JsonOutcome()

    data class Failure(
        val message: String,
        /** 从 1 开始；0 表示无法定位 */
        val line: Int,
        val column: Int,
        /** 字符偏移，-1 表示 org.json 未给出 */
        val offset: Int
    ) : JsonOutcome()
}

/** 摘要结果。algorithm 一律大写，值一律小写十六进制 */
data class DigestResult(
    val algorithm: String,
    val hex: String,
    val byteLength: Int,
    val elapsedMs: Long
)

data class TimestampConversion(
    val epochMillis: Long,
    /** ISO8601 带时区偏移，例如 2026-11-09T20:04:20+08:00 */
    val iso8601: String,
    val zoneId: String
) {
    companion object {
        val EMPTY = TimestampConversion(0L, "", "")
    }
}

data class JwtPayload(
    val ok: Boolean,
    val error: String?,
    /** 头部原文（已解码） */
    val headerJson: String?,
    val payloadJson: String?,
    /** 固定为 false —— 本工具不验签，UI 必须显示「未验签」 */
    val signatureVerified: Boolean = false,
    val algorithm: String? = null,
    val expiresAtMillis: Long? = null
)

// ============================ 工具主体 ============================

/**
 * 纯函数工具箱：正则 / JSON / 编码 / 摘要 / 时间 / JWT。
 *
 * 纪律：
 * 1. 零第三方库 —— JSON 用平台内置 org.json，摘要用 java.security，编码用 java.util.Base64；
 * 2. 所有入口先做长度上限校验，超限直接返回错误，不做截断后继续（避免"看起来成功了"）；
 * 3. 摘要 / 大文本处理一律在 Dispatchers.Default 上跑，禁止在主线程做；
 * 4. 正则的"超时"只是协作式取消，无法真正杀死灾难性回溯线程 —— 这点已在文档里写明，
 *    真正的防线是 MAX_REGEX_INPUT 长度上限。
 */
object DevTools {

    const val MAX_REGEX_INPUT = 64 * 1024
    const val MAX_JSON_INPUT = 1024 * 1024
    const val MAX_DIGEST_INPUT = 8 * 1024 * 1024
    const val MAX_JWT_INPUT = 16 * 1024
    const val MAX_REGEX_MATCHES = 5000
    const val REGEX_TIMEOUT_MS = 1500L

    // ---------------------------- 1. 正则 ----------------------------

    /**
     * 返回匹配区间列表，供 UI 自行高亮；本函数不产出任何 Compose 组件。
     *
     * @param ignoreCase 忽略大小写
     * @param multiline  多行模式（^ $ 匹配行首行尾）
     * @param global     false 时只返回第一个匹配
     * @param dotAll     . 是否匹配换行（对应 Pattern.DOTALL）
     */
    suspend fun testRegex(
        pattern: String,
        input: String,
        ignoreCase: Boolean = false,
        multiline: Boolean = false,
        global: Boolean = true,
        dotAll: Boolean = false
    ): RegexOutcome = withContext(Dispatchers.Default) {
        val begin = System.nanoTime()

        if (pattern.isEmpty()) {
            return@withContext RegexOutcome(false, "正则为空", emptyList(), false, 0L)
        }
        if (input.length > MAX_REGEX_INPUT) {
            return@withContext RegexOutcome(
                false,
                "输入超过上限 ${MAX_REGEX_INPUT} 字符（当前 ${input.length}）",
                emptyList(), false, 0L
            )
        }

        var flags = 0
        if (ignoreCase) flags = flags or java.util.regex.Pattern.CASE_INSENSITIVE
        if (multiline) flags = flags or java.util.regex.Pattern.MULTILINE
        if (dotAll) flags = flags or java.util.regex.Pattern.DOTALL

        val regex = try {
            java.util.regex.Pattern.compile(pattern, flags)
        } catch (e: java.util.regex.PatternSyntaxException) {
            val desc = e.description ?: "语法错误"
            val pos = if (e.index >= 0) "，位置 ${e.index}" else ""
            return@withContext RegexOutcome(false, "$desc$pos", emptyList(), false, 0L)
        } catch (e: Exception) {
            return@withContext RegexOutcome(false, e.message ?: "正则编译失败", emptyList(), false, 0L)
        }

        // 协作式超时：matcher 循环内每轮检查一次是否已被取消
        val collected = ArrayList<RegexMatch>(16)
        var truncated = false

        val job = withTimeoutOrNull(REGEX_TIMEOUT_MS) {
            val matcher = regex.matcher(input)
            while (matcher.find()) {
                val groups = ArrayList<RegexGroup>(matcher.groupCount() + 1)
                for (i in 0..matcher.groupCount()) {
                    val s = if (matcher.start(i) >= 0) matcher.start(i) else null
                    val e = if (matcher.end(i) >= 0) matcher.end(i) else null
                    groups.add(
                        RegexGroup(
                            index = i,
                            name = null,
                            start = s,
                            end = e,
                            value = if (s != null && e != null) matcher.group(i) else null
                        )
                    )
                }
                collected.add(
                    RegexMatch(
                        start = matcher.start(),
                        end = matcher.end(),
                        value = matcher.group(),
                        groups = groups
                    )
                )
                if (collected.size >= MAX_REGEX_MATCHES) {
                    truncated = true
                    break
                }
                if (!global) break
                // 空匹配保护：避免 /a*/ 在零宽位置上死循环
                if (matcher.end() == matcher.start()) {
                    if (!matcher.find(matcher.start() + 1)) break
                }
            }
            true
        }

        val cost = (System.nanoTime() - begin) / 1_000_000L
        if (job == null) {
            return@withContext RegexOutcome(
                false,
                "超过 ${REGEX_TIMEOUT_MS}ms 未完成，已放弃（可能触发灾难性回溯）",
                collected, truncated, cost
            )
        }
        RegexOutcome(true, null, collected, truncated, cost)
    }

    // ---------------------------- 2. JSON ----------------------------

    /**
     * 格式化：pretty=true 输出 2 空格缩进，false 输出压缩单行。
     * 仅使用平台内置 org.json，不引 Gson / Moshi。
     * 出错位置：org.json 的异常文本形如 "Unterminated string at character 42 of {...}"，
     * 本函数从中提取字符偏移，再换算成行/列；提不到偏移时行列返回 0。
     */
    fun formatJson(text: String, pretty: Boolean = true): JsonOutcome {
        if (text.isBlank()) {
            return JsonOutcome.Failure("输入为空", 0, 0, -1)
        }
        if (text.length > MAX_JSON_INPUT) {
            return JsonOutcome.Failure(
                "输入超过上限 ${MAX_JSON_INPUT} 字符（当前 ${text.length}）", 0, 0, -1
            )
        }

        val value = try {
            JSONTokener(text).nextValue()
        } catch (e: JSONException) {
            return failureOf(e, text)
        } catch (e: Exception) {
            return JsonOutcome.Failure(e.message ?: "解析失败", 0, 0, -1)
        }

        return try {
            val rendered = when (value) {
                is JSONObject -> if (pretty) value.toString(2) else value.toString()
                is JSONArray -> if (pretty) value.toString(2) else value.toString()
                else -> value.toString()
            }
            JsonOutcome.Success(
                text = rendered,
                rootType = rootTypeName(value),
                nodeCount = countNodes(value),
                bytes = rendered.toByteArray(Charsets.UTF_8).size
            )
        } catch (e: Exception) {
            JsonOutcome.Failure("序列化失败：${e.message ?: "未知"}", 0, 0, -1)
        }
    }

    /** 只校验不输出，省一次字符串分配 */
    fun validateJson(text: String): JsonOutcome.Failure? {
        if (text.length > MAX_JSON_INPUT) {
            return JsonOutcome.Failure("输入超过上限", 0, 0, -1)
        }
        return try {
            JSONTokener(text).nextValue()
            null
        } catch (e: JSONException) {
            failureOf(e, text)
        } catch (e: Exception) {
            JsonOutcome.Failure(e.message ?: "解析失败", 0, 0, -1)
        }
    }

    private fun failureOf(e: JSONException, source: String): JsonOutcome.Failure {
        val raw = e.message ?: "JSON 语法错误"
        val offset = CHARACTER_INDEX.find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: -1
        if (offset < 0) {
            return JsonOutcome.Failure(raw, 0, 0, -1)
        }
        var line = 1
        var col = 1
        val limit = offset.coerceAtMost(source.length)
        for (i in 0 until limit) {
            if (source[i] == '\n') {
                line++
                col = 1
            } else {
                col++
            }
        }
        return JsonOutcome.Failure(raw, line, col, offset)
    }

    private fun rootTypeName(value: Any?): String = when (value) {
        is JSONObject -> "object"
        is JSONArray -> "array"
        is String -> "string"
        is Boolean -> "boolean"
        is Number -> "number"
        JSONObject.NULL -> "null"
        else -> "unknown"
    }

    private fun countNodes(value: Any?): Int = when (value) {
        is JSONObject -> {
            var n = 1
            val keys = value.keys()
            while (keys.hasNext()) {
                n += countNodes(value.opt(keys.next()))
            }
            n
        }
        is JSONArray -> {
            var n = 1
            for (i in 0 until value.length()) n += countNodes(value.opt(i))
            n
        }
        else -> 1
    }

    // ---------------------------- 3. 编码 ----------------------------

    fun base64Encode(text: String): String =
        Base64.getEncoder().encodeToString(text.toByteArray(Charsets.UTF_8))

    fun base64Decode(text: String): Result<String> = runCatching {
        val cleaned = text.filterNot { it.isWhitespace() }
        val remainder = cleaned.length % 4
        val padded = if (remainder == 0) cleaned else cleaned + "=".repeat(4 - remainder)
        String(Base64.getDecoder().decode(padded), Charsets.UTF_8)
    }

    fun urlEncode(text: String): String = runCatching {
        URLEncoder.encode(text, "UTF-8")
    }.getOrDefault("")

    fun urlDecode(text: String): Result<String> = runCatching {
        URLDecoder.decode(text, "UTF-8")
    }

    /** 转成 xxd 风格的连续小写十六进制，不带空格 */
    fun hexEncode(text: String): String {
        val bytes = text.toByteArray(Charsets.UTF_8)
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(HEX_DIGITS[v ushr 4]).append(HEX_DIGITS[v and 0x0F])
        }
        return sb.toString()
    }

    /** 允许空格 / 冒号 / 换行分隔；奇数长度直接失败 */
    fun hexDecode(text: String): Result<String> = runCatching {
        val cleaned = text.filterNot { it.isWhitespace() || it == ':' || it == '-' }
        require(cleaned.length % 2 == 0) { "十六进制长度必须为偶数（当前 ${cleaned.length}）" }
        require(cleaned.all { it in HEX_DIGITS }) { "包含非十六进制字符" }
        val out = ByteArray(cleaned.length / 2)
        for (i in out.indices) {
            val hi = HEX_DIGITS.indexOf(cleaned[i * 2])
            val lo = HEX_DIGITS.indexOf(cleaned[i * 2 + 1])
            out[i] = ((hi shl 4) or lo).toByte()
        }
        String(out, Charsets.UTF_8)
    }

    /** ROT13 只处理 A-Z / a-z，其余字符原样保留 */
    fun rot13(text: String): String {
        val sb = StringBuilder(text.length)
        for (c in text) {
            sb.append(
                when (c) {
                    in 'a'..'m', in 'A'..'M' -> c + 13
                    in 'n'..'z', in 'N'..'Z' -> c - 13
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    // ---------------------------- 4. 摘要 ----------------------------

    /** MD5 / SHA-256 / CRC32，全部在后台线程执行 */
    suspend fun digest(algorithm: String, input: String): Result<DigestResult> =
        withContext(Dispatchers.Default) {
            if (input.length > MAX_DIGEST_INPUT) {
                return@withContext Result.failure(
                    IllegalArgumentException(
                        "输入超过上限 ${MAX_DIGEST_INPUT} 字符（当前 ${input.length}）"
                    )
                )
            }
            val begin = System.nanoTime()
            val bytes = input.toByteArray(Charsets.UTF_8)
            fun cost(): Long = (System.nanoTime() - begin) / 1_000_000L

            when (algorithm.uppercase(Locale.US)) {
                "MD5" -> runCatching {
                    val md = MessageDigest.getInstance("MD5")
                    val out = md.digest(bytes)
                    DigestResult("MD5", toHex(out), out.size, cost())
                }
                "SHA-256", "SHA256" -> runCatching {
                    val md = MessageDigest.getInstance("SHA-256")
                    val out = md.digest(bytes)
                    DigestResult("SHA-256", toHex(out), out.size, cost())
                }
                "CRC32" -> runCatching {
                    val crc = CRC32()
                    crc.update(bytes)
                    val v = crc.value
                    DigestResult(
                        "CRC32",
                        String.format(Locale.US, "%08x", v),
                        4,
                        cost()
                    )
                }
                else -> Result.failure(
                    IllegalArgumentException("仅支持 MD5 / SHA-256 / CRC32，收到 $algorithm")
                )
            }
        }

    private fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(HEX_DIGITS[v ushr 4]).append(HEX_DIGITS[v and 0x0F])
        }
        return sb.toString()
    }

    // ---------------------------- 5. UUID / 口令 / 颜色 ----------------------------

    fun uuid(): String = UUID.randomUUID().toString()

    fun uuidCompact(): String = UUID.randomUUID().toString().replace("-", "")

    /**
     * 随机口令。字符集排除易混淆的 0/O/1/l/I。
     * 用 SecureRandom，不用 Random。
     */
    fun randomPassword(
        length: Int = 16,
        useUpper: Boolean = true,
        useLower: Boolean = true,
        useDigits: Boolean = true,
        useSymbols: Boolean = false
    ): String {
        val pool = StringBuilder()
        if (useUpper) pool.append("ABCDEFGHJKLMNPQRSTUVWXYZ")
        if (useLower) pool.append("abcdefghijkmnopqrstuvwxyz")
        if (useDigits) pool.append("23456789")
        if (useSymbols) pool.append("!@#\$%^&*-_=+?")
        if (pool.isEmpty()) return ""

        val safeLength = length.coerceIn(4, 128)
        val random = SecureRandom()
        val sb = StringBuilder(safeLength)
        repeat(safeLength) {
            sb.append(pool[random.nextInt(pool.length)])
        }
        return sb.toString()
    }

    /** #RRGGBB 或 #AARRGGBB -> (a, r, g, b)；失败返回 null */
    fun hexToArgb(text: String): IntArray? {
        val s = text.trim().removePrefix("#")
        if (s.length != 6 && s.length != 8) return null
        if (!s.all { it in HEX_DIGITS }) return null
        val a = if (s.length == 8) s.substring(0, 2).toInt(16) else 0xFF
        val o = if (s.length == 8) 2 else 0
        val r = s.substring(o, o + 2).toInt(16)
        val g = s.substring(o + 2, o + 4).toInt(16)
        val b = s.substring(o + 4, o + 6).toInt(16)
        return intArrayOf(a, r, g, b)
    }

    fun argbToHex(argb: IntArray): String {
        val a = argb.getOrElse(0) { 255 } and 0xFF
        val r = argb.getOrElse(1) { 0 } and 0xFF
        val g = argb.getOrElse(2) { 0 } and 0xFF
        val b = argb.getOrElse(3) { 0 } and 0xFF
        return if (a == 0xFF) {
            String.format(Locale.US, "#%02X%02X%02X", r, g, b)
        } else {
            String.format(Locale.US, "#%02X%02X%02X%02X", a, r, g, b)
        }
    }

    // ---------------------------- 6. 时间 ----------------------------

    /**
     * 时间戳(ms) -> ISO8601 带时区。
     * zone 传 null 时用系统默认时区；Asia/Shanghai 可显式传入。
     */
    fun millisToIso(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): Result<TimestampConversion> =
        runCatching {
            val instant = Instant.ofEpochMilli(epochMillis)
            val offset = instant.atZone(zone).offset
            val text = ISO_FORMAT.format(OffsetDateTime.ofInstant(instant, offset))
            TimestampConversion(epochMillis, text, zone.id)
        }

    /**
     * ISO8601 -> 时间戳。接受带偏移的（2026-11-09T20:04:20+08:00）
     * 和不带偏移的（2026-11-09T20:04:20，按当前时区解释）。
     */
    fun isoToMillis(text: String, zone: ZoneId = ZoneId.systemDefault()): Result<TimestampConversion> =
        runCatching {
            val trimmed = text.trim()
            require(trimmed.isNotEmpty()) { "输入为空" }
            val millis = try {
                // 带偏移量：2026-11-09T20:04:20+08:00 / 2026-11-09T12:04:20Z
                OffsetDateTime.parse(trimmed, DateTimeFormatter.ISO_OFFSET_DATE_TIME)
                    .toInstant()
                    .toEpochMilli()
            } catch (e: DateTimeParseException) {
                try {
                    // 带 Z 的紧凑形式
                    Instant.parse(trimmed).toEpochMilli()
                } catch (e2: DateTimeParseException) {
                    // 没有时区信息：按传入 zone 解释
                    java.time.LocalDateTime.parse(trimmed, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                        .atZone(zone)
                        .toInstant()
                        .toEpochMilli()
                }
            }
            millisToIso(millis, zone).getOrThrow()
        }

    /** 从用户输入里宽松解析：纯数字当成秒或毫秒，其他按 ISO 处理 */
    fun flexibleToMillis(text: String, zone: ZoneId = ZoneId.systemDefault()): Result<TimestampConversion> =
        runCatching {
            val trimmed = text.trim()
            require(trimmed.isNotEmpty()) { "输入为空" }
            val digits = trimmed.toLongOrNull()
            if (digits != null) {
                // 10 位当秒，13 位当毫秒，其他按毫秒
                val millis = if (trimmed.length == 10) digits * 1000L else digits
                millisToIso(millis, zone).getOrThrow()
            } else {
                isoToMillis(trimmed, zone).getOrThrow()
            }
        }

    fun nowConversion(zone: ZoneId = ZoneId.systemDefault()): TimestampConversion =
        millisToIso(System.currentTimeMillis(), zone).getOrElse { TimestampConversion.EMPTY }

    // ---------------------------- 7. JWT ----------------------------

    /**
     * 只解 payload，不验签。返回结果里 signatureVerified 恒为 false，
     * UI 必须显示「未验签」徽标 —— 这不是可选装饰，是防止误用。
     */
    fun decodeJwt(token: String): JwtPayload {
        val trimmed = token.trim()
        if (trimmed.isEmpty()) {
            return JwtPayload(false, "输入为空", null, null, algorithm = null, expiresAtMillis = null)
        }
        if (trimmed.length > MAX_JWT_INPUT) {
            return JwtPayload(false, "超过上限 $MAX_JWT_INPUT 字符", null, null)
        }
        val parts = trimmed.split('.')
        if (parts.size != 3) {
            return JwtPayload(false, "JWT 必须是三段（header.payload.signature），当前 ${parts.size} 段", null, null)
        }

        val headerText = runCatching {
            String(Base64.getUrlDecoder().decode(padBase64Url(parts[0])), Charsets.UTF_8)
        }.getOrElse {
            return JwtPayload(false, "header 不是合法 Base64URL：${it.message ?: ""}", null, null)
        }
        val payloadText = runCatching {
            String(Base64.getUrlDecoder().decode(padBase64Url(parts[1])), Charsets.UTF_8)
        }.getOrElse {
            return JwtPayload(false, "payload 不是合法 Base64URL：${it.message ?: ""}", headerText, null)
        }

        val headerObj = runCatching { JSONObject(headerText) }.getOrNull()
        val payloadObj = runCatching { JSONObject(payloadText) }.getOrNull()
        if (payloadObj == null) {
            return JwtPayload(
                false, "payload 解出来不是 JSON 对象", headerText, payloadText,
                algorithm = headerObj?.optString("alg", null), expiresAtMillis = null
            )
        }

        val exp = payloadObj.optLong("exp", -1L)
        return JwtPayload(
            ok = true,
            error = null,
            headerJson = runCatching { headerObj?.toString(2) }.getOrNull() ?: headerText,
            payloadJson = runCatching { payloadObj.toString(2) }.getOrNull() ?: payloadText,
            signatureVerified = false,
            algorithm = headerObj?.optString("alg", null),
            expiresAtMillis = if (exp > 0) exp * 1000L else null
        )
    }

    private fun padBase64Url(s: String): String {
        val remainder = s.length % 4
        if (remainder == 0) return s
        return s + "=".repeat(4 - remainder)
    }

    // ---------------------------- 常量 ----------------------------

    private const val HEX_DIGITS = "0123456789abcdef"

    private val ISO_FORMAT: DateTimeFormatter =
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US)

    private val CHARACTER_INDEX = Regex("at character (\\d+)")

    /** 供 UI 展示"当前时区偏移"用 */
    fun zoneDescription(zone: ZoneId = ZoneId.systemDefault()): String {
        val offset: ZoneOffset = zone.rules.getOffset(Instant.now())
        return "${zone.id} (UTC${offset.id.replace("Z", "+00:00")})"
    }
}
