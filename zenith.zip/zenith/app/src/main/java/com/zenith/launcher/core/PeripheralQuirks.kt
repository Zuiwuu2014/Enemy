package com.zenith.launcher.core

/**
 * 输入设备的机型怪癖过滤。
 *
 * 融合来源：pengchujin/aerial-tv（MIT License，Copyright (c) 2026 pengchujin）
 *   app/src/main/java/app/orchard/tv/guard/GamepadDevices.kt
 * 原文是给「按键过滤守卫」判断要不要拦键用的；Zenith 没有拦键守卫，
 * 但同一批假阳性会让「外设」面板把电视自带的遥控接收器、投影仪语音遥控器
 * 误报成手柄 —— 所以只搬判定表，用途换成显示准确性。
 *
 * 为什么要过滤：Android 里 `sources` 带 SOURCE_GAMEPAD 位不等于它是手柄。
 * 好几款国产固件把内置遥控接收器、虚拟键盘壳子都声明成 GAMEPAD，
 * 直接按位判断就会在外设栏里凭空多出两个"手柄"。
 */
object PeripheralQuirks {

    // Amlogic 电视的软件 eventserver 端点
    private const val AZFP0_EVENTSERVER_NAME = "eventserver-Joystick"
    private const val AZFP0_EVENTSERVER_VENDOR_ID = 0xdead
    private const val AZFP0_EVENTSERVER_PRODUCT_ID = 0xbeef

    // Amlogic 内置遥控接收器：vendor/product 都是 0x0001，sources 却含 GAMEPAD
    private const val AMLOGIC_KEYPAD_NAME = "aml_keypad"
    private const val AMLOGIC_KEYPAD_VENDOR_ID = 0x0001
    private const val AMLOGIC_KEYPAD_PRODUCT_ID = 0x0001

    // Redmi 投影仪 Lite 配的蓝牙语音遥控器
    private const val REDMI_PROJECTOR_REMOTE_NAME = "小米蓝牙语音遥控器"
    private const val XIAOMI_VENDOR_ID = 0x2717
    private const val REDMI_PROJECTOR_REMOTE_PRODUCT_ID = 0x32b8

    // 海思方案投影仪的内置输入壳子
    private const val HILISILICON_KEYBOARD_NAME = "Hi keyboard"
    private const val HILISILICON_KEYBOARD_VENDOR_ID = 0x0001
    private const val HILISILICON_KEYBOARD_PRODUCT_ID = 0x0001

    /**
     * 是否「真手柄」。
     *
     * @param name         InputDevice.getName()
     * @param isVirtual    InputDevice.isVirtual —— 虚拟设备一律不算
     * @param supportsGamepad sources 是否含 SOURCE_GAMEPAD / SOURCE_JOYSTICK
     * @param vendorId / productId  InputDevice.vendorId / productId（读不到传 0）
     * @param alphabetic   是否同时声明了 SOURCE_KEYBOARD（真键盘不是手柄）
     */
    fun isPhysicalGamepad(
        name: String?,
        isVirtual: Boolean,
        supportsGamepad: Boolean,
        vendorId: Int,
        productId: Int,
        alphabetic: Boolean = false
    ): Boolean {
        if (isVirtual) return false
        if (name.orEmpty().contains("virtual", ignoreCase = true)) return false
        if (!supportsGamepad) return false
        // 全键盘就是键盘，不管它还声明了什么键
        if (alphabetic) return false

        if (name == AZFP0_EVENTSERVER_NAME &&
            vendorId == AZFP0_EVENTSERVER_VENDOR_ID &&
            productId == AZFP0_EVENTSERVER_PRODUCT_ID
        ) return false

        if (name == AMLOGIC_KEYPAD_NAME &&
            vendorId == AMLOGIC_KEYPAD_VENDOR_ID &&
            productId == AMLOGIC_KEYPAD_PRODUCT_ID
        ) return false

        if (name == REDMI_PROJECTOR_REMOTE_NAME &&
            vendorId == XIAOMI_VENDOR_ID &&
            productId == REDMI_PROJECTOR_REMOTE_PRODUCT_ID
        ) return false

        if (name == HILISILICON_KEYBOARD_NAME &&
            vendorId == HILISILICON_KEYBOARD_VENDOR_ID &&
            productId == HILISILICON_KEYBOARD_PRODUCT_ID
        ) return false

        return true
    }

    /** 外接鼠标：外置、非虚拟、声明了 SOURCE_MOUSE。内置触摸板不算外设。 */
    fun isExternalMouse(isExternal: Boolean, isVirtual: Boolean, supportsMouse: Boolean): Boolean =
        isExternal && !isVirtual && supportsMouse
}
