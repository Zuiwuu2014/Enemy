package com.zenith.launcher.ui.widgets

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.zenith.launcher.core.NetworkSnapshot
import com.zenith.launcher.core.PeripheralSnapshot
import com.zenith.launcher.core.ZenithVpnService
import com.zenith.launcher.ui.ZenithPalette
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * 等宽大字号时钟，含秒。不接任何系统时间 Provider，直接自己每秒 tick 一次。
 * tick 用的协程挂在 Composable 的生命周期里，页面销毁自动取消。
 */
@Composable
fun MonoClock(modifier: Modifier = Modifier) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            nowMillis = System.currentTimeMillis()
        }
    }

    val text = remember(nowMillis) {
        val cal = java.util.Calendar.getInstance().apply {
            timeInMillis = nowMillis
        }
        String.format(
            Locale.US,
            "%02d:%02d:%02d",
            cal.get(java.util.Calendar.HOUR_OF_DAY),
            cal.get(java.util.Calendar.MINUTE),
            cal.get(java.util.Calendar.SECOND)
        )
    }

    Text(
        text = text,
        style = MaterialTheme.typography.displayLarge,
        color = ZenithPalette.TextMain,
        modifier = modifier
    )
}

/** 自适应单位网速：B/s → KB/s → MB/s → GB/s，B/s 以下不带小数 */
fun formatRate(bytesPerSec: Long): String {
    if (bytesPerSec < 0) return Unavailable.TEXT
    if (bytesPerSec < 1024) return "$bytesPerSec B/s"
    val units = arrayOf("KB/s", "MB/s", "GB/s", "TB/s")
    var value = bytesPerSec.toDouble() / 1024.0
    var index = 0
    while (value >= 1024.0 && index < units.size - 1) {
        value /= 1024.0
        index++
    }
    return String.format(Locale.US, "%.2f %s", value, units[index])
}

/** Wi-Fi 名 + 网速。SSID 为 null 时显示「需定位权限」或 "--"，绝不编造名字 */
@Composable
fun WifiStatusRow(
    snapshot: NetworkSnapshot?,
    modifier: Modifier = Modifier
) {
    val wifi = snapshot?.wifi
    val traffic = snapshot?.traffic

    Column(modifier = modifier) {
        Text(
            text = when {
                wifi == null -> Unavailable.TEXT
                wifi.needsLocationPermission -> "需定位权限"
                wifi.ssid == null -> if (wifi.connected) Unavailable.TEXT else "未连接"
                else -> wifi.ssid
            },
            style = MaterialTheme.typography.titleLarge,
            color = if (wifi?.ssid == null) ZenithPalette.TextDim else ZenithPalette.TextMain
        )
        Spacer(Modifier.height(4.dp))
        val down = traffic?.rxBytesPerSec ?: -1L
        val up = traffic?.txBytesPerSec ?: -1L
        Text(
            text = "↓ ${formatRate(down)}   ↑ ${formatRate(up)}",
            style = MaterialTheme.typography.bodyMedium,
            color = if (down < 0) ZenithPalette.TextFaint else ZenithPalette.TextDim
        )
    }
}

/**
 * 外设在线图标：纯矢量 Path 自绘，不引图标库。
 * 只有三种：鼠标、键盘、U 盘；不在线画成空心，在线画实心。
 */
@Composable
fun PeripheralIcons(
    snapshot: PeripheralSnapshot?,
    modifier: Modifier = Modifier
) {
    val mouseOnline = snapshot?.mouseOnline == true
    val keyboardOnline = snapshot?.keyboardOnline == true
    val storageOnline = snapshot?.volumes?.any { it.isRemovable && it.isMounted } == true

    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        MouseIcon(online = mouseOnline)
        Spacer(Modifier.width(12.dp))
        KeyboardIcon(online = keyboardOnline)
        Spacer(Modifier.width(12.dp))
        StorageIcon(online = storageOnline)
    }
}

@Composable
private fun MouseIcon(online: Boolean) {
    val color = if (online) ZenithPalette.TextMain else ZenithPalette.TextFaint
    Canvas(modifier = Modifier.size(18.dp, 26.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)

        // 外壳：圆角矩形近似
        val shell = Path().apply {
            moveTo(w * 0.5f, 2f)
            cubicTo(w * 0.15f, 2f, 2f, h * 0.25f, 2f, h * 0.5f)
            cubicTo(2f, h * 0.85f, w * 0.15f, h - 2f, w * 0.5f, h - 2f)
            cubicTo(w * 0.85f, h - 2f, w - 2f, h * 0.85f, w - 2f, h * 0.5f)
            cubicTo(w - 2f, h * 0.25f, w * 0.85f, 2f, w * 0.5f, 2f)
            close()
        }
        drawPath(shell, color = color, style = stroke)
        // 中缝
        drawLine(
            color = color,
            start = Offset(w * 0.5f, 2f),
            end = Offset(w * 0.5f, h * 0.45f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun KeyboardIcon(online: Boolean) {
    val color = if (online) ZenithPalette.TextMain else ZenithPalette.TextFaint
    Canvas(modifier = Modifier.size(30.dp, 20.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
        // 外框
        drawRoundRect(
            color = color,
            topLeft = Offset(2f, 2f),
            size = androidx.compose.ui.geometry.Size(w - 4f, h - 4f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()),
            style = stroke
        )
        // 键位（三行小点）
        val rows = 3
        val cols = 6
        val padX = 4.dp.toPx()
        val padY = 5.dp.toPx()
        val stepX = (w - 2 * padX) / (cols - 1)
        val stepY = (h - 2 * padY) / (rows - 1)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                drawCircle(
                    color = color,
                    radius = 1.dp.toPx(),
                    center = Offset(padX + c * stepX, padY + r * stepY)
                )
            }
        }
    }
}

@Composable
private fun StorageIcon(online: Boolean) {
    val color = if (online) ZenithPalette.TextMain else ZenithPalette.TextFaint
    Canvas(modifier = Modifier.size(22.dp, 18.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
        // U 盘外形：矩形 + 突出的插头
        drawRoundRect(
            color = color,
            topLeft = Offset(2f, h * 0.35f),
            size = androidx.compose.ui.geometry.Size(w * 0.62f, h * 0.6f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.dp.toPx()),
            style = stroke
        )
        drawRect(
            color = color,
            topLeft = Offset(w * 0.62f, h * 0.42f),
            size = androidx.compose.ui.geometry.Size(w * 0.36f, h * 0.16f),
            style = stroke
        )
    }
}
