package com.zenith.launcher.core

/**
 * 断网兜底页。
 *
 * 约束：不含任何外链、不引 CDN、不用 Web 字体、不用 JS。
 * 断网时它必须能只靠 WebView 自己渲染出来 —— 否则兜底页本身也加载不出来，等于没做。
 *
 * 补的是阶段三验收清单第 2 条已知限制「离线兜底页未自绘」。
 */
object OfflinePage {

    fun html(code: Int, description: String): String {
        val safe = escape(description)
        return "<!DOCTYPE html><html lang=\"zh-CN\"><head>" +
            "<meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>" +
            "html,body{margin:0;height:100%;background:#000;color:#7A7A7A;" +
            "font-family:ui-monospace,Menlo,Consolas,monospace;}" +
            ".wrap{height:100%;display:flex;flex-direction:column;align-items:center;" +
            "justify-content:center;text-align:center;padding:24px;box-sizing:border-box}" +
            ".t{color:#E8E8E8;font-size:18px;letter-spacing:.08em}" +
            ".c{color:#9B4A4A;font-size:12px;margin-top:6px}" +
            ".h{color:#3A3A3A;font-size:11px;margin-top:20px;line-height:1.9;max-width:34em}" +
            ".k{color:#555555;border:1px solid #2A2A2A;padding:1px 6px;border-radius:2px}" +
            "</style></head><body><div class=\"wrap\">" +
            "<div class=\"t\">页面加载失败</div>" +
            "<div class=\"c\">CODE $code</div>" +
            "<div class=\"h\">$safe<br><br>" +
            "内容仍在白名单内，只是这台设备此刻拿不到它。<br>" +
            "再点一次上方同标签即可重新加载；<br>" +
            "确认网络已连通，或点「清缓存/Cookie」后重来。<br><br>" +
            "<span class=\"k\">Back</span> 退出内置浏览器" +
            "</div></div></body></html>"
    }

    private fun escape(input: String): String =
        input.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
}
