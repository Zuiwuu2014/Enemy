package com.zenith.launcher.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.Process
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean

data class WifiStatus(
    val connected: Boolean,
    /** null 有两种含义：未连接，或缺少定位权限；看 needsLocationPermission 区分 */
    val ssid: String?,
    val needsLocationPermission: Boolean,
    val linkSpeedMbps: Int,
    val frequencyMhz: Int,
    val rssiDbm: Int
)

data class InterfaceInfo(
    val name: String?,
    /** Android 10 起 WifiInfo.getMacAddress() 恒为 02:00:00:00:00:00，这里走 NetworkInterface */
    val macAddress: String?,
    val ipv4: String?,
    val gateway: String?,
    val dnsServers: List<String>,
    val isWifi: Boolean
)

data class TrafficRate(
    val rxBytesPerSec: Long,
    val txBytesPerSec: Long,
    val totalRxBytes: Long,
    val totalTxBytes: Long,
    /** 本进程 uid 的累计值；-1 表示该 ROM 不提供（TrafficStats.UNSUPPORTED） */
    val uidRxBytes: Long,
    val uidTxBytes: Long,
    val sampledOverMillis: Long,
    val timestampMillis: Long
)

data class NetworkSnapshot(
    val wifi: WifiStatus,
    val iface: InterfaceInfo,
    val traffic: TrafficRate,
    val lastUpdate: Long
)

data class LanHost(
    val ip: String,
    val mac: String?,
    /** 可选离线 OUI 表命中才有值，未命中为 null，UI 显示 "--" */
    val vendor: String?,
    /** <=0 表示只从 ARP 表读到、没有实测响应 */
    val rttMs: Long
)

data class LanScanResult(
    val hosts: List<LanHost>,
    val subnet: String?,
    val startedAt: Long,
    val finishedAt: Long,
    val cancelled: Boolean,
    /** true 表示被护栏拦下，hosts 必定为空 */
    val refused: Boolean,
    val refusedReason: String?
)

/**
 * 网络信息读取。
 *
 * 三条纪律：
 * 1. SSID 需要 ACCESS_FINE_LOCATION 且用户已授权；拿不到就返回 null 并置
 *    needsLocationPermission=true，UI 显示「需定位权限」，绝不编造 WLAN 名。
 * 2. MAC 不走 WifiInfo.getMacAddress（Android 10 起恒为 02:00:00:00:00:00），
 *    改走 NetworkInterface.getHardwareAddress()，仍可能因 SELinux 返回 null。
 * 3. 局域网探针只扫本机所在 /24、只接受 RFC1918、不假设 root、可随时取消。
 */
class NetworkAnalyzer(context: Context) {

    private val appContext: Context = context.applicationContext
    private val connectivity: ConnectivityManager? =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val wifiManager: WifiManager? =
        appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val _snapshot = MutableStateFlow<NetworkSnapshot?>(null)
    val snapshot: StateFlow<NetworkSnapshot?> = _snapshot.asStateFlow()

    private var prevRx = -1L
    private var prevTx = -1L
    private var prevNanos = 0L

    fun hasLocationPermission(): Boolean =
        appContext.checkPermission(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Process.myPid(),
            Process.myUid()
        ) == PackageManager.PERMISSION_GRANTED

    fun refresh(): NetworkSnapshot {
        val snap = NetworkSnapshot(
            wifi = readWifi(),
            iface = readInterface(),
            traffic = readTraffic(),
            lastUpdate = System.currentTimeMillis()
        )
        _snapshot.value = snap
        return snap
    }

    // ---------------- Wi-Fi ----------------

    private fun readWifi(): WifiStatus {
        val manager = wifiManager
        val granted = hasLocationPermission()
        if (manager == null) {
            return WifiStatus(false, null, !granted, 0, 0, 0)
        }

        val enabled = runCatching { manager.isWifiEnabled }.getOrDefault(false)
        if (!enabled) {
            return WifiStatus(false, null, !granted, 0, 0, 0)
        }

        // getConnectionInfo() 在 API 31 标记废弃，但 API 29 无 Wi-Fi 框架替代，
        // 保持调用并抑制告警，不引入额外依赖。
        @Suppress("DEPRECATION")
        val info = runCatching { manager.connectionInfo }.getOrNull()
            ?: return WifiStatus(false, null, !granted, 0, 0, 0)

        @Suppress("DEPRECATION")
        val rawSsid = runCatching { info.ssid }.getOrNull()
        val ssid = when {
            !granted -> null
            rawSsid.isNullOrBlank() -> null
            rawSsid == UNKNOWN_SSID -> null
            else -> rawSsid.trim().trim('"')
        }

        @Suppress("DEPRECATION")
        val linkSpeed = runCatching { info.linkSpeed }.getOrDefault(0)
        @Suppress("DEPRECATION")
        val rssi = runCatching { info.rssi }.getOrDefault(0)
        val freq = runCatching { info.frequency }.getOrDefault(0)

        val connected = ssid != null || runCatching {
            manager.connectionInfo.networkId != -1
        }.getOrDefault(false)

        return WifiStatus(
            connected = connected && (ssid != null || !granted),
            ssid = ssid,
            needsLocationPermission = !granted,
            linkSpeedMbps = if (linkSpeed > 0) linkSpeed else 0,
            frequencyMhz = if (freq > 0) freq else 0,
            rssiDbm = rssi
        )
    }

    // ---------------- 接口 / IP / 网关 / DNS ----------------

    private fun readInterface(): InterfaceInfo {
        val cm = connectivity
        val network = runCatching { cm?.activeNetwork }.getOrNull()
        val lp: LinkProperties? = if (network != null) {
            runCatching { cm?.getLinkProperties(network) }.getOrNull()
        } else {
            null
        }
        val caps: NetworkCapabilities? = if (network != null) {
            runCatching { cm?.getNetworkCapabilities(network) }.getOrNull()
        } else {
            null
        }

        val ifaceName = lp?.interfaceName
        val isWifi = runCatching {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }.getOrDefault(false)

        val ipv4 = lp?.linkAddresses?.firstNotNullOfOrNull { la ->
            (la.address as? Inet4Address)?.hostAddress
        }

        val gateway = lp?.routes?.firstNotNullOfOrNull { route ->
            if (!route.isDefaultRoute) null
            else (route.gateway as? Inet4Address)?.hostAddress
        }

        val dns = lp?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()

        return InterfaceInfo(
            name = ifaceName,
            macAddress = readMacAddress(ifaceName),
            ipv4 = ipv4,
            gateway = gateway,
            dnsServers = dns,
            isWifi = isWifi
        )
    }

    /**
     * 兼容说明：
     * - Android 10 (API 29) 起，WifiInfo.getMacAddress() 对所有应用返回固定的
     *   02:00:00:00:00:00，不能再用于展示真实 MAC；
     * - 这里改用 NetworkInterface.getHardwareAddress()，它读的是内核接口层，
     *   通常仍可用；但 Android 11 起部分机型对 /sys/class/net 做了限制，
     *   可能返回 null —— 此时 UI 显示 "--"，不伪造。
     */
    private fun readMacAddress(ifaceName: String?): String? {
        if (ifaceName.isNullOrBlank()) return null
        val bytes = runCatching {
            NetworkInterface.getByName(ifaceName)?.hardwareAddress
        }.getOrNull() ?: return null
        if (bytes.isEmpty() || bytes.all { it == 0.toByte() }) return null
        return bytes.joinToString(":") { String.format("%02x", it) }
    }

    /** 枚举全部接口，给"多网卡"场景备用（有线 + 无线同时在线） */
    fun listInterfaces(): List<InterfaceInfo> {
        val all = runCatching {
            Collections.list(NetworkInterface.getNetworkInterfaces())
        }.getOrDefault(emptyList())

        return all.mapNotNull { nif ->
            val up = runCatching { nif.isUp }.getOrDefault(false)
            if (!up) return@mapNotNull null
            val ipv4 = runCatching {
                Collections.list(nif.inetAddresses)
                    .filterIsInstance<Inet4Address>()
                    .firstOrNull { !it.isLoopbackAddress }
                    ?.hostAddress
            }.getOrNull() ?: return@mapNotNull null

            InterfaceInfo(
                name = nif.name,
                macAddress = readMacAddress(nif.name),
                ipv4 = ipv4,
                gateway = null,
                dnsServers = emptyList(),
                isWifi = nif.name?.startsWith("wlan") == true
            )
        }
    }

    // ---------------- 实时速率 ----------------

    /**
     * 全局（TrafficStats.getTotalRx/TxBytes）+ 本 uid（TrafficStats.getUidRx/TxBytes）各一份差值。
     * 注意 getUid*Bytes 在部分 ROM 返回 UNSUPPORTED(-1)，此时原样返回 -1，UI 显示 "--"。
     */
    private fun readTraffic(): TrafficRate {
        val nowNanos = SystemClock.elapsedRealtimeNanos()
        val totalRx = runCatching { TrafficStats.getTotalRxBytes() }.getOrDefault(-1L)
        val totalTx = runCatching { TrafficStats.getTotalTxBytes() }.getOrDefault(-1L)
        val uid = Process.myUid()
        val uidRx = runCatching { TrafficStats.getUidRxBytes(uid) }.getOrDefault(-1L)
        val uidTx = runCatching { TrafficStats.getUidTxBytes(uid) }.getOrDefault(-1L)

        val safeRx = if (totalRx < 0) 0L else totalRx
        val safeTx = if (totalTx < 0) 0L else totalTx

        if (prevRx < 0 || prevNanos == 0L) {
            prevRx = safeRx
            prevTx = safeTx
            prevNanos = nowNanos
            return TrafficRate(0L, 0L, safeRx, safeTx, uidRx, uidTx, 0L, System.currentTimeMillis())
        }

        val elapsed = nowNanos - prevNanos
        if (elapsed <= 0L) {
            return TrafficRate(0L, 0L, safeRx, safeTx, uidRx, uidTx, 0L, System.currentTimeMillis())
        }

        val dRx = (safeRx - prevRx).coerceAtLeast(0L)
        val dTx = (safeTx - prevTx).coerceAtLeast(0L)
        val seconds = elapsed / 1_000_000_000.0

        prevRx = safeRx
        prevTx = safeTx
        prevNanos = nowNanos

        return TrafficRate(
            rxBytesPerSec = (dRx / seconds).toLong(),
            txBytesPerSec = (dTx / seconds).toLong(),
            totalRxBytes = safeRx,
            totalTxBytes = safeTx,
            uidRxBytes = uidRx,
            uidTxBytes = uidTx,
            sampledOverMillis = elapsed / 1_000_000L,
            timestampMillis = System.currentTimeMillis()
        )
    }

    // ---------------- 局域网探针 ----------------

    fun newLanScanner(): LanScanner = LanScanner(appContext)

    companion object {
        private const val UNKNOWN_SSID = "<unknown ssid>"
    }
}

/**
 * 局域网探针。
 *
 * 护栏（缺一不可）：
 * - 只扫本机 /24，掩码非 24 时裁剪到前 3 段；
 * - 目标必须全部是 RFC1918 私网地址，本机若在公网地址上直接拒绝；
 * - 不假设 root，不读需要特权的节点（/proc/net/arp 读不到就跳过）；
 * - 全流程可取消，取消后立即返回；
 * - 并发上限 32，超时 700ms，总耗时上限约 6 秒。
 */
class LanScanner(context: Context) {

    private val appContext: Context = context.applicationContext
    private val cancelled = AtomicBoolean(false)

    fun cancel() {
        cancelled.set(true)
    }

    suspend fun scan(timeoutMillis: Long = DEFAULT_TIMEOUT_MILLIS): LanScanResult =
        withContext(Dispatchers.IO) {
            cancelled.set(false)
            val startedAt = System.currentTimeMillis()
            val localIp = localIpv4()
                ?: return@withContext refused(startedAt, "未取到本机 IPv4，无法确定扫描范围")

            if (!isRfc1918(localIp)) {
                return@withContext refused(
                    startedAt,
                    "本机地址 $localIp 不属于内网，按护栏禁止扫描公网"
                )
            }

            val prefix = localIp.substringBeforeLast('.')
            val arpTable = readArpTable()
            val pingPath = detectPingBinary()
            val hosts = ArrayList<LanHost>(32)

            val targets = (1..254).map { "$prefix.$it" }.filter { it != localIp }

            targets.chunked(CONCURRENCY).forEach { chunk ->
                if (cancelled.get() || !currentCoroutineContext().isActive) return@forEach

                val batch = coroutineScope {
                    chunk.map { ip ->
                        async { probe(ip, timeoutMillis, pingPath) }
                    }.awaitAll()
                }

                batch.forEach { host ->
                    if (host == null) return@forEach
                    val arp = arpTable[host.ip]
                    hosts.add(
                        LanHost(
                            ip = host.ip,
                            mac = arp,
                            vendor = vendorOf(arp),
                            rttMs = host.rttMs
                        )
                    )
                }
            }

            // ARP 表里存在但没 ping 通的设备也补进去，rtt 记 0（UI 显示 "--"）
            val known = hosts.mapTo(HashSet()) { it.ip }
            arpTable.forEach { (ip, mac) ->
                if (!known.contains(ip) && ip.startsWith("$prefix.")) {
                    hosts.add(LanHost(ip, mac, vendorOf(mac), 0L))
                }
            }

            LanScanResult(
                hosts = hosts.sortedBy { ipToLong(it.ip) },
                subnet = "$prefix.0/24",
                startedAt = startedAt,
                finishedAt = System.currentTimeMillis(),
                cancelled = cancelled.get(),
                refused = false,
                refusedReason = null
            )
        }

    private fun refused(startedAt: Long, reason: String) = LanScanResult(
        hosts = emptyList(),
        subnet = null,
        startedAt = startedAt,
        finishedAt = System.currentTimeMillis(),
        cancelled = false,
        refused = true,
        refusedReason = reason
    )

    private data class Probe(val ip: String, val rttMs: Long)

    private fun probe(ip: String, timeoutMillis: Long, pingPath: String?): Probe? {
        if (cancelled.get()) return null
        val begin = System.nanoTime()
        val ok = if (pingPath != null) pingOnce(pingPath, ip, timeoutMillis) else reachable(ip, timeoutMillis)
        if (!ok) return null
        val costMs = (System.nanoTime() - begin) / 1_000_000L
        return Probe(ip, costMs.coerceAtLeast(1L))
    }

    private fun pingOnce(pingPath: String, ip: String, timeoutMillis: Long): Boolean {
        return runCatching {
            val waitSeconds = ((timeoutMillis + 999) / 1000).coerceAtLeast(1)
            val process = ProcessBuilder(
                pingPath, "-c", "1", "-W", waitSeconds.toString(), ip
            ).redirectErrorStream(true).start()
            val finished = process.waitFor(timeoutMillis + 500, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroy()
                return@runCatching false
            }
            process.exitValue() == 0
        }.getOrDefault(false)
    }

    private fun reachable(ip: String, timeoutMillis: Long): Boolean = runCatching {
        InetAddress.getByName(ip).isReachable(timeoutMillis.toInt())
    }.getOrDefault(false)

    private fun detectPingBinary(): String? {
        val candidates = listOf("/system/bin/ping", "/system/xbin/ping", "/vendor/bin/ping")
        return candidates.firstOrNull { File(it).canExecute() || File(it).exists() }
    }

    private fun localIpv4(): String? {
        return runCatching {
            Collections.list(NetworkInterface.getNetworkInterfaces())
                .asSequence()
                .filter { runCatching { it.isUp }.getOrDefault(false) }
                .flatMap { nif -> Collections.list(nif.inetAddresses).asSequence() }
                .filterIsInstance<Inet4Address>()
                .firstOrNull { !it.isLoopbackAddress && !it.isLinkLocalAddress }
                ?.hostAddress
        }.getOrNull()
    }

    /**
     * /proc/net/arp 列：IPaddress HWtype Flags HWaddress Mask Device
     * 非 root 下多数机型可读；读不到返回空表，不报错。
     */
    private fun readArpTable(): Map<String, String> {
        val file = File("/proc/net/arp")
        if (!file.canRead()) return emptyMap()
        val out = HashMap<String, String>(16)
        runCatching {
            file.useLines { seq ->
                seq.drop(1).forEach { line ->
                    val parts = line.trim().split(WHITESPACE)
                    if (parts.size < 4) return@forEach
                    val ip = parts[0]
                    val flags = parts[2]
                    val mac = parts[3]
                    if (flags == "0x0") return@forEach
                    if (mac == "00:00:00:00:00:00") return@forEach
                    if (!MAC_REGEX.matches(mac)) return@forEach
                    out[ip] = mac.lowercase()
                }
            }
        }
        return out
    }

    companion object {
        const val DEFAULT_TIMEOUT_MILLIS = 700L
        const val CONCURRENCY = 32

        private val WHITESPACE = Regex("\\s+")
        private val MAC_REGEX = Regex("^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$")

        /** 可选离线 OUI 表，只覆盖常见设备；未命中返回 null */
        private val OUI_TABLE = mapOf(
            "b8:27:eb" to "Raspberry Pi",
            "dc:a6:32" to "Raspberry Pi",
            "e4:5f:01" to "Raspberry Pi",
            "00:1a:11" to "Google",
            "3c:5a:b4" to "Google",
            "f4:f5:d8" to "Google",
            "24:6f:28" to "Espressif",
            "30:ae:a4" to "Espressif",
            "84:0d:8e" to "Espressif",
            "a4:cf:12" to "Espressif",
            "ac:84:c6" to "TP-Link",
            "b0:be:76" to "TP-Link",
            "50:64:2b" to "Xiaomi",
            "64:09:80" to "Xiaomi",
            "78:11:dc" to "Xiaomi",
            "00:0c:29" to "VMware",
            "00:50:56" to "VMware",
            "18:fe:34" to "Espressif",
            "ec:fa:bc" to "Espressif"
        )

        /** 可选离线 OUI 查表，只用于展示"厂商前缀"，不做设备指纹 */
        fun vendorOf(mac: String?): String? {
            if (mac == null || mac.length < 8) return null
            val prefix = mac.substring(0, 8).lowercase()
            return OUI_TABLE[prefix]
        }

        fun isRfc1918(ip: String): Boolean {
            val parts = ip.split('.')
            if (parts.size != 4) return false
            val a = parts[0].toIntOrNull() ?: return false
            val b = parts[1].toIntOrNull() ?: return false
            return when {
                a == 10 -> true
                a == 172 && b in 16..31 -> true
                a == 192 && b == 168 -> true
                else -> false
            }
        }

        fun ipToLong(ip: String): Long {
            val parts = ip.split('.')
            if (parts.size != 4) return 0L
            var value = 0L
            for (p in parts) {
                value = (value shl 8) or ((p.toIntOrNull() ?: 0).toLong() and 0xFF)
            }
            return value
        }
    }
}
