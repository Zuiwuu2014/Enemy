package com.zenith.launcher.core

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 应用图标加载器。
 *
 * 目的：补上阶段三验收清单里第 7 条已知限制「槽位应用图标没有画」。
 *
 * 约束（一条都没破）：
 *  · 不加任何依赖 —— 用的是已经在依赖清单里的 androidx.core:core-ktx 提供的
 *    `androidx.core.graphics.drawable.toBitmap`，以及 Compose 自带的 `asImageBitmap`
 *  · 不引图标库、不引图片库、不联网 —— 图标只从系统 PackageManager 取
 *  · 不落盘 —— 纯内存 LRU，退出即释放
 *
 * 思路参考：pengchujin/aerial-tv（MIT）中 `IconLibrary` 的「按包名缓存 + 失败不反复重试」结构，
 * 但那里是联网下载图库，与 Zenith「零联网」红线冲突，只借了缓存结构，没有搬它的网络部分。
 */
object AppIconLoader {

    /** 缓存上限，张。一个图标 96×96 ARGB_8888 约 36KB，64 张约 2.3MB，可控 */
    private const val MAX_ENTRIES = 64

    /**
     * 加载失败的包名 → 时间戳。失败过的短期不再试，避免每次重组都去碰 PackageManager。
     */
    private val failedAt = HashMap<String, Long>()
    private const val RETRY_AFTER_MS = 60_000L

    private val cache = object : LinkedHashMap<String, ImageBitmap>(MAX_ENTRIES, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ImageBitmap>?): Boolean =
            size > MAX_ENTRIES
    }

    /** 同步命中缓存；没有就返回 null，由调用方决定要不要异步加载 */
    @Synchronized
    fun peek(key: String): ImageBitmap? = cache[key]

    /**
     * 异步加载。key 形如 "包名/Activity 全名"。
     * 任何一个环节失败都返回 null —— 调用方画首字母兜底，绝不画假图标。
     */
    suspend fun load(context: Context, key: String, sizePx: Int): ImageBitmap? {
        peek(key)?.let { return it }

        val now = System.currentTimeMillis()
        synchronized(failedAt) {
            val at = failedAt[key]
            if (at != null && now - at < RETRY_AFTER_MS) return null
        }

        val bitmap = withContext(Dispatchers.IO) {
            runCatching { decode(context, key, sizePx) }.getOrNull()
        }

        if (bitmap == null) {
            synchronized(failedAt) { failedAt[key] = now }
            return null
        }
        synchronized(cache) { cache[key] = bitmap }
        synchronized(failedAt) { failedAt.remove(key) }
        return bitmap
    }

    private fun decode(context: Context, key: String, sizePx: Int): ImageBitmap? {
        val slash = key.indexOf('/')
        if (slash <= 0) return null
        val pkg = key.substring(0, slash)
        val cls = key.substring(slash + 1)
        if (cls.isEmpty()) return null

        val pm = context.packageManager
        val side = sizePx.coerceIn(16, 256)

        // 先试 Activity 图标（更准，能区分同包不同入口），再退到应用图标
        val drawable: Drawable? = runCatching {
            pm.getActivityIcon(ComponentName(pkg, if (cls.startsWith(".")) pkg + cls else cls))
        }.getOrNull() ?: runCatching {
            pm.getApplicationIcon(pkg)
        }.getOrNull()

        if (drawable == null) return null

        // toBitmap 会真正 rasterize，AdaptiveIconDrawable 也支持
        val bitmap: Bitmap = drawable.toBitmap(side, side, Bitmap.Config.ARGB_8888)
        if (bitmap.width <= 0 || bitmap.height <= 0) return null
        return bitmap.asImageBitmap()
    }

    /** 应用被卸载 / 换绑后清掉旧图 */
    @Synchronized
    fun evict(key: String) {
        cache.remove(key)
        synchronized(failedAt) { failedAt.remove(key) }
    }

    @Synchronized
    fun clear() {
        cache.clear()
        synchronized(failedAt) { failedAt.clear() }
    }
}
