package com.zenith.launcher.core

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.File

/**
 * 一次完整的硬件快照。所有字段不可变，UI 层直接渲染或判空显示 "--"。
 * 其中 battery 为 null 表示设备无电池（电视盒子 / 部分工控机），UI 必须显示 "--"。
 */
data class HardwareSnapshot(
    val cpu: CpuSnapshot,
    val memory: MemorySnapshot,
    val disk: DiskSnapshot,
    val battery: BatterySnapshot?,
    val lastUpdate: Long
)

data class CpuSnapshot(
    /** 0f..100f，首帧无差值时为 0f */
    val totalPercent: Float,
    /** 逐核使用率，顺序与 /proc/stat 的 cpu0..cpuN 一致 */
    val perCorePercent: List<Float>,
    /** 温度摄氏度；无传感器或无读取权限时为 null */
    val temperatureCelsius: Float?,
    val timestampMillis: Long
)

data class MemorySnapshot(
    val totalBytes: Long,
    val usedBytes: Long,
    val availableBytes: Long,
    val cachedBytes: Long,
    val swapTotalBytes: Long,
    val swapUsedBytes: Long,
    /** LowMemoryKiller 分级阈值（字节），从 0 到 -1 共 6 档；读不到时为空列表 */
    val lmkThresholdBytes: List<Long>,
    val timestampMillis: Long
) {
    val usedPercent: Float
        get() = if (totalBytes <= 0L) 0f else (usedBytes.toDouble() / totalBytes * 100.0).toFloat()
}

data class DiskSnapshot(
    val readBytesPerSecond: Long,
    val writeBytesPerSecond: Long,
    /** 两次采样的实际间隔，用于校正抖动 */
    val sampledOverMillis: Long,
    val timestampMillis: Long
)

data class BatterySnapshot(
    val percent: Int,
    val voltageMillivolts: Int,
    val temperatureCelsius: Float,
    /** BatteryManager.BATTERY_STATUS_* */
    val status: Int,
    /** BatteryManager.BATTERY_PLUGGED_* */
    val plugged: Int,
    val isCharging: Boolean,
    val timestampMillis: Long
)

/**
 * 硬件采样器。
 *
 * 三条硬约束：
 * 1. 全部采样可取消 —— 使用协程循环，绝不使用 Handler.postDelayed 自递归；
 * 2. 页面不可见自动停 —— bind(lifecycleOwner) 走 repeatOnLifecycle(STARTED)，
 *    ON_STOP 时协程被取消，循环随之退出；
 * 3. 只读 /proc 与 /sys，不申请 root，不写任何文件。
 */
class HardwareMonitor @JvmOverloads constructor(
    context: Context,
    private val intervalMillis: Long = DEFAULT_INTERVAL_MILLIS
) {

    private val appContext: Context = context.applicationContext

    private val _snapshot = MutableStateFlow<HardwareSnapshot?>(null)
    val snapshot: StateFlow<HardwareSnapshot?> = _snapshot.asStateFlow()

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val cpuSampler = CpuSampler()
    private val diskSampler = DiskSampler()

    private var bindJob: Job? = null
    private var manualJob: Job? = null

    /**
     * 绑定到 Lifecycle：STARTED 时启动，STOPPED 时自动取消。
     * 只允许绑定一次，重复调用直接返回。
     */
    fun bind(owner: LifecycleOwner) {
        if (bindJob != null) return
        bindJob = owner.lifecycleScope.launch {
            owner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                runLoop()
            }
        }
    }

    /** 手动启动（非 Lifecycle 场景），调用方必须自己负责调 stop() */
    fun start(scope: CoroutineScope) {
        if (manualJob != null) return
        manualJob = scope.launch { runLoop() }
    }

    fun unbind() {
        bindJob?.cancel()
        bindJob = null
        _running.value = false
    }

    fun stop() {
        manualJob?.cancel()
        manualJob = null
        bindJob?.cancel()
        bindJob = null
        _running.value = false
    }

    /** 单次采样，不走循环；UI 下拉刷新可调 */
    suspend fun sampleOnce(): HardwareSnapshot =
        withContext(Dispatchers.IO) { readAll() }

    private suspend fun runLoop() {
        _running.value = true
        try {
            withContext(Dispatchers.IO) {
                cpuSampler.prime()
                diskSampler.prime()
            }
            while (currentCoroutineContext().isActive) {
                val started = SystemClock.elapsedRealtime()
                val snap = withContext(Dispatchers.IO) { readAll() }
                if (currentCoroutineContext().isActive) {
                    _snapshot.value = snap
                }
                val cost = SystemClock.elapsedRealtime() - started
                val rest = (intervalMillis - cost).coerceAtLeast(MIN_INTERVAL_MILLIS)
                delay(rest)
            }
        } finally {
            _running.value = false
        }
    }

    private fun readAll(): HardwareSnapshot {
        val now = System.currentTimeMillis()
        val cpu = cpuSampler.sample().copy(temperatureCelsius = readTemperatureCelsius())
        return HardwareSnapshot(
            cpu = cpu,
            memory = readMemory(),
            disk = diskSampler.sample(),
            battery = readBattery(),
            lastUpdate = now
        )
    }

    // ---------------- 内存 ----------------

    private fun readMemory(): MemorySnapshot {
        val now = System.currentTimeMillis()
        val map = readMemInfo()
        val total = map["MemTotal"] ?: 0L
        val available = map["MemAvailable"]
            ?: ((map["MemFree"] ?: 0L) + (map["Cached"] ?: 0L) + (map["Buffers"] ?: 0L))
        val cached = (map["Cached"] ?: 0L) + (map["Buffers"] ?: 0L)
        val used = if (total > 0L) (total - available).coerceAtLeast(0L) else 0L
        val swapTotal = map["SwapTotal"] ?: 0L
        val swapFree = map["SwapFree"] ?: 0L
        return MemorySnapshot(
            totalBytes = total,
            usedBytes = used,
            availableBytes = available,
            cachedBytes = cached,
            swapTotalBytes = swapTotal,
            swapUsedBytes = (swapTotal - swapFree).coerceAtLeast(0L),
            lmkThresholdBytes = readLmkThresholds(),
            timestampMillis = now
        )
    }

    /** /proc/meminfo 单位是 kB，统一换算成字节 */
    private fun readMemInfo(): Map<String, Long> {
        val out = HashMap<String, Long>(32)
        val file = File("/proc/meminfo")
        if (!file.canRead()) return out
        runCatching {
            file.forEachLine { line ->
                val idx = line.indexOf(':')
                if (idx <= 0) return@forEachLine
                val key = line.substring(0, idx).trim()
                val rest = line.substring(idx + 1).trim()
                val num = rest.substringBefore(' ').toLongOrNull() ?: return@forEachLine
                out[key] = num * 1024L
            }
        }
        return out
    }

    /**
     * LowMemoryKiller 阈值。不同 ROM 的路径不一致，按候选列表逐个回退。
     * 值为页数（4KB/页），按逗号分隔，最后一档是 0 即"杀进程水位"。
     * 读不到（多数非 root 场景）返回空列表，UI 显示 "--"。
     */
    private fun readLmkThresholds(): List<Long> {
        val candidates = listOf(
            "/sys/module/lowmemorykiller/parameters/minfree",
            "/sys/module/lowmemorykiller/parameters/adj",
            "/sys/kernel/mm/lowmemorykiller/min_free_kbytes"
        )
        for (path in candidates) {
            val f = File(path)
            if (!f.canRead()) continue
            val text = runCatching { f.readText().trim() }.getOrNull() ?: continue
            if (text.isEmpty()) continue
            if (path.endsWith("min_free_kbytes")) {
                val kb = text.toLongOrNull() ?: continue
                return listOf(kb * 1024L)
            }
            if (!path.endsWith("minfree")) continue
            val pages = text.split(',').mapNotNull { it.trim().toLongOrNull() }
            if (pages.isEmpty()) continue
            return pages.map { it * PAGE_SIZE_BYTES }
        }
        return emptyList()
    }

    // ---------------- 电池 ----------------

    /**
     * 无电池设备（电视盒子 / 无 UPS 的工控机）会拿不到 ACTION_BATTERY_CHANGED 粘性广播，
     * 此时返回 null，UI 层按约定显示 "--"，禁止猜测数值。
     */
    private fun readBattery(): BatterySnapshot? {
        val intent: Intent? = runCatching {
            appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull() ?: return null

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return null

        val percent = (level * 100.0 / scale).toInt().coerceIn(0, 100)
        val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)

        return BatterySnapshot(
            percent = percent,
            voltageMillivolts = voltage,
            temperatureCelsius = if (tempTenths == Int.MIN_VALUE) Float.NaN else tempTenths / 10f,
            status = status,
            plugged = plugged,
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL ||
                plugged != 0,
            timestampMillis = System.currentTimeMillis()
        )
    }

    // ---------------- /proc/stat 解析 ----------------

    /**
     * 首次采样只建立基线，返回值全 0；之后每次 sample() 与上一次做差。
     */
    private class CpuSampler {

        private var prevTotal: LongArray = LongArray(0)
        private var prevIdle: LongArray = LongArray(0)

        fun prime() {
            val rows = readRows()
            prevTotal = LongArray(rows.size) { rows[it].total }
            prevIdle = LongArray(rows.size) { rows[it].idle }
        }

        fun sample(): CpuSnapshot {
            val now = System.currentTimeMillis()
            val rows = readRows()
            if (rows.isEmpty()) {
                return CpuSnapshot(0f, emptyList(), null, now)
            }

            val size = rows.size
            val totalDelta = LongArray(size)
            val idleDelta = LongArray(size)
            for (i in 0 until size) {
                val total = rows[i].total
                val idle = rows[i].idle
                val pt = if (i < prevTotal.size) prevTotal[i] else 0L
                val pi = if (i < prevIdle.size) prevIdle[i] else 0L
                totalDelta[i] = (total - pt).coerceAtLeast(0L)
                idleDelta[i] = (idle - pi).coerceAtLeast(0L)
            }

            prevTotal = LongArray(size) { rows[it].total }
            prevIdle = LongArray(size) { rows[it].idle }

            // rows[0] 是汇总行 "cpu"，rows[1..] 是逐核
            val aggregateTotal = totalDelta[0]
            val aggregateIdle = idleDelta[0]
            val totalPercent = usage(aggregateTotal, aggregateIdle)

            val perCore = ArrayList<Float>(size - 1)
            for (i in 1 until size) {
                perCore.add(usage(totalDelta[i], idleDelta[i]))
            }

            return CpuSnapshot(
                totalPercent = totalPercent,
                perCorePercent = perCore,
                temperatureCelsius = null,
                timestampMillis = now
            )
        }

        private fun usage(total: Long, idle: Long): Float {
            if (total <= 0L) return 0f
            val busy = (total - idle).coerceIn(0L, total)
            return (busy.toDouble() / total * 100.0).toFloat().coerceIn(0f, 100f)
        }

        private fun readRows(): List<Row> {
            val file = File("/proc/stat")
            if (!file.canRead()) return emptyList()
            val rows = ArrayList<Row>(16)
            runCatching {
                file.useLines { seq ->
                    for (line in seq) {
                        if (!line.startsWith("cpu")) break
                        // cpu  user nice system idle iowait irq softirq steal ...
                        val parts = line.trim().split(WHITESPACE)
                        if (parts.size < 5) continue
                        var total = 0L
                        for (i in 1 until minOf(parts.size, 9)) {
                            total += parts[i].toLongOrNull() ?: 0L
                        }
                        // idle = idle + iowait
                        val idle = (parts[4].toLongOrNull() ?: 0L) +
                            (if (parts.size > 5) parts[5].toLongOrNull() ?: 0L else 0L)
                        rows.add(Row(total, idle))
                    }
                }
            }
            return rows
        }

        private class Row(val total: Long, val idle: Long)
    }

    // ---------------- 温度 ----------------

    /**
     * 多路径回退：
     * 1. /sys/class/thermal/thermal_zoneXX/type 命中 cpu/soc/ap 等关键字 -> 取其 temp
     * 2. 全部 zone 取最大值兜底（必须是合理区间）
     * 3. /sys/class/hwmon/hwmonX/temp1_input
     * 全部失败返回 null（无权限 / 无传感器），UI 显示 "--"。
     */
    private fun readTemperatureCelsius(): Float? {
        val candidates = ArrayList<Float>(8)

        val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
        if (zones != null) {
            for (zone in zones) {
                val type = runCatching {
                    File(zone, "type").takeIf { it.canRead() }?.readText()?.trim().orEmpty()
                }.getOrDefault("")
                val raw = runCatching {
                    File(zone, "temp").takeIf { it.canRead() }?.readText()?.trim()?.toLongOrNull()
                }.getOrNull() ?: continue
                val celsius = normalizeMilliCelsius(raw) ?: continue
                if (isCpuLike(type)) {
                    candidates.add(celsius)
                } else if (candidates.isEmpty()) {
                    candidates.add(celsius)
                }
            }
        }

        if (candidates.isEmpty()) {
            val hwmons = File("/sys/class/hwmon").listFiles()
            if (hwmons != null) {
                for (dir in hwmons) {
                    for (i in 1..4) {
                        val f = File(dir, "temp${i}_input")
                        if (!f.canRead()) continue
                        val raw = runCatching { f.readText().trim().toLongOrNull() }.getOrNull() ?: continue
                        val celsius = normalizeMilliCelsius(raw) ?: continue
                        candidates.add(celsius)
                    }
                }
            }
        }

        if (candidates.isEmpty()) return null
        return candidates.maxOrNull()
    }

    private fun isCpuLike(type: String): Boolean {
        if (type.isEmpty()) return false
        val t = type.lowercase()
        return CPU_THERMAL_KEYWORDS.any { t.contains(it) }
    }

    /** 有些机器给的是摄氏度整数，有些是毫摄氏度；也过滤明显异常值 */
    private fun normalizeMilliCelsius(raw: Long): Float? {
        val value = when {
            raw > 1000L -> raw / 1000f
            raw in -40L..200L -> raw.toFloat()
            else -> return null
        }
        return if (value in -40f..150f) value else null
    }

    // ---------------- /proc/diskstats ----------------

    /**
     * 字段顺序（内核文档）：
     * major minor name reads_completed reads_merged sectors_read ms_reading
     * writes_completed writes_merged sectors_written ...
     * sectors 固定按 512 字节计。只统计整盘，避免分区重复计数。
     */
    private class DiskSampler {

        private var prevSectorsRead = 0L
        private var prevSectorsWritten = 0L
        private var prevElapsedNanos = 0L

        fun prime() {
            val c = readCounters()
            prevSectorsRead = c.first
            prevSectorsWritten = c.second
            prevElapsedNanos = SystemClock.elapsedRealtimeNanos()
        }

        fun sample(): DiskSnapshot {
            val nowNanos = SystemClock.elapsedRealtimeNanos()
            val c = readCounters()
            val read = c.first
            val written = c.second

            if (prevElapsedNanos == 0L) {
                prevSectorsRead = read
                prevSectorsWritten = written
                prevElapsedNanos = nowNanos
                return DiskSnapshot(0L, 0L, 0L, System.currentTimeMillis())
            }

            val elapsedNanos = nowNanos - prevElapsedNanos
            if (elapsedNanos <= 0L) {
                return DiskSnapshot(0L, 0L, 0L, System.currentTimeMillis())
            }

            val dRead = (read - prevSectorsRead).coerceAtLeast(0L) * SECTOR_SIZE
            val dWrite = (written - prevSectorsWritten).coerceAtLeast(0L) * SECTOR_SIZE
            val seconds = elapsedNanos / 1_000_000_000.0

            prevSectorsRead = read
            prevSectorsWritten = written
            prevElapsedNanos = nowNanos

            return DiskSnapshot(
                readBytesPerSecond = (dRead / seconds).toLong(),
                writeBytesPerSecond = (dWrite / seconds).toLong(),
                sampledOverMillis = elapsedNanos / 1_000_000L,
                timestampMillis = System.currentTimeMillis()
            )
        }

        private fun readCounters(): Pair<Long, Long> {
            val file = File("/proc/diskstats")
            if (!file.canRead()) return 0L to 0L
            var sectorsRead = 0L
            var sectorsWritten = 0L
            runCatching {
                file.useLines { seq ->
                    for (line in seq) {
                        val p = line.trim().split(WHITESPACE)
                        if (p.size < 10) continue
                        val name = p[2]
                        if (!isWholeDisk(name)) continue
                        sectorsRead += p[5].toLongOrNull() ?: 0L
                        sectorsWritten += p[9].toLongOrNull() ?: 0L
                    }
                }
            }
            return sectorsRead to sectorsWritten
        }

        private fun isWholeDisk(name: String): Boolean {
            if (VIRTUAL_DISK_PREFIXES.any { name.startsWith(it) }) return false
            return WHOLE_DISK_REGEX.matches(name)
        }
    }

    companion object {
        const val DEFAULT_INTERVAL_MILLIS = 1000L
        const val MIN_INTERVAL_MILLIS = 250L

        private const val PAGE_SIZE_BYTES = 4096L
        private const val SECTOR_SIZE = 512L

        private val WHITESPACE = Regex("\\s+")

        private val CPU_THERMAL_KEYWORDS = listOf(
            "cpu", "soc", "ap", "tsens", "cluster", "core", "gpu"
        )

        private val VIRTUAL_DISK_PREFIXES = listOf(
            "loop", "ram", "zram", "dm-", "md", "sr", "nbd"
        )

        /** mmcblk0 / sda / nvme0n1 / vda 这类整盘，排除 mmcblk0p1 之类的分区 */
        private val WHOLE_DISK_REGEX = Regex(
            "^(mmcblk\\d+|sd[a-z]+|nvme\\d+n\\d+|vd[a-z]+|xvd[a-z]+|hvd[a-z]+)$"
        )
    }
}
