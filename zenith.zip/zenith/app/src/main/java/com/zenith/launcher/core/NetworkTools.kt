package com.zenith.launcher.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI
import java.net.URL
import java.util.Locale

// ============================ HTTP 请求器 ============================

data class HttpHeader(val name: String, val value: String)

data class HttpRequestSpec(
    val url: String,
    val method: String = "GET",
    val headers: List<HttpHeader> = emptyList(),
    val body: String? = null,
    val connectTimeoutMs: Int = 10_000,
    val readTimeoutMs: Int = 15_000,
    val maxBodyBytes: Int = 256 * 1024,
    /** 默认拒绝内网；只有用户显式打开开关才置 true */
    val allowPrivateNetwork: Boolean = false,
    /** 默认不自动跟随跳转，避免被 302 引到内网 */
    val followRedirects: Boolean = false
)

data class HttpResponseData(
    val ok: Boolean,
    val status: Int,
    val reasonPhrase: String,
    val headers: List<HttpHeader>,
    val body: String,
    val bodyBytes: Int,
    val truncated: Boolean,
    /** 跟随跳转后的最终地址；未跳转时等于请求地址 */
    val finalUrl: String,
    val elapsedMs: Long,
    /** 非空表示被本地护栏拦下，没有发出任何请求 */
    val blockedReason: String? = null,
    /** 请求异常时的原始信息（被护栏拦下时为空） */
    val errorMessage: String? = null
) {
    companion object {
        fun blocked(url: String, reason: String, elapsedMs: Long): HttpResponseData =
            HttpResponseData(
                ok = false, status = 0, reasonPhrase = "", headers = emptyList(),
                body = "", bodyBytes = 0, truncated = false, finalUrl = url,
                elapsedMs = elapsedMs, blockedReason = reason, errorMessage = null
            )

        fun failed(url: String, reason: String, elapsedMs: Long): HttpResponseData =
            HttpResponseData(
                ok = false, status = 0, reasonPhrase = "", headers = emptyList(),
                body = "", bodyBytes = 0, truncated = false, finalUrl = url,
                elapsedMs = elapsedMs, blockedReason = null, errorMessage = reason
            )
    }
}

/**
 * 手写 HttpURLConnection 请求器。
 *
 * 硬护栏：
 * 1. SSRF —— 目标主机解析出的**所有** IP 只要有一个是 loopback / 链路本地(169.254/fe80)
 *    / 私网(RFC1918, ULA) / 0.0.0.0，且用户没打开「允许内网」，直接拒绝，不发请求；
 * 2. 跳转 —— 默认不跟随；开启跟随时每一跳都重新过一遍 SSRF 检查，最多 5 跳；
 * 3. 体积 —— 响应体最多 maxBodyBytes，超出部分丢弃并标记 truncated；
 * 4. 不留痕 —— 不实现 CookieHandler、不写任何文件、不缓存 token。
 */
object NetworkTools {

    const val MAX_REDIRECTS = 5
    const val MAX_BODY_BYTES = 4 * 1024 * 1024

    private val ALLOWED_SCHEMES = setOf("http", "https")

    /**
     * 预检：只做地址判定，不发请求。UI 可在用户点"发送"前先调这个给出提示。
     * 返回 null 表示放行，非 null 是拒绝原因。
     */
    fun precheck(url: String, allowPrivateNetwork: Boolean): String? {
        val uri = try {
            URI(url.trim())
        } catch (e: Exception) {
            return "URL 格式不合法：${e.message ?: ""}"
        }
        val scheme = uri.scheme?.lowercase(Locale.US)
            ?: return "缺少协议（只允许 http / https）"
        if (scheme !in ALLOWED_SCHEMES) {
            return "协议 $scheme 不被允许，只允许 http / https"
        }
        val host = uri.host ?: return "URL 里没有主机名"
        if (host.isEmpty()) return "主机名为空"

        if (host.equals("localhost", ignoreCase = true) ||
            host.endsWith(".localhost", ignoreCase = true)
        ) {
            return if (allowPrivateNetwork) null else "已拦截：localhost 属于本机地址。如确需访问请打开「允许内网」"
        }

        // 域名先解析，拿到所有 A/AAAA 记录逐个判定
        val addresses = try {
            InetAddress.getAllByName(host)
        } catch (e: Exception) {
            return "域名解析失败：${e.message ?: host}"
        }
        if (addresses.isEmpty()) return "域名解析不到任何地址：$host"

        if (allowPrivateNetwork) return null

        for (addr in addresses) {
            val reason = privateReason(addr)
            if (reason != null) {
                return "已拦截：$host 解析到 ${addr.hostAddress}（$reason）。如确需访问请打开「允许内网」"
            }
        }
        return null
    }

    /** 判定是否为不可信地址；返回中文原因，可访问返回 null */
    fun privateReason(addr: InetAddress): String? {
        if (addr.isAnyLocalAddress) return "通配地址 0.0.0.0"
        if (addr.isLoopbackAddress) return "本机回环地址"
        if (addr.isLinkLocalAddress) return "链路本地地址（169.254/fe80）"
        if (addr.isSiteLocalAddress) return "内网私有地址（RFC1918）"
        if (isUniqueLocalIpv6(addr)) return "IPv6 唯一本地地址（fc00::/7）"
        if (isCarrierGradeNat(addr)) return "运营商级 NAT 地址（100.64/10）"
        return null
    }

    private fun isUniqueLocalIpv6(addr: InetAddress): Boolean {
        val b = addr.address
        if (b.size != 16) return false
        return (b[0].toInt() and 0xFE) == 0xFC
    }

    private fun isCarrierGradeNat(addr: InetAddress): Boolean {
        val b = addr.address
        if (b.size != 4) return false
        val a0 = b[0].toInt() and 0xFF
        val a1 = b[1].toInt() and 0xFF
        return a0 == 100 && a1 in 64..127
    }

    /** 主入口：在 IO 线程执行，带总超时（所有等待之和再加 2s 余量） */
    suspend fun request(spec: HttpRequestSpec): HttpResponseData =
        withContext(Dispatchers.IO) {
            val begin = SystemClock.elapsedRealtime()
            fun elapsed() = SystemClock.elapsedRealtime() - begin

            val method = spec.method.uppercase(Locale.US)
            if (method !in setOf("GET", "POST", "PUT", "DELETE", "HEAD", "PATCH")) {
                return@withContext HttpResponseData.failed(
                    spec.url, "不支持的请求方法：$method", elapsed()
                )
            }
            if (spec.maxBodyBytes !in 1024..MAX_BODY_BYTES) {
                return@withContext HttpResponseData.failed(
                    spec.url, "响应体上限必须在 1KB~4MB 之间", elapsed()
                )
            }

            val totalBudget = spec.connectTimeoutMs.toLong() +
                spec.readTimeoutMs.toLong() * (MAX_REDIRECTS + 1) + 2_000L

            val result = withTimeoutOrNull(totalBudget) {
                executeWithRedirects(spec, method)
            }

            if (result == null) {
                return@withContext HttpResponseData.failed(
                    spec.url, "总耗时超过 ${totalBudget}ms，已中止", elapsed()
                )
            }

            result.copy(elapsedMs = elapsed())
        }

    private fun executeWithRedirects(spec: HttpRequestSpec, method: String): HttpResponseData {
        var currentUrl = spec.url.trim()
        var hops = 0

        while (true) {
            val precheckFailure = precheck(currentUrl, spec.allowPrivateNetwork)
            if (precheckFailure != null) {
                return HttpResponseData.blocked(currentUrl, precheckFailure, 0L)
            }

            val single = executeOnce(spec, method, currentUrl)
            val status = single.status

            val isRedirect = status == 301 || status == 302 || status == 303 ||
                status == 307 || status == 308
            if (!isRedirect || !spec.followRedirects) {
                return single
            }

            val location = single.headers
                .firstOrNull { it.name.equals("Location", ignoreCase = true) }
                ?.value
                ?: return single

            if (hops >= MAX_REDIRECTS) {
                return single.copy(
                    ok = false,
                    errorMessage = "跳转超过 $MAX_REDIRECTS 次，已停止"
                )
            }

            val next = try {
                URL(URL(currentUrl), location).toString()
            } catch (e: Exception) {
                return single.copy(ok = false, errorMessage = "Location 无法解析：$location")
            }

            // 每一跳都重新过 SSRF，防止 302 到 127.0.0.1
            val hopCheck = precheck(next, spec.allowPrivateNetwork)
            if (hopCheck != null) {
                return HttpResponseData.blocked(currentUrl, "第 ${hops + 1} 跳被拦截：$hopCheck", 0L)
            }

            currentUrl = next
            hops++
        }
    }

    private fun executeOnce(
        spec: HttpRequestSpec,
        method: String,
        url: String
    ): HttpResponseData {
        var conn: HttpURLConnection? = null
        return try {
            val parsed = URL(url)
            val connection = parsed.openConnection() as HttpURLConnection
            conn = connection
            connection.requestMethod = method
            // 关掉 JDK 自带跳转，全部由我们手动跟，才能逐跳查 SSRF
            connection.instanceFollowRedirects = false
            connection.connectTimeout = spec.connectTimeoutMs
            connection.readTimeout = spec.readTimeoutMs
            connection.useCaches = false
            connection.setRequestProperty("User-Agent", "Zenith/0.1 (Android)")
            connection.setRequestProperty("Accept", "*/*")

            // 用户自定义 Header 覆盖默认值；禁止 CRLF 注入
            for (h in spec.headers) {
                val name = h.name.trim()
                if (name.isEmpty()) continue
                if (name.contains('\r') || name.contains('\n')) continue
                if (h.value.contains('\r') || h.value.contains('\n')) continue
                if (name.equals("Host", ignoreCase = true)) continue
                connection.setRequestProperty(name, h.value)
            }

            val bodyBytes = spec.body?.toByteArray(Charsets.UTF_8)
            if (bodyBytes != null && method != "GET" && method != "HEAD") {
                connection.doOutput = true
                if (connection.getRequestProperty("Content-Type") == null) {
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                connection.setFixedLengthStreamingMode(bodyBytes.size)
                connection.outputStream.use { it.write(bodyBytes) }
            }

            val status = connection.responseCode
            val reason = connection.responseMessage ?: ""

            val headers = ArrayList<HttpHeader>(16)
            for ((k, values) in connection.headerFields) {
                if (k == null) continue
                for (v in values) headers.add(HttpHeader(k, v))
            }

            val stream: InputStream? = if (status >= 400) connection.errorStream else connection.inputStream
            val capped = if (stream == null || method == "HEAD") {
                CappedBody(ByteArray(0), 0, false)
            } else {
                readCapped(stream, spec.maxBodyBytes)
            }

            val charset = charsetOf(connection.contentType)
            val decoded = capped.decode(charset)

            HttpResponseData(
                ok = status in 200..399,
                status = status,
                reasonPhrase = reason,
                headers = headers,
                body = decoded,
                bodyBytes = capped.count,
                truncated = capped.truncated,
                finalUrl = url,
                elapsedMs = 0L
            )
        } catch (e: Exception) {
            HttpResponseData.failed(url, "${e.javaClass.simpleName}: ${e.message ?: ""}", 0L)
        } finally {
            runCatching { conn?.disconnect() }
        }
    }

    /** 累积到上限就停，返回 (字节缓冲, 实际字节数, 是否被截断) */
    private fun readCapped(input: InputStream, cap: Int): CappedBody {
        val out = ByteArrayOutputStream(minOf(cap, 64 * 1024))
        val buffer = ByteArray(8 * 1024)
        var total = 0
        var truncated = false
        BufferedInputStream(input).use { stream ->
            while (true) {
                val read = stream.read(buffer)
                if (read <= 0) break
                val room = cap - total
                if (room <= 0) {
                    truncated = true
                    break
                }
                val take = minOf(read, room)
                out.write(buffer, 0, take)
                total += take
                if (take < read) {
                    truncated = true
                    break
                }
            }
        }
        return CappedBody(out.toByteArray(), total, truncated)
    }

    /** 响应体读取结果 */
    private class CappedBody(
        val bytes: ByteArray,
        val count: Int,
        val truncated: Boolean
    ) {
        fun decode(charset: java.nio.charset.Charset?): String =
            if (charset != null) {
                runCatching { String(bytes, charset) }.getOrDefault(String(bytes, Charsets.UTF_8))
            } else {
                String(bytes, Charsets.UTF_8)
            }
    }

    private fun charsetOf(contentType: String?): java.nio.charset.Charset? {
        if (contentType == null) return null
        val idx = contentType.lowercase(Locale.US).indexOf("charset=")
        if (idx < 0) return null
        val raw = contentType.substring(idx + 8).substringBefore(';').trim().trim('"')
        return runCatching { java.nio.charset.Charset.forName(raw) }.getOrNull()
    }
}

// ============================ VpnService 骨架 ============================

data class VpnTrafficSample(
    val uid: Int,
    val packageName: String?,
    val rxBytes: Long,
    val txBytes: Long,
    val rxBytesPerSec: Long,
    val txBytesPerSec: Long
)

data class VpnState(
    val running: Boolean,
    /** 系统未授权 / 用户拒绝 */
    val needPermission: Boolean,
    val sessionName: String,
    val establishedAt: Long,
    val elapsedSeconds: Long,
    val samples: List<VpnTrafficSample>,
    val lastUpdate: Long,
    /** 固定 true，提醒 UI 显示"仅计数，不解析流量" */
    val countOnly: Boolean = true
)

/**
 * VpnService 骨架 —— 只做三件事：走系统授权、按 uid 计数、可一键断开。
 *
 * 明确不做（防意外条款，写死在这里，后续改动请先读这段）：
 * - 不加任何 addRoute：tun 建立后不接管任何流量，因此**不会**导致断网，
 *   也不会产生半个隧道导致流量黑洞；
 * - 不读 tun 的文件描述符，不解密，不解析 HTTP/TLS，不写 pcap；
 * - 计数来自 TrafficStats.getUidRxBytes/TxBytes，不是从 tun 抓的包；
 * - 不落盘任何流量元数据，进程退出即丢。
 *
 * 因此本服务的真正价值是：验证 VPN 授权链路 + 提供一个按 uid 的速率面板。
 * 若将来需要真实分流，属于另一个量级的工作，且与本项目"零解析"红线冲突，需重新评审。
 */
class ZenithVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var sampleJob: Job? = null

    private var prevRx = HashMap<Int, Long>()
    private var prevTx = HashMap<Int, Long>()
    private var prevNanos = 0L
    private var establishedAt = 0L

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn("用户主动断开")
                return START_NOT_STICKY
            }
            else -> startVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (tun != null) return
        startForegroundCompat()

        // 走系统授权；prepare 返回非 null 说明用户还没同意，必须由 Activity 发起
        val prepareIntent = prepare(this)
        if (prepareIntent != null) {
            _state.value = _state.value.copy(needPermission = true, running = false)
            stopSelf()
            return
        }

        val builder = Builder()
            .setSession(SESSION_NAME)
            .setMtu(MTU)
            .addAddress(LOCAL_ADDRESS, LOCAL_PREFIX)
            // 故意不加 addRoute：不加路由 = 不接管任何流量
            .setBlocking(false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // 告诉系统这个 VPN 不需要 metered 计费困扰；API 29 起可用
            runCatching { builder.setMetered(false) }
        }

        val fd = try {
            builder.establish()
        } catch (e: Exception) {
            null
        }

        if (fd == null) {
            _state.value = _state.value.copy(running = false, needPermission = true)
            stopSelf()
            return
        }

        tun = fd
        establishedAt = System.currentTimeMillis()
        prevNanos = SystemClock.elapsedRealtimeNanos()
        prevRx.clear()
        prevTx.clear()

        _state.value = VpnState(
            running = true,
            needPermission = false,
            sessionName = SESSION_NAME,
            establishedAt = establishedAt,
            elapsedSeconds = 0L,
            samples = emptyList(),
            lastUpdate = establishedAt,
            countOnly = true
        )

        startSampling()
    }

    private fun startSampling() {
        sampleJob?.cancel()
        sampleJob = scope.launch {
            while (isActive) {
                delay(SAMPLE_INTERVAL_MS)
                if (tun == null) break
                val samples = sampleUids()
                val current = _state.value
                _state.value = current.copy(
                    samples = samples,
                    elapsedSeconds = (System.currentTimeMillis() - establishedAt) / 1000L,
                    lastUpdate = System.currentTimeMillis()
                )
                updateNotification(samples)
            }
        }
    }

    /**
     * 只统计"有变化的 uid"，避免把几百个 uid 全塞进 UI。
     * TrafficStats 在部分 ROM 对其它 uid 返回 UNSUPPORTED(-1)，这类直接跳过。
     */
    private fun sampleUids(): List<VpnTrafficSample> {
        val nowNanos = SystemClock.elapsedRealtimeNanos()
        val elapsed = if (prevNanos == 0L) 0L else (nowNanos - prevNanos).coerceAtLeast(1L)
        val seconds = elapsed / 1_000_000_000.0
        val result = ArrayList<VpnTrafficSample>(8)

        for (uid in TRACKED_UIDS) {
            val rx = android.net.TrafficStats.getUidRxBytes(uid)
            val tx = android.net.TrafficStats.getUidTxBytes(uid)
            if (rx < 0 || tx < 0) continue

            val lastRx = prevRx[uid] ?: rx
            val lastTx = prevTx[uid] ?: tx
            val dRx = (rx - lastRx).coerceAtLeast(0L)
            val dTx = (tx - lastTx).coerceAtLeast(0L)
            prevRx[uid] = rx
            prevTx[uid] = tx

            if (dRx == 0L && dTx == 0L && lastRx != 0L) continue

            result.add(
                VpnTrafficSample(
                    uid = uid,
                    packageName = runCatching { packageManager.getNameForUid(uid) }.getOrNull(),
                    rxBytes = rx,
                    txBytes = tx,
                    rxBytesPerSec = if (seconds > 0) (dRx / seconds).toLong() else 0L,
                    txBytesPerSec = if (seconds > 0) (dTx / seconds).toLong() else 0L
                )
            )
        }
        prevNanos = nowNanos
        return result
    }

    /** 系统回收 VPN 授权时回调（用户在别的 VPN 里切走、或系统强制） */
    override fun onRevoke() {
        stopVpn("系统回收 VPN 授权")
        super.onRevoke()
    }

    private fun stopVpn(reason: String) {
        sampleJob?.cancel()
        sampleJob = null
        runCatching { tun?.close() }
        tun = null
        _state.value = _state.value.copy(
            running = false,
            samples = emptyList(),
            lastUpdate = System.currentTimeMillis()
        )
        runCatching { stopForeground(true) }
        stopSelf()
        android.util.Log.i(TAG, "VPN 已停止：$reason")
    }

    override fun onDestroy() {
        instance = null
        sampleJob?.cancel()
        scope.cancel()
        runCatching { tun?.close() }
        tun = null
        _state.value = VpnState(
            running = false, needPermission = false, sessionName = SESSION_NAME,
            establishedAt = 0L, elapsedSeconds = 0L, samples = emptyList(),
            lastUpdate = System.currentTimeMillis(), countOnly = true
        )
        super.onDestroy()
    }

    // ---------------- 前台通知（Android 10 起必需） ----------------

    private fun createChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Zenith 网络计数",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "仅在 VPN 会话期间显示，用于说明统计正在运行"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun startForegroundCompat() {
        val notification = buildNotification("VPN 会话已建立，正在按 uid 统计（不解析流量）")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, FOREGROUND_TYPE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(samples: List<VpnTrafficSample>) {
        val totalRx = samples.sumOf { it.rxBytesPerSec }
        val totalTx = samples.sumOf { it.txBytesPerSec }
        val text = "↓ ${formatRate(totalRx)}  ↑ ${formatRate(totalTx)}（仅计数）"
        runCatching {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.notify(NOTIFICATION_ID, buildNotification(text))
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pending = openIntent?.let {
            PendingIntent.getActivity(
                this, 0, it,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                } else {
                    PendingIntent.FLAG_UPDATE_CURRENT
                }
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ZenithVpnService::class.java).setAction(ACTION_STOP),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
        )

        val builder = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Zenith · 网络计数")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "断开",
                    stopIntent
                ).build()
            )
        if (pending != null) builder.setContentIntent(pending)
        return builder.build()
    }

    companion object {
        const val ACTION_STOP = "com.zenith.launcher.action.VPN_STOP"
        const val ACTION_START = "com.zenith.launcher.action.VPN_START"

        private const val TAG = "ZenithVpn"
        private const val CHANNEL_ID = "zenith_vpn"
        private const val NOTIFICATION_ID = 1001
        private const val SESSION_NAME = "Zenith 计数会话"
        private const val MTU = 1500
        private const val LOCAL_ADDRESS = "10.66.0.2"
        private const val LOCAL_PREFIX = 32
        private const val SAMPLE_INTERVAL_MS = 1000L
        private const val FOREGROUND_TYPE = 0x00000040 // FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED

        /** 只统计本应用 + 系统 + 常见前台 uid，避免遍历全表触发权限问题 */
        private val TRACKED_UIDS: IntArray = intArrayOf(
            0,
            1000,
            Process.myUid()
        )

        private val _state = MutableStateFlow(
            VpnState(
                running = false, needPermission = false, sessionName = SESSION_NAME,
                establishedAt = 0L, elapsedSeconds = 0L, samples = emptyList(),
                lastUpdate = 0L, countOnly = true
            )
        )
        val state: StateFlow<VpnState> = _state.asStateFlow()

        @Volatile
        private var instance: ZenithVpnService? = null

        /** Activity 侧查询是否需要先走系统授权 */
        fun needsPermission(context: Context): Intent? = prepare(context)

        fun formatRate(bytesPerSec: Long): String {
            if (bytesPerSec < 0) return "--"
            val units = arrayOf("B/s", "KB/s", "MB/s", "GB/s")
            var value = bytesPerSec.toDouble()
            var index = 0
            while (value >= 1024.0 && index < units.size - 1) {
                value /= 1024.0
                index++
            }
            return if (index == 0) {
                "${bytesPerSec} ${units[0]}"
            } else {
                String.format(Locale.US, "%.2f %s", value, units[index])
            }
        }
    }
}
