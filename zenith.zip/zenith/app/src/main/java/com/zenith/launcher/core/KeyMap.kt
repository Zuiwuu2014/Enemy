package com.zenith.launcher.core

import android.view.KeyEvent as NativeKeyEvent
import androidx.compose.ui.input.key.KeyEvent

/**
 * 选择键的统一判定。
 *
 * 融合来源：pengchujin/aerial-tv（MIT License，Copyright (c) 2026 pengchujin）
 *   app/src/main/java/app/orchard/tv/ui/components/Pressable.kt 中的 `KeyEvent.isSelect()`
 *
 * 为什么要它：Zenith 原来只认 `Key.Enter` 与 `Key.DirectionCenter`，
 * 于是蓝牙手柄的 A 键（KEYCODE_BUTTON_A）和小键盘回车（KEYCODE_NUMPAD_ENTER）按下去没反应。
 * 这里改成看 `nativeKeyEvent.keyCode`，比用 Compose 的 `Key.ButtonA` 等常量更稳
 * —— android.view.KeyEvent 的常量在任何 API 级别都存在，Compone 的 Key 对象在不同版本里增减过。
 */
fun KeyEvent.isSelectKey(): Boolean = when (nativeKeyEvent.keyCode) {
    NativeKeyEvent.KEYCODE_DPAD_CENTER,
    NativeKeyEvent.KEYCODE_ENTER,
    NativeKeyEvent.KEYCODE_NUMPAD_ENTER,
    NativeKeyEvent.KEYCODE_BUTTON_A,
    NativeKeyEvent.KEYCODE_BUTTON_SELECT -> true
    else -> false
}

/**
 * 是否「一次按下的起点」——长按的后续重复事件 repeatCount > 0，不该被当成多次点击。
 */
fun KeyEvent.isFirstPress(): Boolean = nativeKeyEvent.repeatCount == 0

/**
 * 返回键族（遥控器 Back / 键盘 Esc）。
 */
fun KeyEvent.isBackKey(): Boolean = when (nativeKeyEvent.keyCode) {
    NativeKeyEvent.KEYCODE_BACK, NativeKeyEvent.KEYCODE_ESCAPE -> true
    else -> false
}
