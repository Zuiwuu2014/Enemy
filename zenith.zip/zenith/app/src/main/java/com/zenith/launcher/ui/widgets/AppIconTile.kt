package com.zenith.launcher.ui.widgets

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.zenith.launcher.core.AppIconLoader

/**
 * 应用图标块。
 *
 * 有图标就画图标（做去饱和处理，压进纯黑主题的灰度基调，不加发光、不加阴影）；
 * 没图标就退回首字母 + 等宽字，绝不画假图标。
 *
 * 不引任何图标库 / 图片库：图标来自 PackageManager，走 AppIconLoader 的内存 LRU。
 */
@Composable
fun AppIconTile(
    key: String?,
    label: String,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    dim: Boolean = false
) {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }

    var icon by remember(key) { mutableStateOf(key?.let { AppIconLoader.peek(it) }) }

    LaunchedEffect(key) {
        if (key == null) {
            icon = null
            return@LaunchedEffect
        }
        // 先看缓存；没有再异步解，避免在主线程碰 PackageManager
        icon = AppIconLoader.peek(key) ?: AppIconLoader.load(context, key, px)
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        val image = icon
        if (image != null) {
            Image(
                bitmap = image,
                contentDescription = label,
                contentScale = ContentScale.Fit,
                colorFilter = if (dim) {
                    // 整体去饱和，压进纯黑主题的灰度基调；不加发光、不加阴影
                    ColorFilter.colorMatrix(
                        ColorMatrix().apply {
                            setToSaturation(0f)
                        }
                    )
                } else {
                    null
                }
            )
        } else {
            // 兜底：首字母 + 等宽
            Text(
                text = firstGlyph(label),
                style = MaterialTheme.typography.titleMedium,
                color = ZenithPalette.TextDim,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .size(size)
                    .background(ZenithPalette.Track)
            )
        }
    }
}

/** 取首字母：中文取第一个字，英文取首字母大写，空串给 "?" */
private fun firstGlyph(label: String): String {
    val trimmed = label.trim()
    if (trimmed.isEmpty()) return "?"
    val first = trimmed.codePointAt(0)
    return String(Character.toChars(first)).uppercase()
}
