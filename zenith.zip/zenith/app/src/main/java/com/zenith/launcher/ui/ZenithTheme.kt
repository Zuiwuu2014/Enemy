package com.zenith.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * 调色板。规矩只有一条：**hover 只提亮，不发光**。
 * 所有颜色都是无透明度渐变的实色，没有 blur、没有 shadow、没有 glow。
 */
object ZenithPalette {
    /** 纯黑，整个应用只有一个底色 */
    val Void = Color(0xFF000000)
    /** 炭灰，模块底色，比纯黑亮一档 */
    val Charcoal = Color(0xFF141414)
    /** 炭灰高亮，hover 时的模块底色 */
    val CharcoalHi = Color(0xFF1F1F1F)
    /** 线框，常态 */
    val Line = Color(0xFF2A2A2A)
    /** 线框，聚焦/悬停 */
    val LineHi = Color(0xFF555555)
    /** 主文字 */
    val TextMain = Color(0xFFE8E8E8)
    /** 次要文字 */
    val TextDim = Color(0xFF7A7A7A)
    /** 不可用 / 空位 */
    val TextFaint = Color(0xFF3A3A3A)
    /** 在线（绿点） */
    val Online = Color(0xFF6FCF97)
    /** 离线（红点） */
    val Offline = Color(0xFF9B4A4A)
    /** 警示，如"--"以外的提示 */
    val Warn = Color(0xFFC9A227)
    /** 数据条轨道的颜色 */
    val Track = Color(0xFF1C1C1C)
}

private val ZenithTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 56.sp, fontWeight = FontWeight.Light, letterSpacing = 2.sp),
    displayMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 40.sp, fontWeight = FontWeight.Light, letterSpacing = 1.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 18.sp, fontWeight = FontWeight.Normal, letterSpacing = 1.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Normal, letterSpacing = 0.5.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, letterSpacing = 1.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
)

private val ZenithColors = darkColorScheme(
    primary = ZenithPalette.TextMain,
    onPrimary = ZenithPalette.Void,
    secondary = ZenithPalette.TextDim,
    onSecondary = ZenithPalette.Void,
    background = ZenithPalette.Void,
    onBackground = ZenithPalette.TextMain,
    surface = ZenithPalette.Charcoal,
    onSurface = ZenithPalette.TextMain,
    surfaceVariant = ZenithPalette.CharcoalHi,
    onSurfaceVariant = ZenithPalette.TextDim,
    outline = ZenithPalette.Line,
    error = ZenithPalette.Offline
)

@Composable
fun ZenithTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ZenithColors,
        typography = ZenithTypography,
        content = content
    )
}
