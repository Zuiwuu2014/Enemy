package com.zenith.launcher.core

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * 防砖护栏。
 *
 * 机制（比"数 onDestroy"可靠）：
 * 1. 每次 onCreate 先看上次会话有没有留下"未确认稳定"的标记 pending；
 *    有 → 说明上次是异常退出（崩溃/被低内存杀/被系统 ANR 杀），崩溃计数 +1；
 * 2. 本次会话立刻写入 pending=true；
 * 3. 前台稳定运行 8 秒后 markStable()，pending=false 且计数清零；
 * 4. 计数 >= 3 → 判定"反复起不来"，调用 revertToSystemHome() 并只显示一张静态提示页，
 *    不再渲染主界面 —— 这样用户永远有路可退。
 *
 * 注意：这里的"崩溃"包含被 LMK 杀掉的正常情况，宁可误判也不要把用户锁在崩溃循环里。
 */
object CrashGuard {

    const val THRESHOLD = 3
    const val STABLE_DELAY_MS = 8000L

    private const val PREFS = "zenith_crash_guard"
    private const val KEY_PENDING = "session_pending"
    private const val KEY_COUNT = "crash_count"

    /** 在 onCreate 最开头调用，返回累计崩溃次数 */
    fun onSessionStart(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val wasPending = prefs.getBoolean(KEY_PENDING, false)
        var count = prefs.getInt(KEY_COUNT, 0)
        if (wasPending) count++
        prefs.edit()
            .putBoolean(KEY_PENDING, true)
            .putInt(KEY_COUNT, count)
            .apply()
        return count
    }

    /** 前台稳定运行一段时间后调用，标记本次会话正常 */
    fun markStable(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_PENDING, false)
            .putInt(KEY_COUNT, 0)
            .apply()
    }

    fun currentCount(context: Context): Int =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_COUNT, 0)

    fun reset(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().clear().apply()
    }

    fun tripped(count: Int): Boolean = count >= THRESHOLD

    /**
     * 回退到系统桌面。
     *
     * 能做与不能做必须分清：
     * - 能做：clearPackagePreferredActivities(自己的包名) 可以把"默认桌面"从本应用身上摘掉，
     *   这是公开 API（API 33 起标记 deprecated，但仍可用，行为不变）；
     * - 不能做：直接指定另一个应用为默认桌面。Android 没有这个公开 API，
     *   只有用户本人在系统 UI（或 RoleManager 弹窗）里才能选。
     * 所以这里"摘掉自己 + 打开系统桌面选择页"，让用户自己点一下。
     */
    fun revertToSystemHome(activity: Activity): Boolean {
        var cleared = false
        runCatching {
            activity.packageManager.clearPackagePreferredActivities(activity.packageName)
            cleared = true
        }

        // 顺带把 HOME 的 role 请求页打开（API 29+ 有 RoleManager，但不是所有 ROM 都有 HOME role 页）
        val opened = runCatching {
            activity.startActivity(
                Intent(Settings.ACTION_HOME_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        }.getOrDefault(false)

        if (!opened) {
            // 兜底：打开应用详情页，用户至少能在这里清默认值
            runCatching {
                activity.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(android.net.Uri.fromParts("package", activity.packageName, null))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        return cleared
    }

    /** 供 UI 显示的三条回退说明，与实际可执行动作一一对应 */
    val REVERT_GUIDE: List<String> = listOf(
        "① 应用内「退出 Zenith」按钮：摘掉本应用的默认桌面并打开系统桌面选择页",
        "② 连续崩溃 3 次：下次启动只显示提示页，同时自动打开系统桌面选择页",
        "③ 完全无法进入时：adb shell cmd package set-home-activity <原桌面组件名>"
    )
}
