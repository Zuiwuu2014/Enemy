package com.zenith.launcher

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.activity.compose.setContent
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.zenith.launcher.core.AppLauncher
import com.zenith.launcher.core.CrashGuard
import com.zenith.launcher.ui.MainScreen
import com.zenith.launcher.ui.ZenithPalette
import com.zenith.launcher.ui.ZenithTheme
import com.zenith.launcher.ui.widgets.Unavailable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 主 Activity（HOME 候选）。
 *
 * onCreate 顺序是刻意安排的，先 CrashGuard.onSessionStart() 再 setContent，
 * 崩溃计数在渲染之前落盘，避免 setContent 抛异常时漏计。
 */
class MainActivity : ComponentActivity() {

    private val stableHandler = Handler(Looper.getMainLooper())
    private val stableRunnable = Runnable { CrashGuard.markStable(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ① 崩溃计数（必须在 setContent 之前）
        val crashCount = CrashGuard.onSessionStart(this)

        // ② 8 秒后标记稳定
        stableHandler.postDelayed(stableRunnable, CrashGuard.STABLE_DELAY_MS)

        // ③ 反复崩溃：只显示一张静态提示页，同时打开系统桌面选择页让用户自救
        if (CrashGuard.tripped(crashCount)) {
            showCrashGuardScreen(crashCount)
            return
        }

        // ④ 正常路径
        setContent {
            ZenithTheme {
                MainScreen(
                    lifecycleOwner = this,
                    onOpenHub = { openHub() },
                    onExitZenith = { exitZenith() }
                )
            }
        }
    }

    private fun showCrashGuardScreen(count: Int) {
        CrashGuard.revertToSystemHome(this)
        setContent {
            ZenithTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ZenithPalette.Void)
                        .padding(32.dp)
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Text(
                            text = "ZENITH 已暂停",
                            style = MaterialTheme.typography.titleLarge,
                            color = ZenithPalette.TextMain
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = "检测到连续 $count 次异常退出，为避免把你锁在崩溃循环里，" +
                                "已自动打开系统桌面选择页。请选一个可用的桌面应用。",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ZenithPalette.TextDim
                        )
                        Spacer(Modifier.height(24.dp))
                        Text(
                            text = "回退方式",
                            style = MaterialTheme.typography.labelMedium,
                            color = ZenithPalette.TextDim
                        )
                        Spacer(Modifier.height(6.dp))
                        for (line in CrashGuard.REVERT_GUIDE) {
                            Text(
                                text = line,
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenithPalette.TextFaint
                            )
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(
                            text = "按 Back 重新尝试进入 Zenith",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithPalette.TextFaint
                        )
                    }
                }
            }
        }
    }

    private fun openHub() {
        runCatching {
            startActivity(
                android.content.Intent(this, HubActivity::class.java)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /**
     * 回退原桌面：摘掉自己的默认桌面 + 打开系统桌面选择页。
     * 不调用任何非公开 API，不尝试替用户选。
     */
    private fun exitZenith() {
        CrashGuard.reset(this)
        val jumped = CrashGuard.revertToSystemHome(this)

        // 只有在「确实还有别的桌面可选」时才 finish，否则会黑屏。
        val otherHomeExists = runCatching {
            val intent = android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_HOME)
            packageManager.queryIntentActivities(intent, 0)
                .any { it.activityInfo?.packageName != packageName }
        }.getOrDefault(false)

        if (jumped && otherHomeExists) {
            finishAffinity()
        }
        // 没跳成功/没有别的桌面：保持在前台，让用户自己按 Home 或去设置里改。
        // 绝不在没有替代桌面的情况下 finish —— 那会让用户对着一片黑。
    }

    override fun onDestroy() {
        stableHandler.removeCallbacks(stableRunnable)
        super.onDestroy()
    }

    override fun onBackPressed() {
        // HOME 页面的 Back 默认行为就是"没反应"，这里保持一致，避免被当成"退出 Zenith"
        // 用户想退必须走右下角「退出 Zenith」或按 Q。
        if (isTaskRoot) {
            // 不做任何事
        } else {
            super.onBackPressed()
        }
    }
}
