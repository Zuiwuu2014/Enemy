package com.zenith.launcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.zenith.launcher.core.AppLauncher
import com.zenith.launcher.core.LaunchableApp
import java.util.Locale

/**
 * 全局输入服务（无障碍）。
 *
 * 纪律：
 * 1. **必须由用户在系统设置里手动开启**，本应用不会、也不能自动给自己授权；
 * 2. 只监听 Ctrl+Space，其余按键全部 return false 不吞掉；
 * 3. `canRetrieveWindowContent=false` —— 不读屏、不抓节点、不截图；
 * 4. 搜索只在本地的可启动应用列表里做字符串匹配，不联网、不上传；
 * 5. 崩溃不自动重启风暴：60 秒内启动 3 次即 disableSelf()，并保留一条通知说明原因。
 *
 * 覆盖层用 TYPE_ACCESSIBILITY_OVERLAY，不需要 SYSTEM_ALERT_WINDOW 权限。
 */
class GlobalInputService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlay: View? = null
    private var listContainer: LinearLayout? = null
    private var searchField: EditText? = null

    private var apps: List<LaunchableApp> = emptyList()
    private var filtered: List<LaunchableApp> = emptyList()
    private var focusIndex = 0

    private var receiverRegistered = false

    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_STOP) return
            hideOverlay()
            persistEnabled(false)
            runCatching { disableSelf() }
            cancelNotification()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        // 崩溃风暴护栏：60 秒内第 3 次启动就不再工作
        val starts = recordStart()
        if (starts >= MAX_STARTS_PER_WINDOW) {
            persistEnabled(false)
            showCrashStormNotification()
            runCatching { disableSelf() }
            return
        }

        serviceInfo = (serviceInfo ?: AccessibilityServiceInfo()).apply {
            // 只收窗口状态变化，不收文本内容事件
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            // 能不取窗口内容就不取
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                flags = flags and AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS.inv()
            }
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        reloadApps()

        if (!receiverRegistered) {
            runCatching {
                // ContextCompat 会在 API 33 以下自动降级，不用手写版本分支
                ContextCompat.registerReceiver(
                    this,
                    stopReceiver,
                    IntentFilter(ACTION_STOP),
                    ContextCompat.RECEIVER_NOT_EXPORTED
                )
                receiverRegistered = true
            }
        }
        showPersistentNotification()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 刻意什么都不做：本服务不需要读屏内容
    }

    override fun onInterrupt() {
        hideOverlay()
    }

    override fun onDestroy() {
        hideOverlay()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(stopReceiver) }
            receiverRegistered = false
        }
        cancelNotification()
        super.onDestroy()
    }

    // ---------------- 按键 ----------------

    /**
     * 只认 Ctrl+Space。其余一律 false —— 绝不吞键。
     * 覆盖层展开时才接管 Esc / 方向 / 回车，用于关闭和选择。
     */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val overlayVisible = overlay != null

        if (event.keyCode == KeyEvent.KEYCODE_SPACE &&
            event.isCtrlPressed &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0
        ) {
            toggleOverlay()
            return true
        }

        if (!overlayVisible) return false

        if (event.action != KeyEvent.ACTION_DOWN) return false
        return when (event.keyCode) {
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BACK -> {
                hideOverlay()
                true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                moveFocus(1)
                true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                moveFocus(-1)
                true
            }
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER -> {
                launchFocused()
                true
            }
            else -> false
        }
    }

    // ---------------- 覆盖层 ----------------

    private fun toggleOverlay() {
        if (overlay != null) hideOverlay() else showOverlay()
    }

    private fun showOverlay() {
        val wm = windowManager ?: return
        if (overlay != null) return
        reloadApps()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F2000000"))
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        val hint = TextView(this).apply {
            text = "ZENITH · 搜索应用（Esc 关闭）"
            setTextColor(Color.parseColor("#7A7A7A"))
            typeface = Typeface.MONOSPACE
            textSize = 12f
        }

        val field = EditText(this).apply {
            hint = "输入应用名"
            setTextColor(Color.parseColor("#E8E8E8"))
            setHintTextColor(Color.parseColor("#3A3A3A"))
            typeface = Typeface.MONOSPACE
            textSize = 20f
            setBackgroundColor(Color.TRANSPARENT)
            isSingleLine = true
            setPadding(0, dp(8), 0, dp(8))
        }
        searchField = field

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        listContainer = list

        val scroll = ScrollView(this).apply {
            addView(list, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        root.addView(hint)
        root.addView(field, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            dimAmount = 0.72f
        }

        runCatching { wm.addView(root, params) }
        overlay = root

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter(s?.toString().orEmpty())
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })

        applyFilter("")
        field.requestFocus()
    }

    private fun hideOverlay() {
        val root = overlay ?: return
        runCatching { windowManager?.removeView(root) }
        overlay = null
        listContainer = null
        searchField = null
        filtered = emptyList()
        focusIndex = 0
    }

    private fun applyFilter(query: String) {
        val q = query.trim().lowercase(Locale.getDefault())
        filtered = if (q.isEmpty()) {
            apps.take(MAX_ROWS)
        } else {
            apps.filter {
                it.label.lowercase(Locale.getDefault()).contains(q) ||
                    it.packageName.lowercase(Locale.getDefault()).contains(q)
            }.take(MAX_ROWS)
        }
        focusIndex = 0
        renderList()
    }

    private fun renderList() {
        val container = listContainer ?: return
        container.removeAllViews()

        if (filtered.isEmpty()) {
            container.addView(rowText("没有匹配的应用（本机共 ${apps.size} 个可启动）", false))
            return
        }

        for ((index, app) in filtered.withIndex()) {
            val view = rowText(app.label, index == focusIndex)
            view.setOnClickListener { launch(app) }
            container.addView(view)
        }
    }

    private fun rowText(text: String, focused: Boolean): TextView = TextView(this).apply {
        this.text = text
        typeface = Typeface.MONOSPACE
        textSize = 16f
        setTextColor(
            if (focused) Color.parseColor("#FFFFFF") else Color.parseColor("#B0B0B0")
        )
        setBackgroundColor(
            if (focused) Color.parseColor("#1F1F1F") else Color.TRANSPARENT
        )
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }

    private fun moveFocus(delta: Int) {
        if (filtered.isEmpty()) return
        focusIndex = (focusIndex + delta).coerceIn(0, filtered.size - 1)
        renderList()
    }

    private fun launchFocused() {
        filtered.getOrNull(focusIndex)?.let { launch(it) }
    }

    private fun launch(app: LaunchableApp) {
        hideOverlay()
        val error = AppLauncher.launch(this, app)
        if (error != null) {
            runCatching { Toast.makeText(this, error, Toast.LENGTH_SHORT).show() }
        }
    }

    private fun reloadApps() {
        apps = runCatching { AppLauncher.listLaunchable(packageManager) }
            .getOrDefault(emptyList())
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
        ).toInt()

    // ---------------- 通知 ----------------

    private fun showPersistentNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channel = NotificationChannel(
            CHANNEL_ID, "Zenith 全局输入", NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)

        val stop = PendingIntent.getBroadcast(
            this, 0,
            Intent(ACTION_STOP).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = android.app.Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Zenith · 全局输入已开启")
            .setContentText("Ctrl+Space 呼出搜索；点「停止」可随时关闭")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                android.app.Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ),
                    "停止",
                    stop
                ).build()
            )
            .build()
        runCatching { manager.notify(NOTIFICATION_ID, notification) }
    }

    private fun showCrashStormNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channel = NotificationChannel(
            CHANNEL_ID, "Zenith 全局输入", NotificationManager.IMPORTANCE_DEFAULT
        )
        manager.createNotificationChannel(channel)
        val notification = android.app.Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Zenith · 全局输入已自动关闭")
            .setContentText("检测到 60 秒内连续启动 $MAX_STARTS_PER_WINDOW 次，为避免反复崩溃已停用。可在系统设置中重新开启。")
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setAutoCancel(true)
            .build()
        runCatching { manager.notify(NOTIFICATION_ID + 1, notification) }
    }

    private fun cancelNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        runCatching { manager.cancel(NOTIFICATION_ID) }
    }

    private fun recordStart(): Int {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = SystemClock.elapsedRealtime()
        val windowStart = prefs.getLong(KEY_WINDOW_START, 0L)
        var count = prefs.getInt(KEY_START_COUNT, 0)
        count = if (now - windowStart > START_WINDOW_MS || windowStart == 0L) 1 else count + 1
        prefs.edit()
            .putLong(KEY_WINDOW_START, if (now - windowStart > START_WINDOW_MS || windowStart == 0L) now else windowStart)
            .putInt(KEY_START_COUNT, count)
            .apply()
        return count
    }

    private fun persistEnabled(enabled: Boolean) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    companion object {
        const val ACTION_STOP = "com.zenith.launcher.action.ACCESSIBILITY_STOP"
        val isEnabledFlag: (Context) -> Boolean = { ctx ->
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, true)
        }

        private const val PREFS = "zenith_accessibility"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_WINDOW_START = "window_start"
        private const val KEY_START_COUNT = "start_count"

        private const val CHANNEL_ID = "zenith_input"
        private const val NOTIFICATION_ID = 2001
        private const val MAX_ROWS = 12
        private const val MAX_STARTS_PER_WINDOW = 3
        private const val START_WINDOW_MS = 60_000L
    }
}
