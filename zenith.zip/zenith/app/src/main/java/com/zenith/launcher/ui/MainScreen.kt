package com.zenith.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleOwner
import com.zenith.launcher.core.AppLauncher
import com.zenith.launcher.core.isFirstPress
import com.zenith.launcher.core.isSelectKey
import com.zenith.launcher.core.AppSlotStore
import com.zenith.launcher.core.CrashGuard
import com.zenith.launcher.core.HardwareMonitor
import com.zenith.launcher.core.LanScanner
import com.zenith.launcher.core.LanScanResult
import com.zenith.launcher.core.LaunchableApp
import com.zenith.launcher.core.NetworkAnalyzer
import com.zenith.launcher.core.PeripheralManager
import com.zenith.launcher.ui.widgets.AppIconTile
import com.zenith.launcher.ui.widgets.BatteryBlock
import com.zenith.launcher.ui.widgets.CpuMemoryRings
import com.zenith.launcher.ui.widgets.LanProbeStatus
import com.zenith.launcher.ui.widgets.MonoClock
import com.zenith.launcher.ui.widgets.PeripheralIcons
import com.zenith.launcher.ui.widgets.Unavailable
import com.zenith.launcher.ui.widgets.WifiStatusRow
import com.zenith.launcher.ui.widgets.formatRate
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 主界面。
 *
 * 布局：左侧监控列（CPU/内存/电池/局域网探针），顶部时钟 + Wi-Fi + 外设图标，
 * 底部 5~8 个线框应用位，右下常驻「退出 Zenith」。
 * 所有数据格遵守「不可用显示 --」。
 */
@Composable
fun MainScreen(
    lifecycleOwner: LifecycleOwner,
    onOpenHub: () -> Unit,
    onExitZenith: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ---------- 数据源 ----------
    val hardwareMonitor = remember { HardwareMonitor(context) }
    val peripheralManager = remember { PeripheralManager(context) }
    val networkAnalyzer = remember { NetworkAnalyzer(context) }
    val slotStore = remember { AppSlotStore(context) }

    LaunchedEffect(Unit) {
        hardwareMonitor.bind(lifecycleOwner)
        peripheralManager.start()
        networkAnalyzer.refresh()
    }

    val hardware by hardwareMonitor.snapshot.collectAsState()
    val peripherals by peripheralManager.snapshot.collectAsState()
    val network by networkAnalyzer.snapshot.collectAsState()

    // ---------- 局域网探针 ----------
    var lanResult by remember { mutableStateOf<LanScanResult?>(null) }
    var lanScanning by remember { mutableStateOf(false) }
    var lanJob by remember { mutableStateOf<Job?>(null) }

    fun startLanScan() {
        if (lanScanning) return
        lanScanning = true
        val scanner = networkAnalyzer.newLanScanner()
        lanJob = scope.launch {
            try {
                lanResult = scanner.scan()
            } finally {
                lanScanning = false
            }
        }
    }

    fun stopLanScan() {
        lanJob?.cancel()
        lanScanning = false
    }

    // ---------- 应用位 ----------
    var launchable by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var slots by remember { mutableStateOf(slotStore.load()) }
    var slotCount by remember { mutableStateOf(slotStore.count) }
    var pendingSlotIndex by remember { mutableStateOf<Int?>(null) }
    var launchError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val apps = AppLauncher.listLaunchable(context.packageManager)
        launchable = apps
        slotStore.seedIfEmpty(apps)
        slots = slotStore.load()
    }

    fun launchSlot(index: Int) {
        val key = slots.getOrNull(index) ?: run {
            pendingSlotIndex = index
            return
        }
        val app = LaunchableApp.fromKey(key, context.packageManager)
        if (app == null) {
            pendingSlotIndex = index
            return
        }
        val error = AppLauncher.launch(context, app)
        launchError = error
    }

    fun bindSlot(index: Int, app: LaunchableApp) {
        slotStore.setSlot(index, app.key)
        slots = slotStore.load()
        pendingSlotIndex = null
    }

    // ---------- 退出 ----------
    fun exitZenith() {
        stopLanScan()
        peripheralManager.stop()
        onExitZenith()
    }

    // ---------- 焦点/按键 ----------
    // D-pad：方向键在模块间移动，Center/Enter 触发，Back 不退出（防误按）。
    // 简化版走查：每一个可聚焦元素都标 focusable()，焦点框由 focusable 自带绘制，
    // 这里额外让 hover 提亮也作用于焦点态，保证鼠标与遥控器表现一致。

    val rootFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { rootFocus.requestFocus() } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ZenithPalette.Void)
            .focusRequester(rootFocus)
            .focusable()
            .onKeyEvent { event ->
                // 只处理 KeyUp，避免长按重复触发
                if (event.type != KeyEventType.KeyUp) return@onKeyEvent false
                when (event.key) {
                    Key.H -> { onOpenHub(); true }
                    Key.Q -> { exitZenith(); true }
                    Key.R -> { startLanScan(); true }
                    else -> false
                }
            }
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {

            // ================= 顶部 =================
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MonoClock(Modifier.width(220.dp))
                Spacer(Modifier.width(24.dp))
                WifiStatusRow(
                    snapshot = network,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(24.dp))
                PeripheralIcons(snapshot = peripherals)
            }

            Spacer(Modifier.height(16.dp))

            // ================= 中间 =================
            Row(Modifier.fillMaxWidth().weight(1f)) {

                // 左列：监控
                Column(
                    modifier = Modifier
                        .width(280.dp)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                ) {
                    MonitorCard {
                        CpuMemoryRings(snapshot = hardware)
                        Spacer(Modifier.height(12.dp))
                        BatteryBlock(snapshot = hardware)
                    }

                    Spacer(Modifier.height(12.dp))

                    // 内存详情
                    MonitorCard {
                        Text(
                            text = "MEMORY",
                            style = MaterialTheme.typography.labelMedium,
                            color = ZenithPalette.TextDim
                        )
                        Spacer(Modifier.height(6.dp))
                        val mem = hardware?.memory
                        DetailRow(
                            label = "总量",
                            value = formatBytes(mem?.totalBytes ?: -1L)
                        )
                        DetailRow(
                            label = "已用",
                            value = formatBytes(mem?.usedBytes ?: -1L)
                        )
                        DetailRow(
                            label = "可用",
                            value = formatBytes(mem?.availableBytes ?: -1L)
                        )
                        DetailRow(
                            label = "缓存",
                            value = formatBytes(mem?.cachedBytes ?: -1L)
                        )
                        DetailRow(
                            label = "Swap",
                            value = if (mem == null || mem.swapTotalBytes <= 0L)
                                Unavailable.TEXT
                            else formatBytes(mem.swapUsedBytes)
                        )
                        val lmk = mem?.lmkThresholdBytes
                        DetailRow(
                            label = "LMK 阈值",
                            value = if (lmk.isNullOrEmpty()) Unavailable.TEXT
                            else lmk.joinToString("/") { formatBytes(it) }
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // 磁盘
                    MonitorCard {
                        Text(
                            text = "DISK",
                            style = MaterialTheme.typography.labelMedium,
                            color = ZenithPalette.TextDim
                        )
                        Spacer(Modifier.height(6.dp))
                        val disk = hardware?.disk
                        DetailRow(
                            label = "读",
                            value = if (disk == null) Unavailable.TEXT
                            else formatRate(disk.readBytesPerSecond)
                        )
                        DetailRow(
                            label = "写",
                            value = if (disk == null) Unavailable.TEXT
                            else formatRate(disk.writeBytesPerSecond)
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // 存储卷
                    MonitorCard {
                        Text(
                            text = "STORAGE",
                            style = MaterialTheme.typography.labelMedium,
                            color = ZenithPalette.TextDim
                        )
                        Spacer(Modifier.height(6.dp))
                        val volumes = peripherals?.volumes ?: emptyList()
                        if (volumes.isEmpty()) {
                            Text(
                                text = Unavailable.TEXT,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ZenithPalette.TextFaint
                            )
                        } else {
                            for (v in volumes.take(4)) {
                                DetailRow(
                                    label = v.label ?: v.path.substringAfterLast('/'),
                                    value = "${formatBytes(v.freeBytes)} / ${formatBytes(v.totalBytes)}"
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 局域网探针
                    MonitorCard(
                        onClick = { if (lanScanning) stopLanScan() else startLanScan() },
                        focusLabel = "局域网探针"
                    ) {
                        LanProbeStatus(
                            scanResult = lanResult,
                            scanning = lanScanning
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = when {
                                lanResult?.refused == true -> lanResult?.refusedReason ?: "已拒绝"
                                lanResult == null -> "点击开始扫描（只扫本机 /24）"
                                else -> "子网 ${lanResult?.subnet ?: Unavailable.TEXT}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithPalette.TextFaint,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (lanResult?.hosts?.isNotEmpty() == true) {
                            Spacer(Modifier.height(6.dp))
                            for (host in lanResult!!.hosts.take(4)) {
                                DetailRow(
                                    label = host.ip,
                                    value = "${host.mac ?: Unavailable.TEXT} ${
                                        if (host.rttMs <= 0L) "" else "· ${host.rttMs}ms"
                                    }"
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.width(16.dp))

                // 右区：应用位 + 错误提示
                Column(Modifier.fillMaxSize()) {

                    Text(
                        text = "APPS",
                        style = MaterialTheme.typography.labelMedium,
                        color = ZenithPalette.TextDim
                    )
                    Spacer(Modifier.height(8.dp))

                    // 应用位网格：5~8 个可配置，空位显示 "+"
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in 0 until slotCount) {
                            AppSlot(
                                index = i,
                                key = slots.getOrNull(i),
                                launchable = launchable,
                                onLaunch = { launchSlot(i) },
                                onRebind = { pendingSlotIndex = i },
                                onPick = { app -> bindSlot(i, app) },
                                onClear = {
                                    slotStore.setSlot(i, null)
                                    slots = slotStore.load()
                                },
                                pickerVisible = pendingSlotIndex == i,
                                onDismissPicker = { pendingSlotIndex = null },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "长按换绑 · 空位显示 + · D-pad OK 启动",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithPalette.TextFaint
                        )
                        Spacer(Modifier.width(16.dp))
                        Text(
                            text = "H=浏览器  R=扫描  Q=退出",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithPalette.TextFaint
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            text = "槽位数",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenithPalette.TextFaint
                        )
                        for (n in AppSlotStore.MIN_SLOTS..AppSlotStore.MAX_SLOTS) {
                            val selected = slotCount == n
                            Text(
                                text = "$n",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) ZenithPalette.TextMain else ZenithPalette.TextFaint,
                                modifier = Modifier
                                    .padding(horizontal = 3.dp)
                                    .focusable()
                                    .onFocusChanged { }
                                    .onKeyEvent { ev ->
                                        if (ev.type == KeyEventType.KeyUp &&
                                            (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                                        ) {
                                            slotCount = n
                                            slotStore.setCount(n)
                                            true
                                        } else false
                                    }
                                    .border(1.dp, if (selected) ZenithPalette.LineHi else ZenithPalette.Line)
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (launchError != null) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = launchError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenithPalette.Offline
                        )
                    }

                    Spacer(Modifier.weight(1f))

                    // ================= 右下：常驻退出 =================
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ExitButton(onClick = { exitZenith() })
                    }
                }
            }
        }
    }
}

// ---------------- 子组件 ----------------

@Composable
private fun MonitorCard(
    onClick: (() -> Unit)? = null,
    focusLabel: String? = null,
    content: @Composable () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val focused = remember { mutableStateOf(false) }
    val hovered by interaction.collectIsHoveredAsState()

    val bg = if (hovered || focused.value) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal
    val line = if (hovered || focused.value) ZenithPalette.LineHi else ZenithPalette.Line

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg)
            .border(1.dp, line)
            .padding(12.dp)
            .focusable()
            .onFocusChanged { focused.value = it.isFocused }
            .hoverable(interaction)
            .then(
                if (onClick != null) {
                    Modifier.onKeyEvent { ev ->
                        if (ev.type == KeyEventType.KeyUp &&
                            (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                        ) {
                            onClick()
                            true
                        } else false
                    }
                } else Modifier
            )
    ) {
        Column { content() }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = ZenithPalette.TextDim,
            modifier = Modifier.width(72.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = if (value == Unavailable.TEXT) ZenithPalette.TextFaint else ZenithPalette.TextMain,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AppSlot(
    index: Int,
    key: String?,
    launchable: List<LaunchableApp>,
    onLaunch: () -> Unit,
    onRebind: () -> Unit,
    onPick: (LaunchableApp) -> Unit,
    onClear: () -> Unit,
    pickerVisible: Boolean,
    onDismissPicker: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val pm = context.packageManager

    val app = key?.let { LaunchableApp.fromKey(it, pm) }
    val focused = remember { mutableStateOf(false) }
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()

    val bg = if (hovered || focused.value) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal
    val line = if (hovered || focused.value) ZenithPalette.LineHi else ZenithPalette.Line

    Box(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .background(bg)
                .border(1.dp, line)
                .focusable()
                .onFocusChanged { focused.value = it.isFocused }
                .hoverable(interaction)
                .onKeyEvent { ev ->
                    if (ev.type != KeyEventType.KeyUp || !ev.isFirstPress()) return@onKeyEvent false
                    when {
                        // 手柄 A / 遥控器 OK / 回车 都算确认
                        ev.isSelectKey() -> { onLaunch(); true }
                        // 键盘用户：Del / Backspace 清空该位
                        ev.key == Key.Delete || ev.key == Key.Backspace -> { onClear(); true }
                        else -> false
                    }
                }
                // 鼠标长按 = 换绑（遥控器走 Enter 两段式，两条路都通）
                .pointerInput(key, launchable.size) {
                    detectTapGestures(
                        onTap = { onLaunch() },
                        onLongPress = { onRebind() }
                    )
                }
                .padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (app == null) {
                Text(
                    text = "+",
                    style = MaterialTheme.typography.displayMedium,
                    color = ZenithPalette.TextFaint
                )
            } else {
                AppIconTile(
                    key = key,
                    label = app.label,
                    size = 30.dp,
                    dim = true
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = app.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = ZenithPalette.TextMain,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }
        }

        // 换绑面板（用 D-pad OK 在空位上触发；显示当前可启动应用列表前 12 个）
        if (pickerVisible) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ZenithPalette.Void.copy(alpha = 0.92f))
                    .border(1.dp, ZenithPalette.LineHi)
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "选择应用（Back 关闭）",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZenithPalette.TextDim
                    )
                    Spacer(Modifier.height(4.dp))
                    for (candidate in launchable.take(12)) {
                        Text(
                            text = candidate.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenithPalette.TextMain,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusable()
                                .onKeyEvent { ev ->
                                    if (ev.type == KeyEventType.KeyUp &&
                                        (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                                    ) {
                                        onPick(candidate)
                                        true
                                    } else false
                                }
                                .padding(vertical = 2.dp)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Esc/Back 关闭",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZenithPalette.TextFaint,
                        modifier = Modifier
                            .focusable()
                            .onKeyEvent { ev ->
                                if (ev.type == KeyEventType.KeyUp &&
                                    (ev.key == Key.Escape || ev.key == Key.Back)
                                ) {
                                    onDismissPicker()
                                    true
                                } else false
                            }
                    )
                }
            }
        }
    }
}

@Composable
private fun ExitButton(onClick: () -> Unit) {
    val focused = remember { mutableStateOf(false) }
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()

    val bg = if (hovered || focused.value) ZenithPalette.CharcoalHi else ZenithPalette.Charcoal
    val line = if (hovered || focused.value) ZenithPalette.LineHi else ZenithPalette.Line

    Text(
        text = "退出 Zenith",
        style = MaterialTheme.typography.titleMedium,
        color = ZenithPalette.TextMain,
        modifier = Modifier
            .background(bg)
            .border(1.dp, line)
            .focusable()
            .onFocusChanged { focused.value = it.isFocused }
            .hoverable(interaction)
            .onKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyUp &&
                    (ev.key == Key.Enter || ev.key == Key.DirectionCenter)
                ) {
                    onClick()
                    true
                } else false
            }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

// ---------------- 工具 ----------------

fun formatBytes(bytes: Long): String {
    if (bytes < 0) return Unavailable.TEXT
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble() / 1024.0
    var index = 0
    while (value >= 1024.0 && index < units.size - 1) {
        value /= 1024.0
        index++
    }
    return String.format(java.util.Locale.US, "%.1f %s", value, units[index])
}
